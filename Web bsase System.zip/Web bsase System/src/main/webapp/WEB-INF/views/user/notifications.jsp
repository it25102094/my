<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<jsp:include page="/WEB-INF/views/common/header.jsp">
    <jsp:param name="pageTitle" value="Notifications - Sportix" />
</jsp:include>
<jsp:include page="/WEB-INF/views/common/navbar.jsp" />

<div class="container my-5" style="max-width: 700px;">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="fw-bold mb-0"><i class="fas fa-bell text-primary me-2"></i> Notifications</h3>
        <span class="badge bg-secondary">${notifications.size()} alerts</span>
    </div>

    <c:choose>
        <c:when test="${empty notifications}">
            <div class="card bg-dark border-secondary p-5 text-center rounded-4 shadow">
                <i class="fas fa-bell-slash text-muted fa-3x mb-3"></i>
                <h5>No notifications yet.</h5>
                <p class="text-muted small">Follow teams to receive automated notifications when match clips are published.</p>
            </div>
        </c:when>
        <c:otherwise>
            <div class="list-group">
                <c:forEach var="n" items="${notifications}">
                    <div class="list-group-item bg-dark text-white border-secondary mb-2 rounded-3 p-3 ${!n.read ? 'border-primary' : ''}">
                        <div class="d-flex justify-content-between align-items-start">
                            <h6 class="fw-bold mb-1 text-primary">
                                <c:choose>
                                    <c:when test="${n.type == 'TEAM_POST'}"><i class="fas fa-upload me-1 text-success"></i></c:when>
                                    <c:when test="${n.type == 'MODERATION'}"><i class="fas fa-shield-alt me-1 text-warning"></i></c:when>
                                    <c:otherwise><i class="fas fa-info-circle me-1 text-info"></i></c:otherwise>
                                </c:choose>
                                ${n.title}
                            </h6>
                            <span class="text-muted small">${n.createdAt}</span>
                        </div>
                        <p class="small text-light mb-2">${n.message}</p>
                        
                        <div class="d-flex justify-content-between align-items-center">
                            <c:if test="${not empty n.referenceId}">
                                <a href="${pageContext.request.contextPath}/watch?v=${n.referenceId}" class="btn btn-sm btn-outline-primary rounded-pill px-3">
                                    Watch Video
                                </a>
                            </c:if>
                            <c:if test="${!n.read}">
                                <button type="button" class="btn btn-link text-muted p-0 small text-decoration-none ms-auto" onclick="markRead(${n.notificationId}, this)">
                                    <i class="fas fa-check me-1"></i> Mark as Read
                                </button>
                            </c:if>
                        </div>
                    </div>
                </c:forEach>
            </div>
        </c:otherwise>
    </c:choose>
</div>

<script>
function markRead(id, btn) {
    fetch('notifications/read', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'notificationId=' + id
    }).then(res => {
        if (res.ok) {
            btn.parentElement.parentElement.classList.remove('border-primary');
            btn.remove();
        }
    });
}
</script>

<jsp:include page="/WEB-INF/views/common/footer.jsp" />
