<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<jsp:include page="/WEB-INF/views/common/header.jsp">
    <jsp:param name="pageTitle" value="Login - Sportix" />
</jsp:include>
<jsp:include page="/WEB-INF/views/common/navbar.jsp" />

<div class="container my-5" style="max-width: 480px;">
    <div class="card bg-dark border-secondary p-4 p-md-5 rounded-4 shadow-lg">
        <div class="text-center mb-4">
            <i class="fas fa-play-circle text-primary fa-3x mb-2"></i>
            <h3 class="fw-bold">Sign In to Sportix</h3>
            <p class="text-muted small">Enter your credentials to access personalized sports feeds.</p>
        </div>

        <c:if test="${not empty errorMessage}">
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-circle me-2"></i> ${errorMessage}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        </c:if>

        <form action="${pageContext.request.contextPath}/login" method="POST">
            <div class="mb-3">
                <label class="form-label small fw-bold">Username or Email</label>
                <div class="input-group">
                    <span class="input-group-text bg-dark border-secondary text-muted"><i class="fas fa-user"></i></span>
                    <input type="text" class="form-control bg-dark text-white border-secondary" name="identifier" 
                           placeholder="username or user@gmail.com" value="${identifier}" required>
                </div>
            </div>

            <div class="mb-4">
                <label class="form-label small fw-bold">Password</label>
                <div class="input-group">
                    <span class="input-group-text bg-dark border-secondary text-muted"><i class="fas fa-lock"></i></span>
                    <input type="password" class="form-control bg-dark text-white border-secondary" name="password" 
                           placeholder="••••••••" required>
                </div>
            </div>

            <button type="submit" class="btn btn-primary w-100 rounded-pill py-2 fw-bold mb-3">
                <i class="fas fa-sign-in-alt me-1"></i> Sign In
            </button>

            <!-- System Accounts Reference for Evaluators -->
            <div class="p-3 bg-black rounded-3 border border-secondary small text-muted mb-3">
                <div class="fw-bold text-light mb-1"><i class="fas fa-shield-alt text-primary me-1"></i> Pre-configured Test Accounts:</div>
                <div>• Admin: <code>admin</code> / <code>Admin@123</code></div>
                <div>• Content Mgr: <code>content_mgr</code> / <code>Admin@123</code></div>
                <div>• Registered User: <code>john_fan</code> / <code>User@123</code></div>
            </div>

            <div class="text-center text-muted small">
                Don't have an account? <a href="${pageContext.request.contextPath}/register" class="text-primary fw-bold">Create Account</a>
            </div>
        </form>
    </div>
</div>

<jsp:include page="/WEB-INF/views/common/footer.jsp" />
