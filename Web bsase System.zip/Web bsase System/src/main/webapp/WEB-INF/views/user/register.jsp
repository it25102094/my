<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<jsp:include page="/WEB-INF/views/common/header.jsp">
    <jsp:param name="pageTitle" value="Create Account - SPORTIX" />
</jsp:include>
<jsp:include page="/WEB-INF/views/common/navbar.jsp" />

<div class="container-fluid px-lg-5 auth-page-container">
    <div class="row align-items-center w-100 g-5">
        <!-- LEFT HERO COLUMN (Screenshot 1 Left) -->
        <div class="col-lg-7 auth-hero-col">
            <h1 class="auth-hero-title">
                SPORTS<br>
                BRINGS US<br>
                <span class="highlight">CLOSER</span>
            </h1>
            <p class="lead text-light mb-4" style="max-width: 500px; font-size: 1.15rem;">
                Live matches. Unmissable highlights.<br>
                A home for Sri Lankan sports fans.
            </p>

            <div class="auth-feature-list">
                <div class="auth-feature-item">
                    <div class="icon-wrap"><i class="fas fa-users"></i></div>
                    <div>
                        <div class="fw-bold text-white">Follow Teams</div>
                        <div class="text-muted small">Get updates on your favourite teams.</div>
                    </div>
                </div>

                <div class="auth-feature-item">
                    <div class="icon-wrap"><i class="fas fa-bookmark"></i></div>
                    <div>
                        <div class="fw-bold text-white">Watch Later</div>
                        <div class="text-muted small">Save matches and highlights to watch anytime.</div>
                    </div>
                </div>

                <div class="auth-feature-item">
                    <div class="icon-wrap"><i class="fas fa-eye-slash"></i></div>
                    <div>
                        <div class="fw-bold text-white">Spoiler-Free Mode</div>
                        <div class="text-muted small">Explore freely. We'll keep scores under wraps.</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- RIGHT FORM COLUMN (Screenshot 1 Right) -->
        <div class="col-lg-5">
            <div class="auth-card-glass">
                <div class="auth-tabs">
                    <div class="auth-tab-item active">Create Account</div>
                    <a href="${pageContext.request.contextPath}/login" class="auth-tab-item">Log In</a>
                </div>

                <c:if test="${not empty errorMessage}">
                    <div class="alert alert-danger py-2 small mb-3">${errorMessage}</div>
                </c:if>

                <form action="${pageContext.request.contextPath}/register" method="POST">
                    <!-- Display Name -->
                    <div class="form-floating-custom">
                        <div class="d-flex justify-content-between align-items-center">
                            <label>Display Name</label>
                            <span class="text-muted small" style="font-size: 0.72rem;">14/30</span>
                        </div>
                        <div class="input-with-icon">
                            <i class="far fa-user"></i>
                            <input type="text" class="form-control" name="displayName" value="${displayName}" placeholder="Kavindu Perera" required>
                        </div>
                        <div class="text-muted small mt-1" style="font-size: 0.72rem;">This will be visible to other fans.</div>
                    </div>

                    <!-- Username & Email -->
                    <div class="form-floating-custom">
                        <label>Username</label>
                        <div class="input-with-icon">
                            <i class="fas fa-at"></i>
                            <input type="text" class="form-control" name="username" value="${username}" placeholder="kavindu99" required minlength="3">
                        </div>
                    </div>

                    <div class="form-floating-custom">
                        <label>Email Address</label>
                        <div class="input-with-icon">
                            <i class="far fa-envelope"></i>
                            <input type="email" class="form-control" name="email" value="${email}" placeholder="kavindu@example.com" required>
                        </div>
                        <div class="text-muted small mt-1" style="font-size: 0.72rem;">We'll use this to verify your account.</div>
                    </div>

                    <!-- Password with 4-bar strength meter -->
                    <div class="form-floating-custom">
                        <label>Password</label>
                        <div class="input-with-icon position-relative">
                            <i class="fas fa-lock"></i>
                            <input type="password" id="passInput" name="password" class="form-control" placeholder="••••••••" required minlength="6">
                            <i class="far fa-eye position-absolute end-0 top-50 translate-middle-y me-3 cursor-pointer text-muted" onclick="togglePassView('passInput')"></i>
                        </div>
                        <div class="d-flex justify-content-between align-items-center mt-1">
                            <div class="strength-meter-bar flex-grow-1 me-3">
                                <div class="bar active"></div>
                                <div class="bar active"></div>
                                <div class="bar active"></div>
                                <div class="bar"></div>
                            </div>
                            <span class="text-success fw-bold small" style="font-size: 0.72rem;">Strong</span>
                        </div>
                    </div>

                    <!-- Confirm Password -->
                    <div class="form-floating-custom">
                        <label>Confirm Password</label>
                        <div class="input-with-icon position-relative">
                            <i class="fas fa-lock"></i>
                            <input type="password" id="confirmPassInput" name="confirmPassword" class="form-control" placeholder="••••••••" required minlength="6">
                            <i class="far fa-eye position-absolute end-0 top-50 translate-middle-y me-3 cursor-pointer text-muted" onclick="togglePassView('confirmPassInput')"></i>
                        </div>
                        <div class="text-success small mt-1 d-flex align-items-center gap-1" style="font-size: 0.75rem;">
                            <i class="fas fa-check-circle"></i> Passwords match
                        </div>
                    </div>

                    <!-- Role Selection (For evaluation) -->
                    <div class="mb-3">
                        <label class="form-label small text-muted">Role:</label>
                        <select class="form-select form-select-sm bg-dark text-white border-secondary" name="role">
                            <option value="REGISTERED">Sports Fan (Registered User)</option>
                            <option value="CONTENT_MANAGER">Content Manager</option>
                            <option value="ADVERTISER">Brand Advertiser</option>
                        </select>
                    </div>

                    <div class="form-check mb-4">
                        <input class="form-check-input" type="checkbox" id="termsCheck" checked required>
                        <label class="form-check-label text-muted small" for="termsCheck" style="font-size: 0.75rem;">
                            I agree to the <a href="#" class="text-light text-decoration-underline">Terms of Service</a> and <a href="#" class="text-light text-decoration-underline">Privacy Policy</a>.
                        </label>
                    </div>

                    <button type="submit" class="btn-sportix-primary w-100 py-3 mb-3">
                        Create Account <i class="fas fa-arrow-right ms-2"></i>
                    </button>

                    <div class="position-relative text-center my-3">
                        <hr class="border-secondary m-0">
                        <span class="position-absolute top-50 start-50 translate-middle bg-dark px-3 text-muted small" style="font-size: 0.7rem;">OR</span>
                    </div>

                    <button type="button" class="btn btn-sportix-dark w-100 py-2 d-flex align-items-center justify-content-center gap-2 mb-4" onclick="window.location.href='${pageContext.request.contextPath}/home'">
                        <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" alt="Google" style="width: 18px; height: 18px;">
                        <span>Continue with Google</span>
                    </button>

                    <div class="text-center text-muted small">
                        Already have an account? <a href="${pageContext.request.contextPath}/login" class="text-success fw-bold">Log In</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function togglePassView(id) {
    const el = document.getElementById(id);
    el.type = el.type === 'password' ? 'text' : 'password';
}
</script>

<jsp:include page="/WEB-INF/views/common/footer.jsp" />
