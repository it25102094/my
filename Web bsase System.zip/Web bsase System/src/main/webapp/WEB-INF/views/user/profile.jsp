<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<jsp:include page="/WEB-INF/views/common/header.jsp">
    <jsp:param name="pageTitle" value="User Profile - Sportix" />
</jsp:include>
<jsp:include page="/WEB-INF/views/common/navbar.jsp" />

<div class="container my-5" style="max-width: 900px;">
    <div class="row g-4">
        <!-- Profile Details (Member 1) -->
        <div class="col-md-5">
            <div class="card bg-dark border-secondary p-4 rounded-4 shadow">
                <div class="text-center mb-3">
                    <div class="rounded-circle bg-primary text-white mx-auto d-flex align-items-center justify-content-center" style="width: 80px; height: 80px; font-size: 2rem; font-weight: bold;">
                        ${user.displayName.substring(0, 1).toUpperCase()}
                    </div>
                    <h4 class="fw-bold mt-2 mb-0">${user.displayName}</h4>
                    <span class="badge bg-secondary">${user.role}</span>
                </div>

                <c:if test="${not empty successMessage}">
                    <div class="alert alert-success small py-2">${successMessage}</div>
                </c:if>

                <form action="${pageContext.request.contextPath}/profile" method="POST">
                    <div class="mb-3">
                        <label class="form-label small text-muted">Username:</label>
                        <input type="text" class="form-control bg-dark text-white border-secondary form-control-sm" value="${user.username}" readonly>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small text-muted">Display Name:</label>
                        <input type="text" class="form-control bg-dark text-white border-secondary form-control-sm" name="displayName" value="${user.displayName}" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small text-muted">Email Address:</label>
                        <input type="email" class="form-control bg-dark text-white border-secondary form-control-sm" name="email" value="${user.email}" required>
                    </div>
                    <button type="submit" class="btn btn-primary btn-sm rounded-pill w-100 fw-bold">Update Profile</button>
                </form>
            </div>
        </div>

        <!-- Followed Teams Management (Member 1) -->
        <div class="col-md-7">
            <div class="card bg-dark border-secondary p-4 rounded-4 shadow">
                <h5 class="fw-bold mb-3"><i class="fas fa-shield-alt text-primary me-2"></i> Followed Teams</h5>
                <p class="text-muted small">You will receive automated notification alerts whenever new match highlights are published for your followed teams.</p>

                <div class="d-flex flex-wrap gap-2 mb-4">
                    <c:forEach var="ft" items="${followedTeams}">
                        <div class="d-flex align-items-center bg-black border border-secondary px-3 py-2 rounded-pill gap-2">
                            <span class="small fw-bold">${ft.name}</span>
                            <form action="${pageContext.request.contextPath}/unfollow-team" method="POST" class="m-0">
                                <input type="hidden" name="teamId" value="${ft.teamId}">
                                <button type="submit" class="btn btn-link text-danger p-0 small" title="Unfollow team">
                                    <i class="fas fa-times-circle"></i>
                                </button>
                            </form>
                        </div>
                    </c:forEach>
                    <c:if test="${empty followedTeams}">
                        <span class="text-muted small">You are not following any teams yet.</span>
                    </c:if>
                </div>

                <h6 class="fw-bold small text-muted text-uppercase mb-2">Discover Teams to Follow:</h6>
                <div class="list-group list-group-flush bg-transparent">
                    <c:forEach var="tm" items="${allTeams}">
                        <div class="list-group-item bg-transparent text-white border-secondary d-flex justify-content-between align-items-center px-0 py-2">
                            <div>
                                <span class="fw-bold small">${tm.name}</span>
                                <span class="badge bg-secondary ms-2 small">${tm.categoryName}</span>
                            </div>
                            <form action="${pageContext.request.contextPath}/follow-team" method="POST" class="m-0">
                                <input type="hidden" name="teamId" value="${tm.teamId}">
                                <button type="submit" class="btn btn-outline-primary btn-sm rounded-pill px-3">
                                    <i class="fas fa-plus me-1"></i> Follow
                                </button>
                            </form>
                        </div>
                    </c:forEach>
                </div>
            </div>
        </div>
    </div>
</div>

<jsp:include page="/WEB-INF/views/common/footer.jsp" />
