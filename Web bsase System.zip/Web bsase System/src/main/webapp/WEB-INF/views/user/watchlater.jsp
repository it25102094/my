<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<jsp:include page="/WEB-INF/views/common/header.jsp">
    <jsp:param name="pageTitle" value="My Watch Later - Sportix" />
</jsp:include>
<jsp:include page="/WEB-INF/views/common/navbar.jsp" />

<div class="container my-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="fw-bold mb-0"><i class="fas fa-clock text-primary me-2"></i> Watch Later List</h3>
        <span class="badge bg-secondary">${watchLaterList.size()} saved videos</span>
    </div>

    <c:choose>
        <c:when test="${empty watchLaterList}">
            <div class="card bg-dark border-secondary p-5 text-center my-4 rounded-4 shadow">
                <i class="fas fa-bookmark text-muted fa-3x mb-3"></i>
                <h5>Your Watch Later list is empty.</h5>
                <p class="text-muted small">Save any match or highlight while browsing to watch them at your convenience.</p>
                <div>
                    <a href="${pageContext.request.contextPath}/home" class="btn btn-primary rounded-pill px-4 mt-2">Explore Highlights</a>
                </div>
            </div>
        </c:when>
        <c:otherwise>
            <div class="row g-4">
                <c:forEach var="item" items="${watchLaterList}">
                    <div class="col-md-6 col-lg-3">
                        <div class="video-card">
                            <a href="${pageContext.request.contextPath}/watch?v=${item.video.videoId}" class="thumbnail-wrap">
                                <img src="${item.video.thumbnailUrl}" alt="${item.video.title}">
                                <span class="badge-video-type">${item.video.videoType}</span>
                            </a>
                            <div class="video-card-body">
                                <span class="badge bg-secondary mb-2 align-self-start small">${item.video.categoryName}</span>
                                <h6 class="video-card-title">
                                    <a href="${pageContext.request.contextPath}/watch?v=${item.video.videoId}">${item.video.title}</a>
                                </h6>
                                <div class="video-card-meta mt-2 pt-2 border-top border-secondary">
                                    <span class="small text-muted"><i class="fas fa-eye me-1"></i> ${item.video.viewCount}</span>
                                    <form action="${pageContext.request.contextPath}/watch-later/remove" method="POST" class="m-0">
                                        <input type="hidden" name="videoId" value="${item.video.videoId}">
                                        <button type="submit" class="btn btn-link text-danger p-0 small text-decoration-none">
                                            <i class="fas fa-trash-alt me-1"></i> Remove
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </c:forEach>
            </div>
        </c:otherwise>
    </c:choose>
</div>

<jsp:include page="/WEB-INF/views/common/footer.jsp" />
