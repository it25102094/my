<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<jsp:include page="/WEB-INF/views/common/header.jsp">
    <jsp:param name="pageTitle" value="Admin Command Center (All Members) - Sportix" />
</jsp:include>
<jsp:include page="/WEB-INF/views/common/navbar.jsp" />

<div class="container-fluid px-lg-5 my-4">
    <!-- Header Banner -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3 mb-4 pb-3 border-bottom border-secondary">
        <div>
            <div class="d-flex align-items-center gap-2 mb-1">
                <span class="badge bg-danger px-2 py-1"><i class="fas fa-shield-alt me-1"></i> MASTER ADMIN ACCESS</span>
                <span class="badge bg-dark border border-secondary text-muted">SE2030 Group: 2026-Y2-S1-MTR-15</span>
            </div>
            <h2 class="fw-bold mb-1"><i class="fas fa-sliders-h text-primary me-2"></i> Administrator Command Center</h2>
            <p class="text-muted small mb-0">Centralized CRUD Control across all 6 Team Members' Functional Areas</p>
        </div>
        <div class="d-flex flex-wrap gap-2">
            <button class="btn btn-primary rounded-pill px-3 fw-bold btn-sm shadow-sm" data-bs-toggle="modal" data-bs-target="#createEventModal">
                <i class="fas fa-calendar-plus me-1"></i> Add Event
            </button>
            <button class="btn btn-outline-info rounded-pill px-3 btn-sm" data-bs-toggle="modal" data-bs-target="#createUserModal">
                <i class="fas fa-user-plus me-1"></i> Add User
            </button>
            <button class="btn btn-outline-warning rounded-pill px-3 btn-sm" data-bs-toggle="modal" data-bs-target="#createCategoryModal">
                <i class="fas fa-folder-plus me-1"></i> Add Sport
            </button>
            <button class="btn btn-outline-success rounded-pill px-3 btn-sm" data-bs-toggle="modal" data-bs-target="#createAdModal">
                <i class="fas fa-bullhorn me-1"></i> Create Ad
            </button>
        </div>
    </div>

    <!-- Alert Messages -->
    <c:if test="${not empty param.success}">
        <div class="alert alert-success alert-dismissible fade show bg-dark border-success text-success d-flex align-items-center" role="alert">
            <i class="fas fa-check-circle me-2 fs-5"></i>
            <div>${param.success}</div>
            <button type="button" class="btn-close btn-close-white ms-auto" data-bs-dismiss="alert"></button>
        </div>
    </c:if>
    <c:if test="${not empty param.error}">
        <div class="alert alert-danger alert-dismissible fade show bg-dark border-danger text-danger d-flex align-items-center" role="alert">
            <i class="fas fa-exclamation-triangle me-2 fs-5"></i>
            <div>${param.error}</div>
            <button type="button" class="btn-close btn-close-white ms-auto" data-bs-dismiss="alert"></button>
        </div>
    </c:if>

    <!-- Top KPI Stats Row -->
    <div class="row g-3 mb-4">
        <div class="col-6 col-md-4 col-xl-2">
            <div class="card bg-dark border-secondary p-3 text-center rounded-4 shadow-sm h-100">
                <div class="text-muted small mb-1"><i class="fas fa-users text-primary me-1"></i> Total Users (M1)</div>
                <h3 class="fw-bold text-white mb-0">${stats.totalUsers}</h3>
            </div>
        </div>
        <div class="col-6 col-md-4 col-xl-2">
            <div class="card bg-dark border-secondary p-3 text-center rounded-4 shadow-sm h-100">
                <div class="text-muted small mb-1"><i class="fas fa-tags text-info me-1"></i> Sports / Teams (M2)</div>
                <h3 class="fw-bold text-info mb-0">${categories.size()} / ${teams.size()}</h3>
            </div>
        </div>
        <div class="col-6 col-md-4 col-xl-2">
            <div class="card bg-dark border-secondary p-3 text-center rounded-4 shadow-sm h-100">
                <div class="text-muted small mb-1"><i class="fas fa-calendar-alt text-primary me-1"></i> Events / Live (M3)</div>
                <h3 class="fw-bold text-primary mb-0">${stats.totalEvents != null ? stats.totalEvents : eventList.size()}</h3>
            </div>
        </div>
        <div class="col-6 col-md-4 col-xl-2">
            <div class="card bg-dark border-secondary p-3 text-center rounded-4 shadow-sm h-100">
                <div class="text-muted small mb-1"><i class="fas fa-comments text-success me-1"></i> Comments (M4)</div>
                <h3 class="fw-bold text-success mb-0">${stats.totalComments != null ? stats.totalComments : allComments.size()}</h3>
            </div>
        </div>
        <div class="col-6 col-md-4 col-xl-2">
            <div class="card bg-dark border-secondary p-3 text-center rounded-4 shadow-sm h-100">
                <div class="text-muted small mb-1"><i class="fas fa-ad text-warning me-1"></i> Ad Campaigns (M5)</div>
                <h3 class="fw-bold text-warning mb-0">${stats.activeAds != null ? stats.activeAds : adList.size()}</h3>
            </div>
        </div>
        <div class="col-6 col-md-4 col-xl-2">
            <div class="card bg-dark border-secondary p-3 text-center rounded-4 shadow-sm h-100">
                <div class="text-muted small mb-1"><i class="fas fa-shield-alt text-danger me-1"></i> Reports (M6)</div>
                <h3 class="fw-bold text-danger mb-0">${stats.pendingReports}</h3>
            </div>
        </div>
    </div>

    <!-- Navigation Tabs: Dedicated to All 6 Members -->
    <ul class="nav nav-pills mb-4 gap-2 border-bottom border-secondary pb-3" id="adminTabs" role="tablist">
        <li class="nav-item">
            <button class="nav-link ${empty param.tab || param.tab == 'events' ? 'active' : ''} rounded-pill px-3 fw-bold" data-bs-toggle="tab" data-bs-target="#events-pane">
                <i class="fas fa-trophy me-1"></i> M3: Events (${eventList.size()})
            </button>
        </li>
        <li class="nav-item">
            <button class="nav-link ${param.tab == 'videos' ? 'active' : ''} rounded-pill px-3 fw-bold" data-bs-toggle="tab" data-bs-target="#videos-pane">
                <i class="fas fa-film me-1"></i> M3: Videos (${videoList.size()})
            </button>
        </li>
        <li class="nav-item">
            <button class="nav-link ${param.tab == 'categories' ? 'active' : ''} rounded-pill px-3 fw-bold" data-bs-toggle="tab" data-bs-target="#categories-pane">
                <i class="fas fa-folder me-1"></i> M2: Categories & Teams
            </button>
        </li>
        <li class="nav-item">
            <button class="nav-link ${param.tab == 'comments' ? 'active' : ''} rounded-pill px-3 fw-bold" data-bs-toggle="tab" data-bs-target="#comments-pane">
                <i class="fas fa-comments me-1"></i> M4: Comments Feed (${allComments.size()})
            </button>
        </li>
        <li class="nav-item">
            <button class="nav-link ${param.tab == 'ads' ? 'active' : ''} rounded-pill px-3 fw-bold" data-bs-toggle="tab" data-bs-target="#ads-pane">
                <i class="fas fa-bullhorn me-1"></i> M5: Ads (${adList.size()})
            </button>
        </li>
        <li class="nav-item">
            <button class="nav-link ${param.tab == 'moderation' ? 'active' : ''} rounded-pill px-3 fw-bold" data-bs-toggle="tab" data-bs-target="#moderation-pane">
                <i class="fas fa-shield-alt me-1"></i> M6: Moderation
                <c:if test="${stats.pendingReports > 0}"><span class="badge bg-danger ms-1">${stats.pendingReports}</span></c:if>
            </button>
        </li>
        <li class="nav-item">
            <button class="nav-link ${param.tab == 'users' ? 'active' : ''} rounded-pill px-3 fw-bold" data-bs-toggle="tab" data-bs-target="#users-pane">
                <i class="fas fa-user-cog me-1"></i> M1: Users (${userList.size()})
            </button>
        </li>
    </ul>

    <!-- Tab Contents -->
    <div class="tab-content" id="adminTabsContent">

        <!-- ==========================================
             TAB 1: SPORTING EVENTS & LIVE FIXTURES (MEMBER 3 & 6)
             ========================================== -->
        <div class="tab-pane fade ${empty param.tab || param.tab == 'events' ? 'show active' : ''}" id="events-pane">
            <div class="card bg-dark border-secondary rounded-4 shadow overflow-hidden">
                <div class="card-header bg-black border-secondary py-3 d-flex justify-content-between align-items-center">
                    <h5 class="fw-bold mb-0 text-white"><i class="fas fa-trophy text-primary me-2"></i> Match Fixtures & Live Scoring Desk (Member 3 & 6)</h5>
                    <button class="btn btn-primary btn-sm rounded-pill px-3 fw-bold" data-bs-toggle="modal" data-bs-target="#createEventModal">
                        <i class="fas fa-plus me-1"></i> Add Event
                    </button>
                </div>
                <div class="table-responsive">
                    <table class="table table-dark table-hover mb-0 align-middle">
                        <thead>
                            <tr class="text-muted small border-secondary">
                                <th>ID</th>
                                <th>Match / Tournament</th>
                                <th>Sport</th>
                                <th>Matchup</th>
                                <th>Schedule & Venue</th>
                                <th>Live Score & Status</th>
                                <th class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach var="ev" items="${eventList}">
                                <tr>
                                    <td class="text-muted fw-bold">#${ev.eventId}</td>
                                    <td>
                                        <div class="fw-bold text-white">${ev.title}</div>
                                        <div class="small text-muted">${ev.tournamentName}</div>
                                    </td>
                                    <td><span class="badge bg-dark border border-secondary text-primary">${ev.categoryName}</span></td>
                                    <td>${ev.team1Name} <span class="text-muted small">vs</span> ${ev.team2Name}</td>
                                    <td>
                                        <div class="small text-white">${ev.eventDate} • ${ev.eventTime}</div>
                                        <div class="text-muted small"><i class="fas fa-map-marker-alt text-danger me-1"></i>${ev.venue}</div>
                                    </td>
                                    <td>
                                        <div class="mb-1">
                                            <c:choose>
                                                <c:when test="${ev.status == 'LIVE'}"><span class="badge bg-danger">LIVE NOW</span></c:when>
                                                <c:when test="${ev.status == 'UPCOMING'}"><span class="badge bg-info text-dark">UPCOMING</span></c:when>
                                                <c:otherwise><span class="badge bg-secondary">COMPLETED</span></c:otherwise>
                                            </c:choose>
                                        </div>
                                        <div class="fw-bold font-monospace small">${ev.team1Score != null ? ev.team1Score : '-'} : ${ev.team2Score != null ? ev.team2Score : '-'}</div>
                                    </td>
                                    <td class="text-end">
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-outline-warning btn-sm" onclick="openScoreModal(${ev.eventId}, '${ev.title}', '${ev.team1Name}', '${ev.team2Name}', '${ev.team1Score}', '${ev.team2Score}', '${ev.status}', '${ev.matchSummary}')">
                                                <i class="fas fa-edit me-1"></i> Score
                                            </button>
                                            <button type="button" class="btn btn-outline-primary btn-sm" onclick="openEditEventModal(${ev.eventId}, '${ev.title}', ${ev.categoryId}, '${ev.tournamentName}', ${ev.team1Id}, ${ev.team2Id}, '${ev.eventDate}', '${ev.eventTime}', '${ev.venue}', '${ev.status}', '${ev.team1Score}', '${ev.team2Score}', '${ev.matchSummary}', ${ev.liveViewers}, '${ev.videoId}')">
                                                <i class="fas fa-cog"></i>
                                            </button>
                                            <form action="${pageContext.request.contextPath}/admin/events/delete" method="POST" class="d-inline" onsubmit="return confirm('Delete event?');">
                                                <input type="hidden" name="eventId" value="${ev.eventId}">
                                                <button type="submit" class="btn btn-outline-danger btn-sm"><i class="fas fa-trash-alt"></i></button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ==========================================
             TAB 2: VIDEO CATALOG MANAGEMENT (MEMBER 3 & 2)
             ========================================== -->
        <div class="tab-pane fade ${param.tab == 'videos' ? 'show active' : ''}" id="videos-pane">
            <div class="card bg-dark border-secondary rounded-4 shadow overflow-hidden">
                <div class="card-header bg-black border-secondary py-3 d-flex justify-content-between align-items-center">
                    <h5 class="fw-bold mb-0 text-white"><i class="fas fa-film text-primary me-2"></i> Published Video Catalog (Member 3 & 2)</h5>
                    <a href="${pageContext.request.contextPath}/admin/videos/add" class="btn btn-primary btn-sm rounded-pill px-3">
                        <i class="fas fa-upload me-1"></i> Upload Video
                    </a>
                </div>
                <div class="table-responsive">
                    <table class="table table-dark table-hover mb-0 align-middle">
                        <thead>
                            <tr class="text-muted small border-secondary">
                                <th>Thumb</th>
                                <th>Video Title</th>
                                <th>Sport</th>
                                <th>Type</th>
                                <th>Engagement</th>
                                <th>Status</th>
                                <th class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach var="v" items="${videoList}">
                                <tr>
                                    <td><img src="${v.thumbnailUrl}" class="rounded border border-secondary" style="width: 80px; height: 45px; object-fit: cover;" alt="thumb"></td>
                                    <td>
                                        <div class="fw-bold text-white">${v.title}</div>
                                        <div class="small text-muted">by ${v.uploaderName}</div>
                                    </td>
                                    <td><span class="badge bg-dark border border-secondary">${v.categoryName}</span></td>
                                    <td><span class="badge bg-secondary">${v.videoType}</span></td>
                                    <td class="small text-muted">${v.viewCount} views • ${v.likeCount} likes</td>
                                    <td><span class="badge ${v.status == 'APPROVED' ? 'bg-success' : 'bg-warning text-dark'}">${v.status}</span></td>
                                    <td class="text-end">
                                        <form action="${pageContext.request.contextPath}/admin/videos/delete" method="POST" class="d-inline" onsubmit="return confirm('Delete video?');">
                                            <input type="hidden" name="videoId" value="${v.videoId}">
                                            <button type="submit" class="btn btn-outline-danger btn-sm"><i class="fas fa-trash-alt"></i></button>
                                        </form>
                                    </td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ==========================================
             TAB 3: SPORTS CATEGORIES & TEAMS (MEMBER 2)
             ========================================== -->
        <div class="tab-pane fade ${param.tab == 'categories' ? 'show active' : ''}" id="categories-pane">
            <div class="row g-4">
                <!-- Categories Sub-card -->
                <div class="col-lg-6">
                    <div class="card bg-dark border-secondary rounded-4 shadow overflow-hidden h-100">
                        <div class="card-header bg-black border-secondary py-3 d-flex justify-content-between align-items-center">
                            <h5 class="fw-bold mb-0 text-white"><i class="fas fa-tags text-primary me-2"></i> Sports Categories</h5>
                            <button class="btn btn-primary btn-sm rounded-pill px-3" data-bs-toggle="modal" data-bs-target="#createCategoryModal">
                                <i class="fas fa-plus me-1"></i> Add Category
                            </button>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-dark table-hover mb-0 align-middle">
                                <thead>
                                    <tr class="text-muted small border-secondary">
                                        <th>ID</th>
                                        <th>Sport Name</th>
                                        <th>Slug</th>
                                        <th class="text-end">Delete</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <c:forEach var="c" items="${categories}">
                                        <tr>
                                            <td class="text-muted fw-bold">#${c.categoryId}</td>
                                            <td class="fw-bold text-white"><i class="${c.iconClass} me-2 text-primary"></i> ${c.name}</td>
                                            <td class="small text-muted"><code>${c.slug}</code></td>
                                            <td class="text-end">
                                                <form action="${pageContext.request.contextPath}/admin/categories/delete" method="POST" class="d-inline" onsubmit="return confirm('Delete category?');">
                                                    <input type="hidden" name="categoryId" value="${c.categoryId}">
                                                    <button type="submit" class="btn btn-outline-danger btn-sm"><i class="fas fa-trash-alt"></i></button>
                                                </form>
                                            </td>
                                        </tr>
                                    </c:forEach>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Teams Sub-card -->
                <div class="col-lg-6">
                    <div class="card bg-dark border-secondary rounded-4 shadow overflow-hidden h-100">
                        <div class="card-header bg-black border-secondary py-3 d-flex justify-content-between align-items-center">
                            <h5 class="fw-bold mb-0 text-white"><i class="fas fa-shield-alt text-info me-2"></i> Clubs & Sports Teams</h5>
                            <button class="btn btn-info btn-sm rounded-pill px-3 fw-bold text-dark" data-bs-toggle="modal" data-bs-target="#createTeamModal">
                                <i class="fas fa-plus me-1"></i> Add Team
                            </button>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-dark table-hover mb-0 align-middle">
                                <thead>
                                    <tr class="text-muted small border-secondary">
                                        <th>ID</th>
                                        <th>Team Name</th>
                                        <th>Category</th>
                                        <th>Country</th>
                                        <th class="text-end">Delete</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <c:forEach var="t" items="${teams}">
                                        <tr>
                                            <td class="text-muted fw-bold">#${t.teamId}</td>
                                            <td class="fw-bold text-white">
                                                <img src="${t.logoUrl}" class="rounded-circle me-1 border border-secondary" style="width: 24px; height: 24px; object-fit: cover;" onerror="this.src='https://via.placeholder.com/24';">
                                                ${t.name}
                                            </td>
                                            <td><span class="badge bg-dark border border-secondary">${t.categoryName}</span></td>
                                            <td class="small text-muted">${t.country}</td>
                                            <td class="text-end">
                                                <form action="${pageContext.request.contextPath}/admin/teams/delete" method="POST" class="d-inline" onsubmit="return confirm('Delete team?');">
                                                    <input type="hidden" name="teamId" value="${t.teamId}">
                                                    <button type="submit" class="btn btn-outline-danger btn-sm"><i class="fas fa-trash-alt"></i></button>
                                                </form>
                                            </td>
                                        </tr>
                                    </c:forEach>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ==========================================
             TAB 4: COMMENTS & USER ENGAGEMENT (MEMBER 4)
             ========================================== -->
        <div class="tab-pane fade ${param.tab == 'comments' ? 'show active' : ''}" id="comments-pane">
            <div class="card bg-dark border-secondary rounded-4 shadow overflow-hidden">
                <div class="card-header bg-black border-secondary py-3">
                    <h5 class="fw-bold mb-0 text-white"><i class="fas fa-comments text-primary me-2"></i> User Comments Audit Desk (Member 4 - Wijesekara)</h5>
                    <small class="text-muted">Review, moderate, and remove comments across all videos</small>
                </div>
                <div class="table-responsive">
                    <table class="table table-dark table-hover mb-0 align-middle">
                        <thead>
                            <tr class="text-muted small border-secondary">
                                <th>ID</th>
                                <th>User</th>
                                <th>Video Title</th>
                                <th>Comment Content</th>
                                <th>Timestamp</th>
                                <th class="text-end">Moderation</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach var="cm" items="${allComments}">
                                <tr>
                                    <td class="text-muted fw-bold">#${cm.commentId}</td>
                                    <td class="fw-bold text-white">${cm.username}</td>
                                    <td class="small text-muted text-truncate" style="max-width: 180px;">${cm.videoTitle}</td>
                                    <td><span class="text-light">${cm.content}</span></td>
                                    <td class="small text-muted">${cm.createdAt}</td>
                                    <td class="text-end">
                                        <form action="${pageContext.request.contextPath}/admin/comments/delete" method="POST" class="d-inline" onsubmit="return confirm('Delete comment?');">
                                            <input type="hidden" name="commentId" value="${cm.commentId}">
                                            <button type="submit" class="btn btn-outline-danger btn-sm rounded-pill px-3">
                                                <i class="fas fa-trash-alt me-1"></i> Remove
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            </c:forEach>
                            <c:if test="${empty allComments}">
                                <tr><td colspan="6" class="text-center py-4 text-muted">No comments posted yet.</td></tr>
                            </c:if>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ==========================================
             TAB 5: AD CAMPAIGNS & NOTIFICATIONS (MEMBER 5)
             ========================================== -->
        <div class="tab-pane fade ${param.tab == 'ads' ? 'show active' : ''}" id="ads-pane">
            <div class="card bg-dark border-secondary rounded-4 shadow overflow-hidden">
                <div class="card-header bg-black border-secondary py-3 d-flex justify-content-between align-items-center">
                    <h5 class="fw-bold mb-0 text-white"><i class="fas fa-bullhorn text-warning me-2"></i> Advertising Campaigns (Member 5 - Thilakarathna)</h5>
                    <button class="btn btn-warning btn-sm rounded-pill px-3 fw-bold" data-bs-toggle="modal" data-bs-target="#createAdModal">
                        <i class="fas fa-plus me-1"></i> Create Campaign
                    </button>
                </div>
                <div class="table-responsive">
                    <table class="table table-dark table-hover mb-0 align-middle">
                        <thead>
                            <tr class="text-muted small border-secondary">
                                <th>ID</th>
                                <th>Title</th>
                                <th>Placement</th>
                                <th>Schedule</th>
                                <th>Impressions / Clicks</th>
                                <th>Status</th>
                                <th class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach var="ad" items="${adList}">
                                <tr>
                                    <td class="text-muted fw-bold">#${ad.adId}</td>
                                    <td class="fw-bold text-white">${ad.title}</td>
                                    <td><span class="badge bg-secondary">${ad.adType}</span></td>
                                    <td class="small text-muted">${ad.startDate} to ${ad.endDate}</td>
                                    <td class="small text-muted">${ad.impressions} imp • ${ad.clicks} clicks</td>
                                    <td><span class="badge ${ad.status == 'ACTIVE' ? 'bg-success' : 'bg-secondary'}">${ad.status}</span></td>
                                    <td class="text-end">
                                        <div class="btn-group">
                                            <form action="${pageContext.request.contextPath}/admin/ads/status" method="POST" class="d-inline">
                                                <input type="hidden" name="adId" value="${ad.adId}">
                                                <button type="submit" name="status" value="${ad.status == 'ACTIVE' ? 'PAUSED' : 'ACTIVE'}" class="btn btn-outline-warning btn-sm">
                                                    ${ad.status == 'ACTIVE' ? 'Pause' : 'Activate'}
                                                </button>
                                            </form>
                                            <form action="${pageContext.request.contextPath}/admin/ads/delete" method="POST" class="d-inline" onsubmit="return confirm('Delete ad?');">
                                                <input type="hidden" name="adId" value="${ad.adId}">
                                                <button type="submit" class="btn btn-outline-danger btn-sm"><i class="fas fa-trash-alt"></i></button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ==========================================
             TAB 6: SAFETY & MODERATION QUEUE (MEMBER 6)
             ========================================== -->
        <div class="tab-pane fade ${param.tab == 'moderation' ? 'show active' : ''}" id="moderation-pane">
            <div class="card bg-dark border-secondary rounded-4 shadow overflow-hidden">
                <div class="card-header bg-black border-secondary py-3">
                    <h5 class="fw-bold mb-0 text-white"><i class="fas fa-shield-alt text-danger me-2"></i> Safety & Moderation Queue (UC-06: Member 6)</h5>
                </div>
                <div class="table-responsive">
                    <table class="table table-dark table-hover mb-0 align-middle">
                        <thead>
                            <tr class="text-muted small border-secondary">
                                <th>Report ID</th>
                                <th>Reporter</th>
                                <th>Target</th>
                                <th>Reason</th>
                                <th>Description</th>
                                <th class="text-end">Decision</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach var="r" items="${pendingReports}">
                                <tr>
                                    <td class="text-muted fw-bold">#${r.reportId}</td>
                                    <td class="fw-bold text-primary">${r.reporterUsername}</td>
                                    <td><span class="badge ${r.targetType == 'COMMENT' ? 'bg-secondary' : 'bg-info text-dark'}">${r.targetType} #${r.targetId}</span></td>
                                    <td><span class="text-danger fw-bold">${r.reason}</span></td>
                                    <td class="small text-muted">${r.description}</td>
                                    <td class="text-end">
                                        <form action="${pageContext.request.contextPath}/admin/moderation/resolve" method="POST" class="d-inline-flex gap-2">
                                            <input type="hidden" name="reportId" value="${r.reportId}">
                                            <input type="hidden" name="targetType" value="${r.targetType}">
                                            <input type="hidden" name="targetId" value="${r.targetId}">
                                            <button type="submit" name="action" value="APPROVE_PENALTY" class="btn btn-danger btn-sm rounded-pill px-3">
                                                Penalize & Remove
                                            </button>
                                            <button type="submit" name="action" value="DISMISS" class="btn btn-outline-secondary btn-sm rounded-pill px-3">
                                                Dismiss
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            </c:forEach>
                            <c:if test="${empty pendingReports}">
                                <tr><td colspan="6" class="text-center py-4 text-muted">All reports resolved! Moderation queue is clean.</td></tr>
                            </c:if>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ==========================================
             TAB 7: USER ACCOUNTS & ROLES (MEMBER 1)
             ========================================== -->
        <div class="tab-pane fade ${param.tab == 'users' ? 'show active' : ''}" id="users-pane">
            <div class="card bg-dark border-secondary rounded-4 shadow overflow-hidden">
                <div class="card-header bg-black border-secondary py-3 d-flex justify-content-between align-items-center">
                    <h5 class="fw-bold mb-0 text-white"><i class="fas fa-users text-primary me-2"></i> User Access & Identity Administration (Member 1)</h5>
                    <button class="btn btn-primary btn-sm rounded-pill px-3 fw-bold" data-bs-toggle="modal" data-bs-target="#createUserModal">
                        <i class="fas fa-user-plus me-1"></i> Add User
                    </button>
                </div>
                <div class="table-responsive">
                    <table class="table table-dark table-hover mb-0 align-middle">
                        <thead>
                            <tr class="text-muted small border-secondary">
                                <th>ID</th>
                                <th>Display Name</th>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Current Role</th>
                                <th>Change Role</th>
                                <th class="text-end">Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach var="u" items="${userList}">
                                <tr>
                                    <td>#${u.userId}</td>
                                    <td class="fw-bold text-white">${u.displayName}</td>
                                    <td class="text-muted">${u.username}</td>
                                    <td class="small text-muted">${u.email}</td>
                                    <td>
                                        <span class="badge ${u.role == 'ADMIN' ? 'bg-danger' : (u.role == 'CONTENT_MANAGER' ? 'bg-warning text-dark' : 'bg-secondary')}">
                                            ${u.role}
                                        </span>
                                    </td>
                                    <td>
                                        <form action="${pageContext.request.contextPath}/admin/users/update-role" method="POST" class="d-inline-flex gap-1 m-0">
                                            <input type="hidden" name="userId" value="${u.userId}">
                                            <select class="form-select form-select-sm bg-dark text-white border-secondary" name="newRole" style="width: 140px;">
                                                <option value="REGISTERED" ${u.role == 'REGISTERED' ? 'selected' : ''}>REGISTERED</option>
                                                <option value="CONTENT_MANAGER" ${u.role == 'CONTENT_MANAGER' ? 'selected' : ''}>CONTENT_MANAGER</option>
                                                <option value="ADVERTISER" ${u.role == 'ADVERTISER' ? 'selected' : ''}>ADVERTISER</option>
                                                <option value="ADMIN" ${u.role == 'ADMIN' ? 'selected' : ''}>ADMIN</option>
                                            </select>
                                            <button type="submit" class="btn btn-outline-primary btn-sm rounded-pill px-2">Save</button>
                                        </form>
                                    </td>
                                    <td class="text-end">
                                        <form action="${pageContext.request.contextPath}/admin/users/delete" method="POST" class="d-inline" onsubmit="return confirm('Delete user ${u.username}?');">
                                            <input type="hidden" name="userId" value="${u.userId}">
                                            <button type="submit" class="btn btn-outline-danger btn-sm"><i class="fas fa-trash-alt"></i></button>
                                        </form>
                                    </td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
</div>

<!-- ==========================================
     MODALS FOR MEMBER 1, 2, 3, 5 CREATIONS
     ========================================== -->

<!-- Modal: Add User (Member 1) -->
<div class="modal fade" id="createUserModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content bg-dark border-secondary text-white rounded-4">
            <div class="modal-header bg-black border-secondary">
                <h5 class="modal-title fw-bold"><i class="fas fa-user-plus text-primary me-2"></i> Add New User Account</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="${pageContext.request.contextPath}/admin/users/create" method="POST">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label small text-muted">Username *</label>
                        <input type="text" name="username" class="form-control bg-black text-white border-secondary" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small text-muted">Email Address *</label>
                        <input type="email" name="email" class="form-control bg-black text-white border-secondary" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small text-muted">Display Name *</label>
                        <input type="text" name="displayName" class="form-control bg-black text-white border-secondary" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small text-muted">Initial Password *</label>
                        <input type="password" name="password" class="form-control bg-black text-white border-secondary" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small text-muted">Role *</label>
                        <select name="role" class="form-select bg-black text-white border-secondary">
                            <option value="REGISTERED">REGISTERED</option>
                            <option value="CONTENT_MANAGER">CONTENT_MANAGER</option>
                            <option value="ADVERTISER">ADVERTISER</option>
                            <option value="ADMIN">ADMIN</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer bg-black border-secondary">
                    <button type="button" class="btn btn-outline-secondary rounded-pill px-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-4 fw-bold">Create User</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal: Add Category (Member 2) -->
<div class="modal fade" id="createCategoryModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content bg-dark border-secondary text-white rounded-4">
            <div class="modal-header bg-black border-secondary">
                <h5 class="modal-title fw-bold"><i class="fas fa-folder-plus text-primary me-2"></i> Add Sport Category</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="${pageContext.request.contextPath}/admin/categories/create" method="POST">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label small text-muted">Category / Sport Name *</label>
                        <input type="text" name="name" class="form-control bg-black text-white border-secondary" placeholder="e.g. Badminton" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small text-muted">Description</label>
                        <textarea name="description" class="form-control bg-black text-white border-secondary" rows="2"></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small text-muted">Font Awesome Icon Class</label>
                        <input type="text" name="iconClass" class="form-control bg-black text-white border-secondary" placeholder="fas fa-table-tennis" value="fas fa-trophy">
                    </div>
                </div>
                <div class="modal-footer bg-black border-secondary">
                    <button type="button" class="btn btn-outline-secondary rounded-pill px-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-4 fw-bold">Save Category</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal: Add Team (Member 2) -->
<div class="modal fade" id="createTeamModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content bg-dark border-secondary text-white rounded-4">
            <div class="modal-header bg-black border-secondary">
                <h5 class="modal-title fw-bold"><i class="fas fa-shield-alt text-info me-2"></i> Add Sports Team</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="${pageContext.request.contextPath}/admin/teams/create" method="POST">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label small text-muted">Team / Club Name *</label>
                        <input type="text" name="name" class="form-control bg-black text-white border-secondary" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small text-muted">Category / Sport *</label>
                        <select name="categoryId" class="form-select bg-black text-white border-secondary" required>
                            <c:forEach var="c" items="${categories}">
                                <option value="${c.categoryId}">${c.name}</option>
                            </c:forEach>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small text-muted">Country</label>
                        <input type="text" name="country" class="form-control bg-black text-white border-secondary" value="Sri Lanka">
                    </div>
                    <div class="mb-3">
                        <label class="form-label small text-muted">Logo URL</label>
                        <input type="url" name="logoUrl" class="form-control bg-black text-white border-secondary" placeholder="https://...">
                    </div>
                </div>
                <div class="modal-footer bg-black border-secondary">
                    <button type="button" class="btn btn-outline-secondary rounded-pill px-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-info rounded-pill px-4 fw-bold text-dark">Save Team</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal: Create Ad Campaign (Member 5) -->
<div class="modal fade" id="createAdModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content bg-dark border-secondary text-white rounded-4">
            <div class="modal-header bg-black border-secondary">
                <h5 class="modal-title fw-bold"><i class="fas fa-bullhorn text-warning me-2"></i> Create Ad Campaign</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="${pageContext.request.contextPath}/admin/ads/create" method="POST">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label small text-muted">Campaign Title *</label>
                        <input type="text" name="title" class="form-control bg-black text-white border-secondary" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small text-muted">Placement Type *</label>
                        <select name="adType" class="form-select bg-black text-white border-secondary">
                            <option value="BANNER">Top / Mid Banner</option>
                            <option value="SIDEBAR">Sidebar Ad Card</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small text-muted">Banner Image URL *</label>
                        <input type="url" name="imageUrl" class="form-control bg-black text-white border-secondary" placeholder="https://..." required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small text-muted">Target Destination URL *</label>
                        <input type="url" name="targetUrl" class="form-control bg-black text-white border-secondary" placeholder="https://..." required>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label small text-muted">Start Date *</label>
                            <input type="date" name="startDate" class="form-control bg-black text-white border-secondary" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label small text-muted">End Date *</label>
                            <input type="date" name="endDate" class="form-control bg-black text-white border-secondary" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small text-muted">Display Priority (1-10)</label>
                        <input type="number" name="priority" class="form-control bg-black text-white border-secondary" value="1" min="1" max="10">
                    </div>
                </div>
                <div class="modal-footer bg-black border-secondary">
                    <button type="button" class="btn btn-outline-secondary rounded-pill px-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-warning rounded-pill px-4 fw-bold">Publish Campaign</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal: Create Sporting Event (Member 3) -->
<div class="modal fade" id="createEventModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content bg-dark border-secondary text-white rounded-4 shadow-lg">
            <div class="modal-header border-secondary bg-black py-3">
                <h5 class="modal-title fw-bold"><i class="fas fa-calendar-plus text-primary me-2"></i> Schedule Sporting Event / Match Fixture</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="${pageContext.request.contextPath}/admin/events/create" method="POST">
                <div class="modal-body p-4">
                    <div class="row g-3">
                        <div class="col-md-8">
                            <label class="form-label small text-muted">Event / Match Title *</label>
                            <input type="text" name="title" class="form-control bg-black text-white border-secondary" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small text-muted">Sport / Category *</label>
                            <select name="categoryId" class="form-select bg-black text-white border-secondary" required>
                                <c:forEach var="c" items="${categories}">
                                    <option value="${c.categoryId}">${c.name}</option>
                                </c:forEach>
                            </select>
                        </div>
                        <div class="col-md-12">
                            <label class="form-label small text-muted">Tournament Name *</label>
                            <input type="text" name="tournamentName" class="form-control bg-black text-white border-secondary" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small text-muted">Team 1 (Home) *</label>
                            <select name="team1Id" class="form-select bg-black text-white border-secondary" required>
                                <c:forEach var="t" items="${teams}">
                                    <option value="${t.teamId}">${t.name}</option>
                                </c:forEach>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small text-muted">Team 2 (Away) *</label>
                            <select name="team2Id" class="form-select bg-black text-white border-secondary" required>
                                <c:forEach var="t" items="${teams}">
                                    <option value="${t.teamId}">${t.name}</option>
                                </c:forEach>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small text-muted">Event Date *</label>
                            <input type="date" name="eventDate" class="form-control bg-black text-white border-secondary" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small text-muted">Event Time *</label>
                            <input type="text" name="eventTime" class="form-control bg-black text-white border-secondary" placeholder="19:30 IST" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small text-muted">Status *</label>
                            <select name="status" class="form-select bg-black text-white border-secondary">
                                <option value="UPCOMING">UPCOMING</option>
                                <option value="LIVE">LIVE NOW</option>
                                <option value="COMPLETED">COMPLETED</option>
                            </select>
                        </div>
                        <div class="col-md-12">
                            <label class="form-label small text-muted">Venue *</label>
                            <input type="text" name="venue" class="form-control bg-black text-white border-secondary" required>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-secondary bg-black">
                    <button type="button" class="btn btn-outline-secondary rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-4 fw-bold">Save Fixture</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal: Quick Score Update -->
<div class="modal fade" id="quickScoreModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content bg-dark border-secondary text-white rounded-4 shadow-lg">
            <div class="modal-header border-secondary bg-black py-3">
                <h5 class="modal-title fw-bold text-warning"><i class="fas fa-broadcast-tower me-2"></i> Live Score Desk</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="${pageContext.request.contextPath}/admin/events/update-score" method="POST">
                <input type="hidden" name="eventId" id="scoreModalEventId">
                <div class="modal-body p-4">
                    <div class="text-center mb-3">
                        <h6 class="fw-bold text-white mb-1" id="scoreModalMatchTitle">Match Title</h6>
                    </div>
                    <div class="row g-3 mb-3">
                        <div class="col-6">
                            <label class="form-label small text-muted" id="scoreModalT1Label">Team 1 Score</label>
                            <input type="text" name="team1Score" id="scoreModalT1Score" class="form-control bg-black text-white border-secondary font-monospace text-center fs-5">
                        </div>
                        <div class="col-6">
                            <label class="form-label small text-muted" id="scoreModalT2Label">Team 2 Score</label>
                            <input type="text" name="team2Score" id="scoreModalT2Score" class="form-control bg-black text-white border-secondary font-monospace text-center fs-5">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small text-muted">Status</label>
                        <select name="status" id="scoreModalStatus" class="form-select bg-black text-white border-secondary">
                            <option value="UPCOMING">UPCOMING</option>
                            <option value="LIVE">LIVE NOW</option>
                            <option value="COMPLETED">COMPLETED</option>
                        </select>
                    </div>
                    <div class="mb-2">
                        <label class="form-label small text-muted">Match Summary</label>
                        <textarea name="matchSummary" id="scoreModalSummary" rows="2" class="form-control bg-black text-white border-secondary"></textarea>
                    </div>
                </div>
                <div class="modal-footer border-secondary bg-black">
                    <button type="button" class="btn btn-outline-secondary rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-warning rounded-pill px-4 fw-bold">Update Live Score</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function openScoreModal(eventId, title, t1Name, t2Name, t1Score, t2Score, status, summary) {
    document.getElementById('scoreModalEventId').value = eventId;
    document.getElementById('scoreModalMatchTitle').textContent = title;
    document.getElementById('scoreModalT1Label').textContent = t1Name + ' Score';
    document.getElementById('scoreModalT2Label').textContent = t2Name + ' Score';
    document.getElementById('scoreModalT1Score').value = t1Score || '';
    document.getElementById('scoreModalT2Score').value = t2Score || '';
    document.getElementById('scoreModalStatus').value = status;
    document.getElementById('scoreModalSummary').value = summary || '';
    new bootstrap.Modal(document.getElementById('quickScoreModal')).show();
}
</script>

<jsp:include page="/WEB-INF/views/common/footer.jsp" />
