<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<jsp:include page="/WEB-INF/views/common/header.jsp">
    <jsp:param name="pageTitle" value="Moderation Queue - Sportix" />
</jsp:include>
<jsp:include page="/WEB-INF/views/common/navbar.jsp" />

<div class="container my-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold mb-0"><i class="fas fa-shield-alt text-warning me-2"></i> Moderation & Safety Queue</h3>
            <p class="text-muted small mb-0">UC-06: Review flagged reports, take punitive actions or dismiss invalid reports</p>
        </div>
        <a href="${pageContext.request.contextPath}/admin/dashboard" class="btn btn-outline-secondary rounded-pill px-3">
            <i class="fas fa-arrow-left me-1"></i> Admin Dashboard
        </a>
    </div>

    <c:if test="${param.success == 'true'}">
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i> Report resolved successfully. Moderation action logged to audit trail.
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    </c:if>

    <div class="card bg-dark border-secondary rounded-4 shadow overflow-hidden">
        <div class="card-header bg-black border-secondary py-3 d-flex justify-content-between align-items-center">
            <h5 class="fw-bold mb-0">Pending Content Reports (${pendingReports.size()})</h5>
            <span class="badge bg-warning text-dark">Awaiting Action</span>
        </div>
        <div class="table-responsive">
            <table class="table table-dark table-hover mb-0 align-middle">
                <thead>
                    <tr class="text-muted small">
                        <th>Report ID</th>
                        <th>Reporter</th>
                        <th>Target Type</th>
                        <th>Target ID</th>
                        <th>Reason</th>
                        <th>Details</th>
                        <th>Reported At</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <c:forEach var="r" items="${pendingReports}">
                        <tr>
                            <td>#${r.reportId}</td>
                            <td><span class="fw-bold text-primary">${r.reporterUsername}</span></td>
                            <td>
                                <span class="badge ${r.targetType == 'VIDEO' ? 'bg-info text-dark' : 'bg-secondary'}">
                                    ${r.targetType}
                                </span>
                            </td>
                            <td>ID: ${r.targetId}</td>
                            <td><span class="text-danger fw-bold">${r.reason}</span></td>
                            <td class="small text-muted" style="max-width: 250px;">
                                ${not empty r.description ? r.description : "No additional comments provided."}
                            </td>
                            <td class="small text-muted">${r.createdAt}</td>
                            <td>
                                <div class="d-flex gap-2">
                                    <!-- Approve Penalty (Hides content) -->
                                    <form action="${pageContext.request.contextPath}/admin/moderation/resolve" method="POST" class="m-0" 
                                          onsubmit="return confirm('Confirm take-down action against this content?');">
                                        <input type="hidden" name="reportId" value="${r.reportId}">
                                        <input type="hidden" name="targetType" value="${r.targetType}">
                                        <input type="hidden" name="targetId" value="${r.targetId}">
                                        <input type="hidden" name="action" value="APPROVE_PENALTY">
                                        <input type="hidden" name="adminNotes" value="Violates community safety guidelines. Content removed.">
                                        <button type="submit" class="btn btn-danger btn-sm rounded-pill px-3" title="Take down reported item">
                                            <i class="fas fa-ban me-1"></i> Remove Content
                                        </button>
                                    </form>

                                    <!-- Dismiss Report -->
                                    <form action="${pageContext.request.contextPath}/admin/moderation/resolve" method="POST" class="m-0">
                                        <input type="hidden" name="reportId" value="${r.reportId}">
                                        <input type="hidden" name="targetType" value="${r.targetType}">
                                        <input type="hidden" name="targetId" value="${r.targetId}">
                                        <input type="hidden" name="action" value="DISMISS">
                                        <input type="hidden" name="adminNotes" value="False report; content is compliant.">
                                        <button type="submit" class="btn btn-outline-secondary btn-sm rounded-pill px-3" title="Dismiss without action">
                                            <i class="fas fa-check me-1"></i> Dismiss
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    </c:forEach>
                    <c:if test="${empty pendingReports}">
                        <tr>
                            <td colspan="8" class="text-center py-5 text-muted">
                                <i class="fas fa-check-double text-success fa-2x mb-2 d-block"></i>
                                All clear! The moderation queue has no pending items.
                            </td>
                        </tr>
                    </c:if>
                </tbody>
            </table>
        </div>
    </div>
</div>

<jsp:include page="/WEB-INF/views/common/footer.jsp" />
