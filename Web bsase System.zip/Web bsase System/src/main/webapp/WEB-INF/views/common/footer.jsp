<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>

<footer>
    <div class="container text-center">
        <div class="row align-items-center">
            <div class="col-md-4 text-md-start mb-2 mb-md-0">
                <span class="fw-bold text-light"><i class="fas fa-play-circle text-primary"></i> SPORTIX</span> &copy; 2026. All Rights Reserved.
            </div>
            <div class="col-md-4 mb-2 mb-md-0">
                <span class="badge bg-secondary">SE2030 Software Engineering Project</span>
                <span class="badge bg-dark border border-secondary ms-1">Group: 2026-Y2-S1-MTR-15</span>
            </div>
            <div class="col-md-4 text-md-end text-muted small">
                Engineered for SLIIT SE2030 Enterprise Standards.
            </div>
        </div>
    </div>
</footer>

<!-- Bootstrap 5 Bundle JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Custom JS -->
<script src="${pageContext.request.contextPath}/assets/js/main.js"></script>
</body>
</html>
