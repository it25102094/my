<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<nav class="navbar navbar-expand-lg navbar-dark navbar-custom">
    <div class="container-fluid px-lg-4">
        <!-- Brand Logo with Lime Dot -->
        <a class="navbar-brand brand-logo me-4" href="${pageContext.request.contextPath}/home">
            SPORTIX<span class="dot">.</span>
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#topNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="topNav">
            <!-- Navigation Links -->
            <ul class="navbar-nav me-auto mb-2 mb-lg-0 align-items-center gap-1">
                <li class="nav-item">
                    <a class="nav-link nav-link-custom ${empty param.type && empty param.q ? 'active' : ''}" href="${pageContext.request.contextPath}/home">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link nav-link-custom ${param.type == 'LIVE' ? 'active' : ''}" href="${pageContext.request.contextPath}/search?type=LIVE">Live</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link nav-link-custom ${param.type == 'HIGHLIGHT' ? 'active' : ''}" href="${pageContext.request.contextPath}/search?type=HIGHLIGHT">Highlights</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link nav-link-custom ${param.type == 'SHORT' ? 'active' : ''}" href="${pageContext.request.contextPath}/search?type=SHORT">Shorts</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link nav-link-custom dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        Sports
                    </a>
                    <ul class="dropdown-menu dropdown-menu-dark">
                        <li><a class="dropdown-item" href="${pageContext.request.contextPath}/search?category=1">Cricket</a></li>
                        <li><a class="dropdown-item" href="${pageContext.request.contextPath}/search?category=2">Football</a></li>
                        <li><a class="dropdown-item" href="${pageContext.request.contextPath}/search?category=3">Basketball</a></li>
                    </ul>
                </li>
            </ul>

            <!-- Search Bar -->
            <form class="search-box-wrap mx-auto" action="${pageContext.request.contextPath}/search" method="GET">
                <div class="search-bar-inner">
                    <i class="fas fa-search search-icon"></i>
                    <input class="form-control search-input-custom" type="search" name="q" 
                           placeholder="Search for a team, player or tournament..." value="${param.q}">
                </div>
            </form>

            <!-- Right Controls -->
            <div class="d-flex align-items-center gap-4 ms-auto mt-2 mt-lg-0">
                <!-- Spoiler-Free Mode Toggle -->
                <div class="spoiler-switch" title="Toggle score visibility">
                    <span>Spoiler-Free Mode</span>
                    <div class="form-check form-switch m-0">
                        <input class="form-check-input" type="checkbox" id="spoilerFreeToggle">
                    </div>
                </div>

                <!-- Notifications -->
                <c:choose>
                    <c:when test="${not empty sessionScope.currentUser}">
                        <a href="${pageContext.request.contextPath}/notifications" class="btn-notification" title="Notifications">
                            <i class="far fa-bell"></i>
                            <c:if test="${sessionScope.unreadNotifications > 0}">
                                <span class="badge-dot"></span>
                            </c:if>
                        </a>
                    </c:when>
                    <c:otherwise>
                        <a href="${pageContext.request.contextPath}/login" class="btn-notification">
                            <i class="far fa-bell"></i>
                        </a>
                    </c:otherwise>
                </c:choose>

                <!-- User Profile / Auth -->
                <c:choose>
                    <c:when test="${not empty sessionScope.currentUser}">
                        <div class="dropdown">
                            <div class="user-avatar-badge dropdown-toggle" role="button" data-bs-toggle="dropdown">
                                <div class="avatar-circle">
                                    ${sessionScope.currentUser.displayName.substring(0, 2).toUpperCase()}
                                </div>
                                <span class="d-none d-md-inline">Hello, ${sessionScope.currentUser.displayName}</span>
                            </div>
                            <ul class="dropdown-menu dropdown-menu-end dropdown-menu-dark">
                                <li><a class="dropdown-item" href="${pageContext.request.contextPath}/profile"><i class="fas fa-user me-2"></i>My Profile & Teams</a></li>
                                <li><a class="dropdown-item" href="${pageContext.request.contextPath}/watch-later"><i class="fas fa-bookmark me-2"></i>Watch Later</a></li>
                                <c:if test="${sessionScope.currentUser.contentManager || sessionScope.currentUser.admin}">
                                    <li><a class="dropdown-item" href="${pageContext.request.contextPath}/add-video"><i class="fas fa-cloud-upload-alt me-2"></i>Publish Video</a></li>
                                    <li><a class="dropdown-item" href="${pageContext.request.contextPath}/manage-videos"><i class="fas fa-video me-2"></i>Manage Video Catalog</a></li>
                                </c:if>
                                <c:if test="${sessionScope.currentUser.advertiser || sessionScope.currentUser.admin}">
                                    <li><a class="dropdown-item" href="${pageContext.request.contextPath}/ads"><i class="fas fa-bullhorn me-2"></i>Ad Campaigns</a></li>
                                </c:if>
                                <c:if test="${sessionScope.currentUser.admin}">
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item" href="${pageContext.request.contextPath}/admin/dashboard"><i class="fas fa-chart-line me-2"></i>Admin Dashboard</a></li>
                                    <li><a class="dropdown-item" href="${pageContext.request.contextPath}/admin/moderation"><i class="fas fa-shield-alt me-2"></i>Moderation Queue</a></li>
                                </c:if>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item text-danger" href="${pageContext.request.contextPath}/logout"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                            </ul>
                        </div>
                    </c:when>
                    <c:otherwise>
                        <div class="d-flex align-items-center gap-2">
                            <a href="${pageContext.request.contextPath}/login" class="btn btn-sm btn-outline-light rounded-pill px-3">Log In</a>
                            <a href="${pageContext.request.contextPath}/register" class="btn btn-sm btn-sportix-primary px-3">Sign Up</a>
                        </div>
                    </c:otherwise>
                </c:choose>
            </div>
        </div>
    </div>
</nav>
