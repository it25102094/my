<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<jsp:include page="/WEB-INF/views/common/header.jsp">
    <jsp:param name="pageTitle" value="Edit Video Details - Sportix" />
</jsp:include>
<jsp:include page="/WEB-INF/views/common/navbar.jsp" />

<div class="container my-5" style="max-width: 800px;">
    <div class="card bg-dark border-secondary p-4 rounded-4 shadow-lg">
        <h3 class="fw-bold mb-3"><i class="fas fa-edit text-primary me-2"></i> Edit Video Details</h3>

        <form action="${pageContext.request.contextPath}/video/edit" method="POST">
            <input type="hidden" name="videoId" value="${video.videoId}">

            <div class="mb-3">
                <label class="form-label fw-bold small">YouTube Video URL <span class="text-danger">*</span></label>
                <input type="url" class="form-control bg-dark text-white border-secondary" id="youtubeUrlInput" name="youtubeUrl" 
                       value="${video.youtubeUrl}" required>
            </div>

            <div class="mb-3">
                <label class="form-label fw-bold small">Video Title <span class="text-danger">*</span></label>
                <input type="text" class="form-control bg-dark text-white border-secondary" name="title" 
                       value="${video.title}" required>
            </div>

            <div class="row g-3 mb-3">
                <div class="col-md-6">
                    <label class="form-label fw-bold small">Sport Category <span class="text-danger">*</span></label>
                    <select class="form-select bg-dark text-white border-secondary" name="categoryId" required>
                        <c:forEach var="c" items="${categories}">
                            <option value="${c.categoryId}" ${video.categoryId == c.categoryId ? 'selected' : ''}>${c.name}</option>
                        </c:forEach>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-bold small">Team Association</label>
                    <select class="form-select bg-dark text-white border-secondary" name="teamId">
                        <option value="0">None / Neutral Match</option>
                        <c:forEach var="t" items="${teams}">
                            <option value="${t.teamId}" ${video.teamId == t.teamId ? 'selected' : ''}>${t.name}</option>
                        </c:forEach>
                    </select>
                </div>
            </div>

            <div class="row g-3 mb-3">
                <div class="col-md-6">
                    <label class="form-label fw-bold small">Content Format <span class="text-danger">*</span></label>
                    <select class="form-select bg-dark text-white border-secondary" name="videoType">
                        <option value="HIGHLIGHT" ${video.videoType == 'HIGHLIGHT' ? 'selected' : ''}>Match Highlight</option>
                        <option value="SHORT" ${video.videoType == 'SHORT' ? 'selected' : ''}>Vertical Short</option>
                        <option value="LIVE" ${video.videoType == 'LIVE' ? 'selected' : ''}>Live Match</option>
                        <option value="INTERVIEW" ${video.videoType == 'INTERVIEW' ? 'selected' : ''}>Interview</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-bold small">Match Final Score</label>
                    <input type="text" class="form-control bg-dark text-white border-secondary" name="matchScore" 
                           value="${video.matchScore}" placeholder="e.g. Real Madrid 3 - 2 Barcelona">
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label fw-bold small">Description</label>
                <textarea class="form-control bg-dark text-white border-secondary" name="description" rows="3">${video.description}</textarea>
            </div>

            <div class="card bg-black border-secondary p-3 mb-4 rounded-3">
                <div class="form-check form-switch mb-2">
                    <input class="form-check-input" type="checkbox" id="isFeaturedCheck" name="isFeatured" value="true" 
                           ${video.featured ? 'checked' : ''}
                           onchange="document.getElementById('featuredDatesSection').style.display = this.checked ? 'flex' : 'none';">
                    <label class="form-check-label fw-bold text-warning small" for="isFeaturedCheck">
                        Mark as Featured Video on Homepage
                    </label>
                </div>
                <div id="featuredDatesSection" class="row g-2 mt-2" style="display: ${video.featured ? 'flex' : 'none'};">
                    <div class="col-md-6">
                        <label class="form-label small text-muted">Featured Start Date:</label>
                        <input type="date" class="form-control bg-dark text-white border-secondary form-control-sm" 
                               name="featuredStartDate" value="${video.featuredStartDate}">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small text-muted">Featured End Date:</label>
                        <input type="date" class="form-control bg-dark text-white border-secondary form-control-sm" 
                               name="featuredEndDate" value="${video.featuredEndDate}">
                    </div>
                </div>
            </div>

            <div class="d-flex justify-content-end gap-2">
                <a href="${pageContext.request.contextPath}/manage-videos" class="btn btn-outline-secondary rounded-pill px-4">Cancel</a>
                <button type="submit" class="btn btn-primary rounded-pill px-5 fw-bold">Update Video</button>
            </div>
        </form>
    </div>
</div>

<jsp:include page="/WEB-INF/views/common/footer.jsp" />
