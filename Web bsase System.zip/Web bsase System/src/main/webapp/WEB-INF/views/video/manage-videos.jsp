<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<jsp:include page="/WEB-INF/views/common/header.jsp">
    <jsp:param name="pageTitle" value="Manage Sports Content - Sportix" />
</jsp:include>
<jsp:include page="/WEB-INF/views/common/navbar.jsp" />

<div class="container my-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold mb-0"><i class="fas fa-video text-primary me-2"></i> Content Manager - Video Catalog</h3>
            <p class="text-muted small mb-0">Member 3: Edit, delete, classify, and manage featured sports videos</p>
        </div>
        <a href="${pageContext.request.contextPath}/add-video" class="btn btn-primary rounded-pill px-4">
            <i class="fas fa-plus me-1"></i> Add New Video
        </a>
    </div>

    <c:if test="${param.deleted == 'true'}">
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i> Video successfully deleted.
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    </c:if>
    <c:if test="${param.updated == 'true'}">
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i> Video details updated successfully.
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    </c:if>

    <div class="card bg-dark border-secondary rounded-4 shadow overflow-hidden">
        <div class="table-responsive">
            <table class="table table-dark table-hover mb-0 align-middle">
                <thead>
                    <tr class="text-muted small">
                        <th>Thumbnail</th>
                        <th>Title & Match Score</th>
                        <th>Category</th>
                        <th>Format</th>
                        <th>Featured</th>
                        <th>Views</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <c:forEach var="v" items="${videos}">
                        <tr>
                            <td>
                                <img src="${v.thumbnailUrl}" alt="${v.title}" class="rounded-2" style="width: 80px; height: 45px; object-fit: cover;">
                            </td>
                            <td>
                                <div class="fw-bold">${v.title}</div>
                                <c:if test="${not empty v.matchScore}">
                                    <span class="badge bg-secondary small">${v.matchScore}</span>
                                </c:if>
                            </td>
                            <td>${v.categoryName}</td>
                            <td><span class="badge bg-primary">${v.videoType}</span></td>
                            <td>
                                <c:choose>
                                    <c:when test="${v.featured}"><span class="badge bg-warning text-dark"><i class="fas fa-star me-1"></i> Featured</span></c:when>
                                    <c:otherwise><span class="text-muted small">Standard</span></c:otherwise>
                                </c:choose>
                            </td>
                            <td class="small text-muted">${v.viewCount}</td>
                            <td>
                                <div class="d-flex gap-2">
                                    <a href="${pageContext.request.contextPath}/video/edit?id=${v.videoId}" class="btn btn-outline-info btn-sm rounded-circle" title="Edit Video">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <form action="${pageContext.request.contextPath}/video/delete" method="POST" class="m-0" onsubmit="return confirm('Delete this video from the system?');">
                                        <input type="hidden" name="videoId" value="${v.videoId}">
                                        <button type="submit" class="btn btn-outline-danger btn-sm rounded-circle" title="Delete Video">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    </c:forEach>
                </tbody>
            </table>
        </div>
    </div>
</div>

<jsp:include page="/WEB-INF/views/common/footer.jsp" />
