<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<jsp:include page="/WEB-INF/views/common/header.jsp">
    <jsp:param name="pageTitle" value="Search Results - SPORTIX" />
</jsp:include>
<jsp:include page="/WEB-INF/views/common/navbar.jsp" />

<div class="container-fluid px-lg-4 my-4">
    <div class="search-results-grid-layout">
        <!-- LEFT FILTER SIDEBAR (Screenshot 2) -->
        <div class="search-filter-sidebar">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="fw-bold text-white mb-0">Filters</h5>
                <a href="${pageContext.request.contextPath}/search" class="text-success small fw-bold">Clear All</a>
            </div>

            <form action="${pageContext.request.contextPath}/search" method="GET" id="searchFilterForm">
                <input type="hidden" name="q" value="${query}">

                <div class="filter-section-title">Sport</div>
                <c:forEach var="cat" items="${categories}">
                    <label class="filter-checkbox-item">
                        <div>
                            <input type="checkbox" name="category" value="${cat.categoryId}" class="form-check-input me-2"
                                   ${selectedCategory == cat.categoryId ? 'checked' : ''} onchange="this.form.submit()">
                            <span>${cat.name}</span>
                        </div>
                    </label>
                </c:forEach>

                <div class="filter-section-title">Content Type</div>
                <label class="filter-checkbox-item">
                    <div>
                        <input type="radio" name="type" value="ALL" class="form-check-input me-2" 
                               ${empty selectedType || selectedType == 'ALL' ? 'checked' : ''} onchange="this.form.submit()">
                        <span>All</span>
                    </div>
                </label>
                <label class="filter-checkbox-item">
                    <div>
                        <input type="radio" name="type" value="LIVE" class="form-check-input me-2" 
                               ${selectedType == 'LIVE' ? 'checked' : ''} onchange="this.form.submit()">
                        <span>Live</span>
                    </div>
                </label>
                <label class="filter-checkbox-item">
                    <div>
                        <input type="radio" name="type" value="HIGHLIGHT" class="form-check-input me-2" 
                               ${selectedType == 'HIGHLIGHT' ? 'checked' : ''} onchange="this.form.submit()">
                        <span>Highlights</span>
                    </div>
                </label>
                <label class="filter-checkbox-item">
                    <div>
                        <input type="radio" name="type" value="SHORT" class="form-check-input me-2" 
                               ${selectedType == 'SHORT' ? 'checked' : ''} onchange="this.form.submit()">
                        <span>Shorts</span>
                    </div>
                </label>

                <div class="filter-section-title">Team</div>
                <select class="form-select form-select-sm bg-dark text-white border-secondary mb-3" name="team" onchange="this.form.submit()">
                    <option value="">All Teams</option>
                    <c:forEach var="tm" items="${teams}">
                        <option value="${tm.teamId}" ${selectedTeam == tm.teamId ? 'selected' : ''}>${tm.name}</option>
                    </c:forEach>
                </select>

                <div class="filter-section-title">Sort By (Strategy Pattern)</div>
                <select class="form-select form-select-sm bg-dark text-white border-secondary mb-3" name="sortBy" onchange="this.form.submit()">
                    <option value="recent" ${selectedSort == 'recent' ? 'selected' : ''}>Most Relevant / Recent</option>
                    <option value="views" ${selectedSort == 'views' ? 'selected' : ''}>Most Viewed</option>
                    <option value="rating" ${selectedSort == 'rating' ? 'selected' : ''}>Top Rated</option>
                </select>
            </form>
        </div>

        <!-- RIGHT RESULTS MAIN COLUMN (Screenshot 2) -->
        <div>
            <div class="d-flex justify-content-between align-items-center mb-2 flex-wrap gap-2">
                <div>
                    <h2 class="h3 fw-bold text-white mb-0" style="font-family: 'Outfit', sans-serif;">Search Results</h2>
                    <span class="text-muted small">${results.size()} results for "${not empty query ? query : 'All Content'}"</span>
                </div>
                <c:if test="${not empty appliedStrategy}">
                    <span class="badge bg-secondary">Algorithm: ${appliedStrategy}</span>
                </c:if>
            </div>

            <!-- Active filter tags -->
            <div class="d-flex align-items-center gap-2 mb-4">
                <span class="filter-tag-pill">Cricket <i class="fas fa-times cursor-pointer ms-1"></i></span>
                <span class="filter-tag-pill">Last 30 days <i class="fas fa-times cursor-pointer ms-1"></i></span>
            </div>

            <div class="row g-3">
                <c:forEach var="v" items="${results}">
                    <div class="col-md-6 col-xl-3">
                        <div class="video-card-v2">
                            <a href="${pageContext.request.contextPath}/watch?v=${v.videoId}" class="video-thumb-wrap">
                                <img src="${v.thumbnailUrl}" alt="${v.title}">
                                <c:choose>
                                    <c:when test="${v.videoType == 'LIVE'}">
                                        <span class="badge-live-custom position-absolute top-0 start-0 m-2">LIVE</span>
                                    </c:when>
                                    <c:otherwise>
                                        <span class="time-pill">8:24</span>
                                    </c:otherwise>
                                </c:choose>
                            </a>
                            <div class="video-info-body">
                                <div class="title"><a href="${pageContext.request.contextPath}/watch?v=${v.videoId}">${v.title}</a></div>
                                <div class="sub-meta">${v.categoryName} &bull; Tournament Series</div>
                                <div class="card-team-badge-row justify-content-between">
                                    <div class="d-flex align-items-center gap-1 text-truncate">
                                        <i class="fas fa-shield-alt text-warning"></i> ${v.teamName != null ? v.teamName : "Sri Lanka"}
                                    </div>
                                    <i class="far fa-bookmark cursor-pointer" title="Watch Later"></i>
                                </div>
                                <div class="sub-meta mt-2">${v.viewCount} views</div>
                            </div>
                        </div>
                    </div>
                </c:forEach>
            </div>

            <!-- Bottom Search Help Card -->
            <div class="card bg-dark border-secondary p-4 mt-4 rounded-4 d-flex flex-row justify-content-between align-items-center flex-wrap gap-3">
                <div class="d-flex align-items-center gap-3">
                    <div class="avatar-circle" style="width: 44px; height: 44px; background: #17223b;"><i class="fas fa-search text-primary"></i></div>
                    <div>
                        <h6 class="fw-bold text-white mb-1">Didn't find what you're looking for?</h6>
                        <span class="text-muted small">Try different keywords, check your spelling or remove some filters to see more results.</span>
                    </div>
                </div>
                <a href="${pageContext.request.contextPath}/search" class="btn-sportix-primary">
                    Clear Filters
                </a>
            </div>
        </div>
    </div>
</div>

<jsp:include page="/WEB-INF/views/common/footer.jsp" />
