<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<jsp:include page="/WEB-INF/views/common/header.jsp">
    <jsp:param name="pageTitle" value="SPORTIX - Sports Streaming & Highlights Platform" />
</jsp:include>
<jsp:include page="/WEB-INF/views/common/navbar.jsp" />

<div class="container-fluid px-lg-4 my-4">

    <!-- Top Hero Section (Matches Screenshot 4) -->
    <div class="hero-layout-grid">
        <!-- 1. Main Live Match Card -->
        <div class="hero-main-card">
            <div>
                <div class="d-flex align-items-center gap-2 mb-2">
                    <span class="badge-live-custom"><i class="fas fa-play"></i> LIVE</span>
                    <span class="text-muted small">Emerald Cup 2025</span>
                </div>
                <h1 class="display-6 fw-bold text-white mb-2" style="max-width: 480px; font-family: 'Outfit', sans-serif;">
                    Colombo Lions <span class="text-muted fw-light">vs</span> Kandy Titans
                </h1>
                <p class="text-muted small mb-3">Cricket &bull; R. Premadasa Stadium, Colombo</p>
                <div class="spoiler-score mb-4 d-inline-block" style="background: rgba(0,0,0,0.4); border: 1px solid rgba(255,255,255,0.1); padding: 6px 12px; border-radius: 6px;">
                    <span class="fw-bold text-white">Lions 178/4 (32.1)</span> &bull; <span class="text-success">Live &bull; 2nd Innings</span>
                </div>
            </div>
            <div>
                <c:choose>
                    <c:when test="${not empty featuredVideos}">
                        <a href="${pageContext.request.contextPath}/watch?v=${featuredVideos[0].videoId}" class="btn-sportix-primary">
                            <i class="fas fa-play"></i> Watch Live
                        </a>
                    </c:when>
                    <c:otherwise>
                        <a href="${pageContext.request.contextPath}/watch?v=1" class="btn-sportix-primary">
                            <i class="fas fa-play"></i> Watch Live
                        </a>
                    </c:otherwise>
                </c:choose>
            </div>
        </div>

        <!-- 2. Hero Promo Card (MORE THAN A GAME) -->
        <div class="hero-promo-card">
            <span class="sub text-uppercase">More Than</span>
            <h2>A GAME</h2>
            <div class="text-light small fw-bold">SRI LANKA PLAYS BIGGER TOGETHER</div>
        </div>

        <!-- 3. Most Viewed Ranked List -->
        <div class="most-viewed-card">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <h5 class="fw-bold text-white mb-0" style="font-size: 1.05rem;">Most Viewed</h5>
                <a href="${pageContext.request.contextPath}/search?sortBy=views" class="text-success small fw-bold">See All</a>
            </div>

            <div class="most-viewed-list">
                <c:forEach var="v" items="${highlights}" varStatus="status" end="4">
                    <a href="${pageContext.request.contextPath}/watch?v=${v.videoId}" class="most-viewed-item">
                        <span class="rank-num">${status.count}</span>
                        <div class="position-relative">
                            <img src="${v.thumbnailUrl}" alt="${v.title}" class="thumb">
                            <span class="time-pill">8:24</span>
                        </div>
                        <div style="flex: 1; min-width: 0;">
                            <div class="text-white text-truncate fw-semibold small">${v.title}</div>
                            <div class="text-muted small text-truncate" style="font-size: 0.75rem;">${v.teamName != null ? v.teamName : v.categoryName}</div>
                            <div class="text-muted small" style="font-size: 0.72rem;">${v.viewCount} views</div>
                        </div>
                    </a>
                </c:forEach>
            </div>
        </div>
    </div>

    <!-- Live Now Section (Matches Screenshot 4) -->
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="fw-bold text-white mb-0" style="font-family: 'Outfit', sans-serif;">Live Now</h4>
        <a href="${pageContext.request.contextPath}/search?type=LIVE" class="text-success small fw-bold">See All Live</a>
    </div>

    <div class="row g-3 mb-5">
        <div class="col-md-6 col-lg-3">
            <div class="live-match-card" onclick="window.location.href='${pageContext.request.contextPath}/watch?v=1'">
                <div class="live-match-header">
                    <span class="badge-live-custom">LIVE</span>
                    <span class="text-muted small"><i class="fas fa-users me-1"></i> 24.6K</span>
                </div>
                <div class="live-match-teams">
                    <div class="team-crest-box">
                        <i class="fas fa-shield-alt text-warning fa-2x"></i>
                        <span class="text-white mt-1">Colombo Lions</span>
                    </div>
                    <span class="match-vs-divider">VS</span>
                    <div class="team-crest-box">
                        <i class="fas fa-shield-alt text-info fa-2x"></i>
                        <span class="text-white mt-1">Kandy Titans</span>
                    </div>
                </div>
                <div class="text-muted small text-center pt-2 border-top border-secondary" style="font-size: 0.75rem;">
                    Cricket &bull; Emerald Cup 2025
                </div>
            </div>
        </div>

        <div class="col-md-6 col-lg-3">
            <div class="live-match-card" onclick="window.location.href='${pageContext.request.contextPath}/watch?v=2'">
                <div class="live-match-header">
                    <span class="badge-live-custom">LIVE</span>
                    <span class="text-muted small"><i class="fas fa-users me-1"></i> 18.2K</span>
                </div>
                <div class="live-match-teams">
                    <div class="team-crest-box">
                        <i class="fas fa-shield-alt text-primary fa-2x"></i>
                        <span class="text-white mt-1">Galle Mariners</span>
                    </div>
                    <span class="match-vs-divider">VS</span>
                    <div class="team-crest-box">
                        <i class="fas fa-shield-alt text-danger fa-2x"></i>
                        <span class="text-white mt-1">Jaffna Rangers</span>
                    </div>
                </div>
                <div class="text-muted small text-center pt-2 border-top border-secondary" style="font-size: 0.75rem;">
                    Football &bull; Island Premier League
                </div>
            </div>
        </div>

        <div class="col-md-6 col-lg-3">
            <div class="live-match-card" onclick="window.location.href='${pageContext.request.contextPath}/watch?v=3'">
                <div class="live-match-header">
                    <span class="badge-live-custom">LIVE</span>
                    <span class="text-muted small"><i class="fas fa-users me-1"></i> 7.1K</span>
                </div>
                <div class="live-match-teams">
                    <div class="team-crest-box">
                        <i class="fas fa-shield-alt text-purple fa-2x" style="color: #a855f7;"></i>
                        <span class="text-white mt-1">Lanka Hurricanes</span>
                    </div>
                    <span class="match-vs-divider">VS</span>
                    <div class="team-crest-box">
                        <i class="fas fa-shield-alt text-warning fa-2x"></i>
                        <span class="text-white mt-1">Coastal Bears</span>
                    </div>
                </div>
                <div class="text-muted small text-center pt-2 border-top border-secondary" style="font-size: 0.75rem;">
                    Rugby &bull; Oceanic Rugby Series
                </div>
            </div>
        </div>

        <div class="col-md-6 col-lg-3">
            <div class="live-match-card" onclick="window.location.href='${pageContext.request.contextPath}/watch?v=4'">
                <div class="live-match-header">
                    <span class="badge-live-custom">LIVE</span>
                    <span class="text-muted small"><i class="fas fa-users me-1"></i> 5.4K</span>
                </div>
                <div class="live-match-teams">
                    <div class="team-crest-box">
                        <i class="fas fa-shield-alt text-danger fa-2x"></i>
                        <span class="text-white mt-1">Sky City Bulls</span>
                    </div>
                    <span class="match-vs-divider">VS</span>
                    <div class="team-crest-box">
                        <i class="fas fa-shield-alt text-info fa-2x"></i>
                        <span class="text-white mt-1">Riverside Falcons</span>
                    </div>
                </div>
                <div class="text-muted small text-center pt-2 border-top border-secondary" style="font-size: 0.75rem;">
                    Basketball &bull; South Asia Basketball League
                </div>
            </div>
        </div>
    </div>

    <!-- Latest Highlights & Shorts Split (Matches Screenshot 4) -->
    <div class="row g-4 mb-5">
        <!-- Highlights (Left 8 Cols) -->
        <div class="col-lg-8">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h4 class="fw-bold text-white mb-0" style="font-family: 'Outfit', sans-serif;">Latest Highlights</h4>
                <a href="${pageContext.request.contextPath}/search?type=HIGHLIGHT" class="text-success small fw-bold">See All Highlights</a>
            </div>

            <div class="row g-3">
                <c:forEach var="v" items="${highlights}" end="5">
                    <div class="col-md-6 col-xl-4">
                        <div class="video-card-v2">
                            <a href="${pageContext.request.contextPath}/watch?v=${v.videoId}" class="video-thumb-wrap">
                                <img src="${v.thumbnailUrl}" alt="${v.title}">
                                <span class="time-pill">10:24</span>
                            </a>
                            <div class="video-info-body">
                                <div class="title"><a href="${pageContext.request.contextPath}/watch?v=${v.videoId}">${v.title}</a></div>
                                <div class="sub-meta">${v.categoryName}</div>
                                <div class="sub-meta mt-auto pt-1">${v.viewCount} views &bull; 1 day ago</div>
                            </div>
                        </div>
                    </div>
                </c:forEach>
            </div>
        </div>

        <!-- Shorts (Right 4 Cols) -->
        <div class="col-lg-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h4 class="fw-bold text-white mb-0" style="font-family: 'Outfit', sans-serif;">Shorts</h4>
                <a href="${pageContext.request.contextPath}/search?type=SHORT" class="text-success small fw-bold">See All</a>
            </div>

            <div class="row g-2">
                <c:forEach var="s" items="${shorts}" end="3">
                    <div class="col-6">
                        <a href="${pageContext.request.contextPath}/watch?v=${s.videoId}" class="short-card-v2">
                            <img src="${s.thumbnailUrl}" alt="${s.title}">
                            <div class="short-card-overlay">
                                <div class="short-title">${s.title}</div>
                                <div class="short-views"><i class="fas fa-play me-1"></i> ${s.viewCount}</div>
                            </div>
                        </a>
                    </div>
                </c:forEach>
            </div>
        </div>
    </div>

    <!-- Followed Teams & Bottom Sponsor Banner (Matches Screenshot 4) -->
    <div class="row g-4 align-items-center mb-5">
        <!-- Followed Teams (Member 1) -->
        <div class="col-lg-5">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="fw-bold text-white mb-0">Followed Teams</h5>
                <a href="${pageContext.request.contextPath}/profile" class="text-success small fw-bold">Manage</a>
            </div>
            <div class="d-flex flex-wrap gap-2">
                <div class="team-follow-pill">
                    <i class="fas fa-shield-alt text-warning fa-lg"></i>
                    <div>
                        <div class="fw-bold small text-white">Colombo Lions</div>
                        <div class="text-muted" style="font-size: 0.72rem;">Cricket</div>
                    </div>
                </div>
                <div class="team-follow-pill">
                    <i class="fas fa-shield-alt text-primary fa-lg"></i>
                    <div>
                        <div class="fw-bold small text-white">Galle Mariners</div>
                        <div class="text-muted" style="font-size: 0.72rem;">Football</div>
                    </div>
                </div>
                <a href="${pageContext.request.contextPath}/profile" class="team-follow-pill text-muted small" style="border-style: dashed;">
                    <i class="fas fa-plus"></i> Follow More Teams
                </a>
            </div>
        </div>

        <!-- Solaris Sponsor Banner (Member 5) -->
        <div class="col-lg-7">
            <div class="bottom-sponsor-banner">
                <div>
                    <div class="text-muted small text-uppercase fw-bold" style="letter-spacing: 1px;">Fans Fuel</div>
                    <div class="h4 fw-bold text-white mb-1" style="font-family: 'Outfit', sans-serif;">A BRIGHTER TOMORROW</div>
                    <div class="small" style="color: var(--primary);">CLEAN ENERGY. STRONGER SPORTS.</div>
                </div>
                <div class="text-end">
                    <div class="h3 fw-bold text-warning mb-0" style="font-family: 'Outfit', sans-serif;"><i class="fas fa-sun me-1"></i> SOLARIS</div>
                    <div class="text-muted" style="font-size: 0.7rem;">POWERING PEOPLE</div>
                </div>
            </div>
        </div>
    </div>

</div>

<jsp:include page="/WEB-INF/views/common/footer.jsp" />
