<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<jsp:include page="/WEB-INF/views/common/header.jsp">
    <jsp:param name="pageTitle" value="Publish Sports Video - Sportix" />
</jsp:include>
<jsp:include page="/WEB-INF/views/common/navbar.jsp" />

<div class="container my-5" style="max-width: 800px;">
    <div class="card bg-dark border-secondary p-4 rounded-4 shadow-lg">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0"><i class="fas fa-cloud-upload-alt text-primary me-2"></i> Publish Sports Video</h3>
            <span class="badge bg-secondary">UC-03 Content Posting</span>
        </div>
        <p class="text-muted small mb-4">Submit a YouTube video or shorts link. Valid links will generate automatic embeds and high-definition thumbnails.</p>

        <!-- Error Alert -->
        <c:if test="${not empty errorMessage}">
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-triangle me-2"></i> ${errorMessage}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        </c:if>

        <form action="${pageContext.request.contextPath}/add-video" method="POST">
            <!-- YouTube URL Input with Instant Preview -->
            <div class="mb-3">
                <label class="form-label fw-bold small">YouTube Video URL / Link <span class="text-danger">*</span></label>
                <div class="input-group">
                    <span class="input-group-text bg-dark text-danger border-secondary"><i class="fab fa-youtube"></i></span>
                    <input type="url" class="form-control bg-dark text-white border-secondary" id="youtubeUrlInput" name="youtubeUrl" 
                           placeholder="https://www.youtube.com/watch?v=... or https://youtu.be/... or shorts" required>
                </div>
                <div class="form-text text-muted">Supports YouTube standard URLs, shortened youtu.be links, and vertical Shorts.</div>
            </div>

            <!-- Instant Live Thumbnail Preview (Client-side JS) -->
            <div id="ytPreviewContainer" class="mb-3 p-3 bg-black rounded-3 border border-secondary" style="display: none;">
                <label class="form-label small text-info fw-bold"><i class="fas fa-check-circle me-1"></i> Detected Video Preview:</label>
                <div class="d-flex gap-3 align-items-center">
                    <img id="ytThumbPreview" src="" alt="Preview" class="rounded-2" style="width: 140px; height: 80px; object-fit: cover;">
                    <span class="small text-muted">YouTube video ID successfully verified. Platform will embed this directly.</span>
                </div>
            </div>

            <!-- Video Title -->
            <div class="mb-3">
                <label class="form-label fw-bold small">Video Title <span class="text-danger">*</span></label>
                <input type="text" class="form-control bg-dark text-white border-secondary" name="title" 
                       placeholder="e.g. ICC T20 World Cup Final 2024 - Last Over Highlights" required maxlength="180">
            </div>

            <div class="row g-3 mb-3">
                <!-- Sport Category -->
                <div class="col-md-6">
                    <label class="form-label fw-bold small">Sport Category <span class="text-danger">*</span></label>
                    <select class="form-select bg-dark text-white border-secondary" name="categoryId" required>
                        <option value="">Select Sport...</option>
                        <c:forEach var="c" items="${categories}">
                            <option value="${c.categoryId}">${c.name}</option>
                        </c:forEach>
                    </select>
                </div>

                <!-- Team -->
                <div class="col-md-6">
                    <label class="form-label fw-bold small">Associated Team (Optional)</label>
                    <select class="form-select bg-dark text-white border-secondary" name="teamId">
                        <option value="0">None / Neutral Match</option>
                        <c:forEach var="t" items="${teams}">
                            <option value="${t.teamId}">${t.name}</option>
                        </c:forEach>
                    </select>
                </div>
            </div>

            <div class="row g-3 mb-3">
                <!-- Video Type / Format -->
                <div class="col-md-6">
                    <label class="form-label fw-bold small">Content Format <span class="text-danger">*</span></label>
                    <select class="form-select bg-dark text-white border-secondary" name="videoType" required>
                        <option value="HIGHLIGHT">Match Highlight</option>
                        <option value="SHORT">Vertical Short-Form Clip</option>
                        <option value="LIVE">Live Match Stream</option>
                        <option value="INTERVIEW">Player/Coach Interview</option>
                    </select>
                </div>

                <!-- Match Score (For Spoiler-Free Mode) -->
                <div class="col-md-6">
                    <label class="form-label fw-bold small">Match Final Score (Optional - Enables Spoiler-Free Mode)</label>
                    <input type="text" class="form-control bg-dark text-white border-secondary" name="matchScore" 
                           placeholder="e.g. SL 185/6 beat IND 182 by 4 runs">
                </div>
            </div>

            <!-- Description -->
            <div class="mb-3">
                <label class="form-label fw-bold small">Description / Match Summary</label>
                <textarea class="form-control bg-dark text-white border-secondary" name="description" rows="3" 
                          placeholder="Provide game key moments, stats, player of the match, or context..."></textarea>
            </div>

            <!-- Featured Video Scheduling (UC-03 Extension 6.a) -->
            <c:if test="${sessionScope.currentUser.contentManager || sessionScope.currentUser.admin}">
                <div class="card bg-black border-secondary p-3 mb-4 rounded-3">
                    <div class="form-check form-switch mb-2">
                        <input class="form-check-input" type="checkbox" id="isFeaturedCheck" name="isFeatured" value="true" 
                               onchange="document.getElementById('featuredDatesSection').style.display = this.checked ? 'flex' : 'none';">
                        <label class="form-check-label fw-bold text-warning small" for="isFeaturedCheck">
                            <i class="fas fa-star me-1"></i> Mark as Featured Hero Video on Homepage
                        </label>
                    </div>

                    <div id="featuredDatesSection" class="row g-2 mt-2" style="display: none;">
                        <div class="col-md-6">
                            <label class="form-label small text-muted">Featured Start Date:</label>
                            <input type="date" class="form-control bg-dark text-white border-secondary form-control-sm" name="featuredStartDate">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small text-muted">Featured End Date:</label>
                            <input type="date" class="form-control bg-dark text-white border-secondary form-control-sm" name="featuredEndDate">
                        </div>
                    </div>
                </div>
            </c:if>

            <div class="d-flex justify-content-end gap-2">
                <a href="${pageContext.request.contextPath}/home" class="btn btn-outline-secondary rounded-pill px-4">Cancel</a>
                <button type="submit" class="btn btn-primary rounded-pill px-5 fw-bold">
                    <i class="fas fa-paper-plane me-1"></i> Publish Video
                </button>
            </div>
        </form>
    </div>
</div>

<jsp:include page="/WEB-INF/views/common/footer.jsp" />
