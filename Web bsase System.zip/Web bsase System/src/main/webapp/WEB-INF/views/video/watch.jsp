<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<jsp:include page="/WEB-INF/views/common/header.jsp">
    <jsp:param name="pageTitle" value="${video.title} - SPORTIX" />
</jsp:include>
<jsp:include page="/WEB-INF/views/common/navbar.jsp" />

<input type="hidden" id="currentVideoId" value="${video.videoId}">

<div class="container-fluid px-lg-4 my-4">

    <!-- Report Confirmation Alert -->
    <c:if test="${param.reported == 'success'}">
        <div class="alert alert-success alert-dismissible fade show mb-4" role="alert">
            <i class="fas fa-check-circle me-2"></i> Report received! The item has been queued for Administrator Review in UC-06.
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    </c:if>

    <div class="row g-4">
        <!-- Main Video & Engagement Column (Screenshot 3 Left) -->
        <div class="col-lg-8">
            <!-- Video Player Wrapper with HUD Overlay -->
            <div class="player-wrapper-v2 position-relative mb-3">
                <div class="position-absolute top-0 start-0 m-3 z-3 d-flex align-items-center gap-2">
                    <span class="badge-live-custom"><i class="fas fa-play"></i> LIVE</span>
                    <span class="badge bg-dark bg-opacity-75 text-white px-2 py-1 small"><i class="fas fa-eye me-1"></i> ${video.viewCount} views</span>
                </div>

                <!-- Top Right Live Score HUD -->
                <c:if test="${not empty video.matchScore}">
                    <div class="hud-score-overlay">
                        <div class="d-flex align-items-center gap-2">
                            <i class="fas fa-shield-alt text-warning"></i>
                            <div>
                                <div class="small fw-bold">${video.teamName != null ? video.teamName : "MATCH"}</div>
                                <div class="team-score-num">${video.matchScore}</div>
                            </div>
                        </div>
                    </div>
                </c:if>

                <!-- Embedded YouTube Video Player -->
                <div class="ratio ratio-16x9">
                    <iframe src="${embedUrl}" title="${video.title}" 
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                </div>
            </div>

            <!-- Title & Live Badge -->
            <div class="d-flex align-items-center gap-2 mb-2">
                <span class="badge-live-custom">${video.videoType}</span>
                <h1 class="h4 fw-bold text-white mb-0" style="font-family: 'Outfit', sans-serif;">${video.title}</h1>
            </div>

            <!-- Channel Bar & Engagement Buttons (Member 4 - Wijesekara W.M.B.S.) -->
            <div class="channel-meta-bar">
                <div class="channel-info-left">
                    <div class="channel-icon-badge"><i class="fas fa-play"></i></div>
                    <div>
                        <div class="fw-bold text-white small d-flex align-items-center gap-1">
                            SPORTIX <i class="fas fa-check-circle text-primary" style="font-size: 0.8rem;"></i>
                        </div>
                        <div class="text-muted" style="font-size: 0.75rem;">1.2M subscribers</div>
                    </div>
                    <button class="btn-follow-lime ms-3" onclick="this.innerText = this.innerText === 'Follow' ? 'Following' : 'Follow'">
                        Follow
                    </button>
                </div>

                <div class="d-flex align-items-center gap-2 flex-wrap">
                    <!-- Like Button -->
                    <button class="btn-sportix-dark ${userLikeStatus == 1 ? 'active' : ''}" id="likeBtn">
                        <i class="fas fa-thumbs-up"></i> <span id="likeCount">${video.likeCount}</span>
                    </button>

                    <!-- Dislike Button -->
                    <button class="btn-sportix-dark ${userLikeStatus == 0 ? 'active' : ''}" id="dislikeBtn">
                        <i class="fas fa-thumbs-down"></i> <span id="dislikeCount">${video.dislikeCount}</span>
                    </button>

                    <!-- Watch Later (Member 1) -->
                    <c:if test="${not empty sessionScope.currentUser}">
                        <form action="${pageContext.request.contextPath}/watch-later/${isSavedInWatchLater ? 'remove' : 'add'}" method="POST" class="d-inline m-0">
                            <input type="hidden" name="videoId" value="${video.videoId}">
                            <input type="hidden" name="redirect" value="${pageContext.request.contextPath}/watch?v=${video.videoId}">
                            <button type="submit" class="btn-sportix-dark ${isSavedInWatchLater ? 'active' : ''}">
                                <i class="fas ${isSavedInWatchLater ? 'fa-check text-success' : 'fa-bookmark'}"></i>
                                ${isSavedInWatchLater ? 'Saved' : 'Watch Later'}
                            </button>
                        </form>
                    </c:if>

                    <!-- Star Rating Widget (Member 4) -->
                    <div class="d-flex align-items-center px-2 py-1 rounded-pill bg-dark border border-secondary gap-1" title="Rate this video">
                        <span class="small fw-bold text-warning me-1">★ <span id="avgRatingDisplay">${video.avgRating}</span></span>
                        <div class="star-rating" id="starRatingContainer">
                            <c:forEach var="i" begin="1" end="5">
                                <i class="${userRating != null && userRating >= i ? 'fas active' : 'far'} fa-star star-item" data-rating="${i}" style="font-size: 0.85rem;"></i>
                            </c:forEach>
                        </div>
                    </div>

                    <!-- Report Content (UC-04: Member 4) -->
                    <button class="btn-sportix-dark text-danger" data-bs-toggle="modal" data-bs-target="#reportModal" 
                            onclick="setReportTarget('VIDEO', ${video.videoId}, '${video.title}')">
                        <i class="fas fa-flag"></i> Report
                    </button>
                </div>
            </div>

            <!-- Comments Section (Member 4 - User Engagement) -->
            <div class="mt-4">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="fw-bold text-white mb-0">Comments (${video.commentCount})</h5>
                    <div class="dropdown">
                        <button class="btn btn-sm btn-link text-muted text-decoration-none dropdown-toggle" type="button" data-bs-toggle="dropdown">
                            Sort by: Top comments
                        </button>
                        <ul class="dropdown-menu dropdown-menu-dark">
                            <li><a class="dropdown-item active" href="#">Top comments</a></li>
                            <li><a class="dropdown-item" href="#">Newest first</a></li>
                        </ul>
                    </div>
                </div>

                <!-- Add Comment Input Box -->
                <c:choose>
                    <c:when test="${not empty sessionScope.currentUser}">
                        <form action="${pageContext.request.contextPath}/comment/add" method="POST" class="d-flex gap-3 mb-4">
                            <input type="hidden" name="videoId" value="${video.videoId}">
                            <div class="avatar-circle" style="width: 38px; height: 38px;">
                                ${sessionScope.currentUser.displayName.substring(0, 2).toUpperCase()}
                            </div>
                            <div class="flex-grow-1">
                                <input type="text" class="form-control bg-dark text-white border-secondary rounded-pill px-3 py-2 small" 
                                       name="content" placeholder="Add a comment..." required>
                            </div>
                            <button type="submit" class="btn btn-sportix-primary btn-sm px-4">Post</button>
                        </form>
                    </c:when>
                    <c:otherwise>
                        <div class="alert alert-secondary text-center small rounded-pill py-2 mb-4">
                            <a href="${pageContext.request.contextPath}/login" class="text-success fw-bold">Sign In</a> to join the discussion and post comments.
                        </div>
                    </c:otherwise>
                </c:choose>

                <!-- Comments Feed -->
                <div id="commentsList">
                    <c:forEach var="c" items="${comments}">
                        <div class="d-flex gap-3 mb-3 p-2 rounded-3">
                            <div class="avatar-circle" style="width: 36px; height: 36px; background: #1e3a8a; color: #fff;">
                                ${c.userDisplayName.substring(0, 2).toUpperCase()}
                            </div>
                            <div class="flex-grow-1">
                                <div class="d-flex align-items-center gap-2 mb-1">
                                    <span class="fw-bold text-white small">${c.userDisplayName}</span>
                                    <span class="text-muted small" style="font-size: 0.72rem;">${c.createdAt}</span>
                                </div>
                                <p class="text-light small mb-2">${c.content}</p>
                                <div class="d-flex align-items-center gap-3 text-muted small">
                                    <c:if test="${sessionScope.currentUser.userId == c.userId || sessionScope.currentUser.admin}">
                                        <form action="${pageContext.request.contextPath}/comment/delete" method="POST" class="d-inline m-0">
                                            <input type="hidden" name="commentId" value="${c.commentId}">
                                            <input type="hidden" name="videoId" value="${video.videoId}">
                                            <button type="submit" class="btn btn-link text-danger p-0 small text-decoration-none" onclick="return confirm('Delete this comment?');">Delete</button>
                                        </form>
                                    </c:if>
                                    <span class="cursor-pointer text-danger" data-bs-toggle="modal" data-bs-target="#reportModal"
                                          onclick="setReportTarget('COMMENT', ${c.commentId}, '${c.userDisplayName}: ${c.content}')">
                                        <i class="fas fa-flag me-1"></i> Report
                                    </span>
                                </div>
                            </div>
                        </div>
                    </c:forEach>
                </div>
            </div>
        </div>

        <!-- Sidebar Column (Screenshot 3 Right) -->
        <div class="col-lg-4">
            <!-- Match Details Box -->
            <div class="match-details-panel">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <h5 class="fw-bold text-white mb-0" style="font-family: 'Outfit', sans-serif;">Match Details</h5>
                    <span class="badge-live-custom">${video.videoType}</span>
                </div>
                <div class="text-muted small mb-3">${video.categoryName}</div>

                <div class="match-fixture-showcase">
                    <div class="text-center">
                        <i class="fas fa-shield-alt text-warning fa-2x mb-1"></i>
                        <div class="small fw-bold text-white">${video.teamName != null ? video.teamName : "Sri Lanka"}</div>
                    </div>
                    <div class="text-muted fw-bold">VS</div>
                    <div class="text-center">
                        <i class="fas fa-shield-alt text-info fa-2x mb-1"></i>
                        <div class="small fw-bold text-white">Opponent</div>
                    </div>
                </div>

                <div class="match-info-item"><i class="fas fa-trophy"></i><div>Emerald Cup 2025</div></div>
                <div class="match-info-item"><i class="far fa-calendar-alt"></i><div>Today, Mar 16, 2025</div></div>
                <div class="match-info-item"><i class="far fa-clock"></i><div>2:30 PM (IST)</div></div>
                <div class="match-info-item"><i class="fas fa-map-marker-alt"></i><div>R. Premadasa Stadium, Colombo</div></div>
            </div>

            <!-- Ad Banner (MORE THAN A GAME) -->
            <div class="hero-promo-card mb-4" style="min-height: 200px; padding: 1.5rem;">
                <span class="sub text-uppercase" style="font-size: 0.8rem;">More Than</span>
                <h4 class="fw-bold text-white mb-0" style="font-family: 'Outfit', sans-serif;">A GAME</h4>
                <div class="text-light small fw-bold mt-1" style="font-size: 0.75rem;">SRI LANKA PLAYS BIGGER TOGETHER</div>
            </div>

            <!-- More Matches -->
            <h6 class="fw-bold text-white mb-3">More Matches</h6>
            <div class="d-flex flex-column gap-3">
                <c:forEach var="rel" items="${relatedVideos}">
                    <a href="${pageContext.request.contextPath}/watch?v=${rel.videoId}" class="d-flex gap-2 p-2 rounded-3 bg-dark border border-secondary text-decoration-none">
                        <img src="${rel.thumbnailUrl}" class="rounded-2" style="width: 120px; height: 68px; object-fit: cover;">
                        <div style="flex: 1; min-width: 0;">
                            <div class="small fw-bold text-white text-truncate">${rel.title}</div>
                            <div class="text-muted small" style="font-size: 0.72rem;">${rel.categoryName}</div>
                            <div class="text-muted small" style="font-size: 0.7rem;">${rel.viewCount} views</div>
                        </div>
                    </a>
                </c:forEach>
            </div>
        </div>
    </div>
</div>

<!-- REPORT MODAL (UC-04: Member 4 - Wijesekara W.M.B.S.) -->
<div class="modal fade" id="reportModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content bg-dark text-white border-secondary rounded-4 shadow-lg p-3">
            <form action="${pageContext.request.contextPath}/report/submit" method="POST">
                <input type="hidden" name="returnVideoId" value="${video.videoId}">
                <input type="hidden" name="targetType" id="modalTargetType" value="VIDEO">
                <input type="hidden" name="targetId" id="modalTargetId" value="${video.videoId}">

                <div class="modal-header border-0 pb-0">
                    <h5 class="modal-title fw-bold" style="font-family: 'Outfit', sans-serif;">Report Content</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="p-3 bg-black rounded-3 border border-secondary mb-3">
                        <div class="text-muted small text-truncate" id="modalTargetSnippet">${video.title}</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small text-muted">Reason for reporting</label>
                        <select class="form-select bg-dark text-white border-secondary" name="reason" required>
                            <option value="Spam">Spam</option>
                            <option value="Offensive Language" selected>Offensive Language</option>
                            <option value="Misleading">Misleading</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0 d-flex gap-2">
                    <button type="button" class="btn btn-sportix-dark flex-grow-1" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-sportix-primary flex-grow-1">Submit Report</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function setReportTarget(type, id, snippet) {
    document.getElementById('modalTargetType').value = type;
    document.getElementById('modalTargetId').value = id;
    document.getElementById('modalTargetSnippet').innerText = snippet;
}
</script>

<jsp:include page="/WEB-INF/views/common/footer.jsp" />
