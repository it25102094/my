<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<jsp:include page="/WEB-INF/views/common/header.jsp">
    <jsp:param name="pageTitle" value="Manage Ad Campaigns - Sportix" />
</jsp:include>
<jsp:include page="/WEB-INF/views/common/navbar.jsp" />

<div class="container my-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold mb-0"><i class="fas fa-bullhorn text-primary me-2"></i> Advertising Campaigns</h3>
            <p class="text-muted small mb-0">UC-05: Create, schedule, and monitor sponsored sports advertisements</p>
        </div>
        <button class="btn btn-primary rounded-pill px-4" data-bs-toggle="collapse" data-bs-target="#newAdForm">
            <i class="fas fa-plus me-1"></i> New Campaign
        </button>
    </div>

    <!-- Error/Success messages -->
    <c:if test="${not empty errorMessage}">
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-triangle me-2"></i> ${errorMessage}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    </c:if>
    <c:if test="${param.created == 'true'}">
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i> Advertisement campaign successfully scheduled and activated!
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    </c:if>

    <!-- Create Campaign Form (UC-05) -->
    <div class="collapse mb-4 ${not empty errorMessage ? 'show' : ''}" id="newAdForm">
        <div class="card bg-dark border-secondary p-4 rounded-4 shadow-lg">
            <h5 class="fw-bold mb-3"><i class="fas fa-calendar-plus text-primary me-2"></i> Schedule New Campaign</h5>
            <form action="${pageContext.request.contextPath}/ads/create" method="POST">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label small fw-bold">Campaign Title <span class="text-danger">*</span></label>
                        <input type="text" class="form-control bg-dark text-white border-secondary" name="title" 
                               placeholder="e.g. Puma Sports Football Boots Promo" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small fw-bold">Placement / Type</label>
                        <select class="form-select bg-dark text-white border-secondary" name="adType">
                            <option value="BANNER">Top Banner (Homepage)</option>
                            <option value="SIDEBAR">Sidebar Card (Watch Page)</option>
                            <option value="CARD">In-Feed Card</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small fw-bold">Display Priority</label>
                        <select class="form-select bg-dark text-white border-secondary" name="priority">
                            <option value="1">Standard (1)</option>
                            <option value="2">High Priority (2)</option>
                            <option value="3">Top Sponsor (3)</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold">Banner Image URL <span class="text-danger">*</span></label>
                        <input type="url" class="form-control bg-dark text-white border-secondary" name="imageUrl" 
                               placeholder="https://images.unsplash.com/... or hosted banner image" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold">Click Target URL <span class="text-danger">*</span></label>
                        <input type="url" class="form-control bg-dark text-white border-secondary" name="targetUrl" 
                               placeholder="https://brand.com/landing-page" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold">Start Date <span class="text-danger">*</span></label>
                        <input type="date" class="form-control bg-dark text-white border-secondary" name="startDate" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold">End Date <span class="text-danger">*</span></label>
                        <input type="date" class="form-control bg-dark text-white border-secondary" name="endDate" required>
                    </div>
                </div>
                <div class="text-end mt-3">
                    <button type="button" class="btn btn-outline-secondary rounded-pill px-3 me-2" data-bs-toggle="collapse" data-bs-target="#newAdForm">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-4 fw-bold">Save & Schedule Campaign</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Active Campaigns Table -->
    <div class="card bg-dark border-secondary rounded-4 shadow overflow-hidden">
        <div class="card-header bg-black border-secondary py-3">
            <h5 class="fw-bold mb-0">Active & Scheduled Campaigns</h5>
        </div>
        <div class="table-responsive">
            <table class="table table-dark table-hover mb-0 align-middle">
                <thead>
                    <tr class="text-muted small">
                        <th>Preview</th>
                        <th>Title</th>
                        <th>Placement</th>
                        <th>Active Dates</th>
                        <th>Performance</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <c:forEach var="ad" items="${campaigns}">
                        <tr>
                            <td>
                                <img src="${ad.imageUrl}" alt="${ad.title}" class="rounded-2" style="width: 80px; height: 45px; object-fit: cover;">
                            </td>
                            <td>
                                <div class="fw-bold">${ad.title}</div>
                                <a href="${ad.targetUrl}" target="_blank" class="text-muted small">${ad.targetUrl}</a>
                            </td>
                            <td><span class="badge bg-secondary">${ad.adType}</span></td>
                            <td class="small text-muted">${ad.startDate} to ${ad.endDate}</td>
                            <td>
                                <div class="small"><i class="fas fa-eye text-info me-1"></i> ${ad.impressions} impressions</div>
                                <div class="small"><i class="fas fa-mouse-pointer text-success me-1"></i> ${ad.clicks} clicks</div>
                            </td>
                            <td>
                                <span class="badge ${ad.status == 'ACTIVE' ? 'bg-success' : 'bg-warning'}">${ad.status}</span>
                            </td>
                            <td>
                                <form action="${pageContext.request.contextPath}/ads/delete" method="POST" class="d-inline" onsubmit="return confirm('Delete this advertisement campaign?');">
                                    <input type="hidden" name="adId" value="${ad.adId}">
                                    <button type="submit" class="btn btn-outline-danger btn-sm rounded-circle" title="Delete Campaign">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    </c:forEach>
                    <c:if test="${empty campaigns}">
                        <tr>
                            <td colspan="7" class="text-center py-4 text-muted">No advertisement campaigns scheduled yet. Click "New Campaign" above.</td>
                        </tr>
                    </c:if>
                </tbody>
            </table>
        </div>
    </div>
</div>

<jsp:include page="/WEB-INF/views/common/footer.jsp" />
