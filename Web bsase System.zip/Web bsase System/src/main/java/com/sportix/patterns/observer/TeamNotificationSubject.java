package com.sportix.patterns.observer;

import com.sportix.dao.NotificationDAO;
import com.sportix.model.Notification;
import com.sportix.model.Video;
import com.sportix.patterns.factory.NotificationFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * Concrete Subject implementing the OBSERVER DESIGN PATTERN.
 * When a new video for a team is published, this subject automatically generates
 * notifications for all users following that team.
 * Assigned to Member 5 (Advertising & Notifications).
 */
public class TeamNotificationSubject implements Subject {

    private final List<Observer> observers = new ArrayList<>();
    private final NotificationDAO notificationDAO = new NotificationDAO();

    @Override
    public void registerObserver(Observer observer) {
        if (observer != null && !observers.contains(observer)) {
            observers.add(observer);
        }
    }

    @Override
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers(Video newVideo) {
        for (Observer observer : observers) {
            observer.update(newVideo);
        }
    }

    /**
     * Dispatches notifications to team followers and persists them to the database.
     */
    public void dispatchTeamUploadNotification(Video video, List<Integer> followerUserIds) {
        if (video == null || followerUserIds == null || followerUserIds.isEmpty()) {
            return;
        }

        String title = video.getTeamName() != null ? video.getTeamName() : "Sports Update";
        String message = "New match content uploaded: \"" + video.getTitle() + "\". Watch now!";

        for (int userId : followerUserIds) {
            Notification notification = NotificationFactory.createNotification(
                    NotificationFactory.NotificationType.TEAM_POST,
                    userId,
                    title,
                    message,
                    video.getVideoId()
            );
            notificationDAO.createNotification(notification);
        }
        
        notifyObservers(video);
    }
}
