package com.sportix.patterns.strategy;

import com.sportix.model.Video;
import java.util.Comparator;
import java.util.List;

/**
 * Concrete Strategy: Sorts videos by highest view count descending.
 */
public class MostViewedStrategy implements VideoSortStrategy {
    @Override
    public void sort(List<Video> videos) {
        if (videos != null) {
            videos.sort(Comparator.comparingInt(Video::getViewCount).reversed());
        }
    }

    @Override
    public String getStrategyName() {
        return "Most Viewed";
    }
}
