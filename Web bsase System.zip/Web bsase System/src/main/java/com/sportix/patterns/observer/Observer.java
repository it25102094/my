package com.sportix.patterns.observer;

import com.sportix.model.Video;

/**
 * Observer Interface in the OBSERVER DESIGN PATTERN.
 */
public interface Observer {
    void update(Video newVideo);
}
