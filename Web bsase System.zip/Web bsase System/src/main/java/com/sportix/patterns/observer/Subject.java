package com.sportix.patterns.observer;

import com.sportix.model.Video;

/**
 * Subject Interface in the OBSERVER DESIGN PATTERN.
 */
public interface Subject {
    void registerObserver(Observer observer);
    void removeObserver(Observer observer);
    void notifyObservers(Video newVideo);
}
