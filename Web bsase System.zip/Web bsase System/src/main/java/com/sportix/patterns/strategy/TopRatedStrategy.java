package com.sportix.patterns.strategy;

import com.sportix.model.Video;
import java.util.Comparator;
import java.util.List;

/**
 * Concrete Strategy: Sorts videos by average rating descending.
 */
public class TopRatedStrategy implements VideoSortStrategy {
    @Override
    public void sort(List<Video> videos) {
        if (videos != null) {
            videos.sort(Comparator.comparingDouble(Video::getAvgRating).reversed());
        }
    }

    @Override
    public String getStrategyName() {
        return "Top Rated";
    }
}
