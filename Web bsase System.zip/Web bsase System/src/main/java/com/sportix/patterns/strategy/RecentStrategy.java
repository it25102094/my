package com.sportix.patterns.strategy;

import com.sportix.model.Video;
import java.util.Comparator;
import java.util.List;

/**
 * Concrete Strategy: Sorts videos by newest creation timestamp descending.
 */
public class RecentStrategy implements VideoSortStrategy {
    @Override
    public void sort(List<Video> videos) {
        if (videos != null) {
            videos.sort((v1, v2) -> {
                if (v1.getCreatedAt() == null || v2.getCreatedAt() == null) return 0;
                return v2.getCreatedAt().compareTo(v1.getCreatedAt());
            });
        }
    }

    @Override
    public String getStrategyName() {
        return "Recently Added";
    }
}
