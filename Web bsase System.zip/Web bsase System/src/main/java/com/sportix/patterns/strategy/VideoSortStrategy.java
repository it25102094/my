package com.sportix.patterns.strategy;

import com.sportix.model.Video;
import java.util.List;

/**
 * Strategy Interface in the STRATEGY DESIGN PATTERN.
 * Allows interchangeable video ordering and recommendation algorithms
 * (e.g. by View Count, Recent Date, or Highest Rating).
 * Assigned to Member 2 (Video Browsing & Search Management).
 */
public interface VideoSortStrategy {
    void sort(List<Video> videos);
    String getStrategyName();
}
