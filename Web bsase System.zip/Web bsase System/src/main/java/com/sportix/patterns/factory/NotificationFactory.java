package com.sportix.patterns.factory;

import com.sportix.model.Notification;

/**
 * Implements the FACTORY DESIGN PATTERN.
 * Encapsulates the instantiation logic for various notification types
 * (TEAM_POST, MODERATION, PROMOTION, SYSTEM).
 * 
 * Satisfies SE2030 Design Pattern requirement.
 */
public class NotificationFactory {

    public enum NotificationType {
        TEAM_POST,
        MODERATION,
        PROMOTION,
        SYSTEM
    }

    /**
     * Factory method to generate standardized Notification domain objects.
     */
    public static Notification createNotification(NotificationType type, int userId, String subjectTitle, String detailMessage, Integer referenceId) {
        Notification notification = new Notification();
        notification.setUserId(userId);
        notification.setReferenceId(referenceId);
        notification.setRead(false);

        switch (type) {
            case TEAM_POST:
                notification.setType("TEAM_POST");
                notification.setTitle("New Upload: " + subjectTitle);
                notification.setMessage(detailMessage);
                break;

            case MODERATION:
                notification.setType("MODERATION");
                notification.setTitle("Moderation Notice: " + subjectTitle);
                notification.setMessage(detailMessage);
                break;

            case PROMOTION:
                notification.setType("PROMOTION");
                notification.setTitle("Sponsored: " + subjectTitle);
                notification.setMessage(detailMessage);
                break;

            case SYSTEM:
            default:
                notification.setType("SYSTEM");
                notification.setTitle("Sportix: " + subjectTitle);
                notification.setMessage(detailMessage);
                break;
        }

        return notification;
    }
}
