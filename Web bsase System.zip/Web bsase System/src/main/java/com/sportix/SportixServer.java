package com.sportix;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.awt.Desktop;
import java.io.*;
import java.net.InetSocketAddress;
import java.net.URI;
import java.nio.file.Files;
import java.util.concurrent.Executors;

/**
 * One-Click Server Launcher for IntelliJ IDEA & Eclipse.
 * Allows running the entire SPORTIX platform directly from IntelliJ with zero setup.
 * Simply right-click -> 'Run SportixServer.main()' in IntelliJ!
 */
public class SportixServer {

    private static final int DEFAULT_PORT = 8080;

    public static void main(String[] args) {
        try {
            int port = DEFAULT_PORT;
            File rootDir = locateProjectRoot();
            File webDir = new File(rootDir, "live-preview");

            if (!webDir.exists()) {
                webDir = new File(rootDir, "src/main/webapp");
            }

            HttpServer server;
            try {
                server = HttpServer.create(new InetSocketAddress("0.0.0.0", port), 0);
            } catch (IOException e) {
                // If 8080 is occupied, fallback to 8085
                port = 8085;
                server = HttpServer.create(new InetSocketAddress("0.0.0.0", port), 0);
            }

            server.createContext("/", new StaticFileHandler(webDir));
            server.setExecutor(Executors.newCachedThreadPool());
            server.start();

            String baseUrl = "http://localhost:" + port;
            System.out.println("==================================================================");
            System.out.println("          SPORTIX - Sports Video Browsing System");
            System.out.println("          IntelliJ IDEA Server Started Successfully!");
            System.out.println("==================================================================");
            System.out.println(" [✓] Server Port:        " + port);
            System.out.println(" [✓] Serving Directory:  " + webDir.getAbsolutePath());
            System.out.println(" [✓] Public Homepage:    " + baseUrl + "/index.html");
            System.out.println(" [✓] Master Admin Panel: " + baseUrl + "/admin.html");
            System.out.println(" [✓] Live Match & HUD:   " + baseUrl + "/watch.html?v=1");
            System.out.println("==================================================================");
            System.out.println(" Opening Master Admin Panel in your default browser...\n");

            // Open default browser automatically
            openBrowser(baseUrl + "/admin.html");

        } catch (Exception e) {
            System.err.println("Failed to start Sportix server: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static File locateProjectRoot() {
        File current = new File(".").getAbsoluteFile();
        if (new File(current, "live-preview").exists() || new File(current, "src").exists()) {
            return current;
        }
        File parent = current.getParentFile();
        if (parent != null && (new File(parent, "live-preview").exists() || new File(parent, "src").exists())) {
            return parent;
        }
        return current;
    }

    private static void openBrowser(String url) {
        try {
            if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
                Desktop.getDesktop().browse(new URI(url));
            } else {
                // Fallback for Windows
                Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + url);
            }
        } catch (Exception ignored) {}
    }

    static class StaticFileHandler implements HttpHandler {
        private final File baseDir;

        public StaticFileHandler(File baseDir) {
            this.baseDir = baseDir;
        }

        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String path = exchange.getRequestURI().getPath();
            if (path.equals("/") || path.isEmpty()) {
                path = "/index.html";
            }

            File requestedFile = new File(baseDir, path.substring(1)).getCanonicalFile();

            // Prevent directory traversal
            if (!requestedFile.getPath().startsWith(baseDir.getCanonicalPath()) || !requestedFile.exists() || requestedFile.isDirectory()) {
                String response = "<h1>404 Not Found - Sportix Server</h1>";
                exchange.sendResponseHeaders(404, response.length());
                OutputStream os = exchange.getResponseBody();
                os.write(response.getBytes());
                os.close();
                return;
            }

            String contentType = determineContentType(requestedFile.getName());
            exchange.getResponseHeaders().set("Content-Type", contentType);
            exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");

            exchange.sendResponseHeaders(200, requestedFile.length());
            try (InputStream is = new FileInputStream(requestedFile);
                 OutputStream os = exchange.getResponseBody()) {
                byte[] buffer = new byte[8192];
                int bytesRead;
                while ((bytesRead = is.read(buffer)) != -1) {
                    os.write(buffer, 0, bytesRead);
                }
            }
        }

        private String determineContentType(String fileName) {
            if (fileName.endsWith(".html") || fileName.endsWith(".jsp")) return "text/html; charset=UTF-8";
            if (fileName.endsWith(".css")) return "text/css; charset=UTF-8";
            if (fileName.endsWith(".js")) return "application/javascript; charset=UTF-8";
            if (fileName.endsWith(".json")) return "application/json; charset=UTF-8";
            if (fileName.endsWith(".png")) return "image/png";
            if (fileName.endsWith(".jpg") || fileName.endsWith(".jpeg")) return "image/jpeg";
            if (fileName.endsWith(".svg")) return "image/svg+xml";
            return "text/plain";
        }
    }
}
