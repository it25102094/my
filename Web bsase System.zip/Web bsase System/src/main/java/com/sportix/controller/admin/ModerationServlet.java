package com.sportix.controller.admin;

import com.sportix.dao.AdminDAO;
import com.sportix.dao.EngagementDAO;
import com.sportix.dao.VideoDAO;
import com.sportix.model.Report;
import com.sportix.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

/**
 * Controller for Content Moderation Queue (UC-06: Approve or Reject Content).
 * Assigned to Member 6 (IT25102092 - Samarasingha S.A.A.K.B.).
 */
@WebServlet(name = "ModerationServlet", urlPatterns = {"/admin/moderation", "/admin/moderation/resolve"})
public class ModerationServlet extends HttpServlet {

    private final AdminDAO adminDAO = new AdminDAO();
    private final VideoDAO videoDAO = new VideoDAO();
    private final EngagementDAO engagementDAO = new EngagementDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        User currentUser = (session != null) ? (User) session.getAttribute("currentUser") : null;

        if (currentUser == null || !currentUser.isAdmin()) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        List<Report> pendingReports = adminDAO.getPendingReports();
        request.setAttribute("pendingReports", pendingReports);

        request.getRequestDispatcher("/WEB-INF/views/admin/moderation.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {

        HttpSession session = request.getSession(false);
        User currentUser = (session != null) ? (User) session.getAttribute("currentUser") : null;

        if (currentUser == null || !currentUser.isAdmin()) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String reportIdStr = request.getParameter("reportId");
        String action = request.getParameter("action"); // 'APPROVE_PENALTY' or 'DISMISS'
        String targetType = request.getParameter("targetType");
        String targetIdStr = request.getParameter("targetId");
        String notes = request.getParameter("adminNotes");

        if (reportIdStr != null && action != null) {
            try {
                int reportId = Integer.parseInt(reportIdStr);
                int targetId = Integer.parseInt(targetIdStr);

                if ("APPROVE_PENALTY".equals(action)) {
                    // Punish/hide violating content
                    if ("COMMENT".equalsIgnoreCase(targetType)) {
                        engagementDAO.deleteComment(targetId, 0, true);
                    } else if ("VIDEO".equalsIgnoreCase(targetType)) {
                        adminDAO.updateVideoStatus(targetId, "REJECTED");
                    }
                    adminDAO.resolveReport(reportId, "APPROVED", notes != null ? notes : "Content removed per platform safety guidelines.");
                } else {
                    // Dismiss false report
                    adminDAO.resolveReport(reportId, "DISMISSED", notes != null ? notes : "No violation found.");
                }

            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
        response.sendRedirect(request.getContextPath() + "/admin/moderation?success=true");
    }
}
