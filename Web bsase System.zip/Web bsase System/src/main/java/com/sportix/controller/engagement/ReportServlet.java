package com.sportix.controller.engagement;

import com.sportix.dao.EngagementDAO;
import com.sportix.model.Report;
import com.sportix.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Controller for Reporting Videos or Comments (UC-04: Report Video or Comment).
 * Assigned to Member 4 (IT25102091 - Wijesekara W.M.B.S.).
 */
@WebServlet(name = "ReportServlet", urlPatterns = {"/report/submit"})
public class ReportServlet extends HttpServlet {

    private final EngagementDAO engagementDAO = new EngagementDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        User currentUser = (session != null) ? (User) session.getAttribute("currentUser") : null;

        if (currentUser == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String targetType = request.getParameter("targetType"); // 'VIDEO' or 'COMMENT'
        String targetIdStr = request.getParameter("targetId");
        String reason = request.getParameter("reason");
        String description = request.getParameter("description");
        String returnVideoId = request.getParameter("returnVideoId");

        if (targetType != null && targetIdStr != null && reason != null) {
            try {
                int targetId = Integer.parseInt(targetIdStr.trim());

                Report report = new Report();
                report.setReporterId(currentUser.getUserId());
                report.setTargetType(targetType.toUpperCase());
                report.setTargetId(targetId);
                report.setReason(reason.trim());
                report.setDescription(description != null ? description.trim() : "");

                boolean submitted = engagementDAO.submitReport(report);

                if (returnVideoId != null && !returnVideoId.isEmpty()) {
                    if (submitted) {
                        response.sendRedirect(request.getContextPath() + "/watch?v=" + returnVideoId + "&reported=success");
                    } else {
                        response.sendRedirect(request.getContextPath() + "/watch?v=" + returnVideoId + "&reported=duplicate");
                    }
                    return;
                }

            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
        response.sendRedirect(request.getContextPath() + "/home");
    }
}
