package com.sportix.controller.ads;

import com.sportix.dao.AdvertisementDAO;
import com.sportix.model.Advertisement;
import com.sportix.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Date;
import java.util.List;

/**
 * Controller for Managing Advertisement Campaigns (UC-05: Create Advertisement Campaign).
 * Assigned to Member 5 (IT25102094 - Thilakarathna S.H.S.D.).
 */
@WebServlet(name = "ManageAdsServlet", urlPatterns = {"/ads", "/ads/create", "/ads/delete"})
public class ManageAdsServlet extends HttpServlet {

    private final AdvertisementDAO adDAO = new AdvertisementDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        User currentUser = (session != null) ? (User) session.getAttribute("currentUser") : null;

        if (currentUser == null || (!currentUser.isAdvertiser() && !currentUser.isAdmin())) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        List<Advertisement> campaigns = adDAO.getAdsByAdvertiser(currentUser.getUserId());
        request.setAttribute("campaigns", campaigns);
        request.getRequestDispatcher("/WEB-INF/views/ads/manage-ads.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        User currentUser = (session != null) ? (User) session.getAttribute("currentUser") : null;

        if (currentUser == null || (!currentUser.isAdvertiser() && !currentUser.isAdmin())) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String path = request.getServletPath();

        if ("/ads/delete".equals(path)) {
            String adIdStr = request.getParameter("adId");
            if (adIdStr != null) {
                try {
                    int adId = Integer.parseInt(adIdStr);
                    adDAO.deleteAd(adId, currentUser.getUserId(), currentUser.isAdmin());
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }
            }
            response.sendRedirect(request.getContextPath() + "/ads");
            return;
        }

        // Create new Campaign (UC-05 Flow)
        String title = request.getParameter("title");
        String adType = request.getParameter("adType");
        String imageUrl = request.getParameter("imageUrl");
        String targetUrl = request.getParameter("targetUrl");
        String startDateStr = request.getParameter("startDate");
        String endDateStr = request.getParameter("endDate");
        String priorityStr = request.getParameter("priority");

        // Input validation
        if (title == null || title.trim().isEmpty() || imageUrl == null || targetUrl == null 
                || startDateStr == null || endDateStr == null) {
            request.setAttribute("errorMessage", "All fields are required to schedule an advertisement campaign.");
            doGet(request, response);
            return;
        }

        Date startDate = Date.valueOf(startDateStr);
        Date endDate = Date.valueOf(endDateStr);

        // Date Validation: End date must be on or after start date (from Lab 04)
        if (endDate.before(startDate)) {
            request.setAttribute("errorMessage", "Campaign End Date must be after Start Date.");
            doGet(request, response);
            return;
        }

        int priority = 1;
        try {
            if (priorityStr != null) {
                priority = Integer.parseInt(priorityStr);
            }
        } catch (NumberFormatException ignored) {}

        Advertisement ad = new Advertisement();
        ad.setAdvertiserId(currentUser.getUserId());
        ad.setTitle(title.trim());
        ad.setAdType(adType != null ? adType : "BANNER");
        ad.setImageUrl(imageUrl.trim());
        ad.setTargetUrl(targetUrl.trim());
        ad.setStartDate(startDate);
        ad.setEndDate(endDate);
        ad.setPriority(priority);
        ad.setStatus("ACTIVE");

        boolean created = adDAO.createAd(ad);

        if (created) {
            response.sendRedirect(request.getContextPath() + "/ads?created=true");
        } else {
            request.setAttribute("errorMessage", "Failed to schedule advertisement campaign.");
            doGet(request, response);
        }
    }
}
