package com.sportix.controller.user;

import com.sportix.dao.UserDAO;
import com.sportix.model.User;
import com.sportix.model.WatchLater;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

/**
 * Controller for Managing Watch Later List.
 * Assigned to Member 1 (IT25102095 - Pasandul H.L.A.).
 */
@WebServlet(name = "WatchLaterServlet", urlPatterns = {"/watch-later", "/watch-later/add", "/watch-later/remove"})
public class WatchLaterServlet extends HttpServlet {

    private final UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        User currentUser = (session != null) ? (User) session.getAttribute("currentUser") : null;

        if (currentUser == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        List<WatchLater> list = userDAO.getWatchLaterVideos(currentUser.getUserId());
        request.setAttribute("watchLaterList", list);
        request.getRequestDispatcher("/WEB-INF/views/user/watchlater.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        HttpSession session = request.getSession(false);
        User currentUser = (session != null) ? (User) session.getAttribute("currentUser") : null;

        if (currentUser == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String path = request.getServletPath();
        String videoIdStr = request.getParameter("videoId");

        if (videoIdStr != null) {
            try {
                int videoId = Integer.parseInt(videoIdStr);
                if ("/watch-later/add".equals(path)) {
                    userDAO.addToWatchLater(currentUser.getUserId(), videoId);
                } else if ("/watch-later/remove".equals(path)) {
                    userDAO.removeFromWatchLater(currentUser.getUserId(), videoId);
                }
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }

        String redirectUrl = request.getParameter("redirect");
        if (redirectUrl != null && !redirectUrl.isEmpty()) {
            response.sendRedirect(redirectUrl);
        } else {
            response.sendRedirect(request.getContextPath() + "/watch-later");
        }
    }
}
