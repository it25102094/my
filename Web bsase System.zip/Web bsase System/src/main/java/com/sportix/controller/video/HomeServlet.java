package com.sportix.controller.video;

import com.sportix.dao.AdvertisementDAO;
import com.sportix.dao.NotificationDAO;
import com.sportix.dao.UserDAO;
import com.sportix.dao.VideoDAO;
import com.sportix.model.Advertisement;
import com.sportix.model.Category;
import com.sportix.model.Team;
import com.sportix.model.User;
import com.sportix.model.Video;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Controller for Homepage & Main Video Browsing Feed.
 * Assigned to Member 2 (IT25102096 - Yashodhya H.N.).
 */
@WebServlet(name = "HomeServlet", urlPatterns = {"", "/home"})
public class HomeServlet extends HttpServlet {

    private final VideoDAO videoDAO = new VideoDAO();
    private final AdvertisementDAO adDAO = new AdvertisementDAO();
    private final NotificationDAO notificationDAO = new NotificationDAO();
    private final UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        User currentUser = (session != null) ? (User) session.getAttribute("currentUser") : null;

        // Fetch categories & featured videos
        List<Category> categories = videoDAO.getAllCategories();
        List<Video> featuredVideos = videoDAO.getFeaturedVideos();
        List<Video> allVideos = videoDAO.getAllApprovedVideos();

        // Categorize into sections
        List<Video> highlights = allVideos.stream()
                .filter(v -> "HIGHLIGHT".equalsIgnoreCase(v.getVideoType()))
                .limit(8)
                .collect(Collectors.toList());

        List<Video> shorts = allVideos.stream()
                .filter(v -> "SHORT".equalsIgnoreCase(v.getVideoType()))
                .limit(6)
                .collect(Collectors.toList());

        List<Video> liveVideos = allVideos.stream()
                .filter(v -> "LIVE".equalsIgnoreCase(v.getVideoType()))
                .limit(4)
                .collect(Collectors.toList());

        // Banner advertisement (Member 5)
        List<Advertisement> banners = adDAO.getActiveAds("BANNER");
        if (!banners.isEmpty()) {
            Advertisement topBanner = banners.get(0);
            adDAO.incrementImpressions(topBanner.getAdId());
            request.setAttribute("topBanner", topBanner);
        }

        // Notification count for logged-in users
        if (currentUser != null) {
            int unreadCount = notificationDAO.getUnreadCount(currentUser.getUserId());
            session.setAttribute("unreadNotifications", unreadCount);
            
            // Personalised feed: get followed teams
            List<Team> followedTeams = userDAO.getFollowedTeams(currentUser.getUserId());
            request.setAttribute("followedTeams", followedTeams);
        }

        request.setAttribute("categories", categories);
        request.setAttribute("featuredVideos", featuredVideos);
        request.setAttribute("highlights", highlights);
        request.setAttribute("shorts", shorts);
        request.setAttribute("liveVideos", liveVideos);

        request.getRequestDispatcher("/WEB-INF/views/video/home.jsp").forward(request, response);
    }
}
