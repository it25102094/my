package com.sportix.controller.auth;

import com.sportix.dao.UserDAO;
import com.sportix.model.User;
import com.sportix.util.PasswordUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Controller for User Registration (UC-01: Register Account).
 * Assigned to Member 1 (IT25102095 - Pasandul H.L.A.).
 */
@WebServlet(name = "RegisterServlet", urlPatterns = {"/register"})
public class RegisterServlet extends HttpServlet {

    private final UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        request.getRequestDispatcher("/WEB-INF/views/user/register.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String displayName = request.getParameter("displayName");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirmPassword");
        String role = request.getParameter("role"); // User role assignment (Defaults to REGISTERED)

        // Strict Server-side Input Validation
        if (username == null || username.trim().length() < 3) {
            forwardWithError(request, response, "Username must be at least 3 characters long.");
            return;
        }

        if (email == null || !email.matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            forwardWithError(request, response, "Please provide a valid email address.");
            return;
        }

        if (password == null || password.length() < 6) {
            forwardWithError(request, response, "Password must be at least 6 characters long.");
            return;
        }

        if (!password.equals(confirmPassword)) {
            forwardWithError(request, response, "Passwords do not match.");
            return;
        }

        // Check uniqueness
        if (userDAO.authenticate(username.trim()) != null) {
            forwardWithError(request, response, "Username or email is already taken. Please choose another or login.");
            return;
        }

        // Hash password securely with SHA-256
        String passwordHash = PasswordUtil.hashPassword(password);

        User newUser = new User();
        newUser.setUsername(username.trim());
        newUser.setEmail(email.trim());
        newUser.setDisplayName(displayName != null && !displayName.trim().isEmpty() ? displayName.trim() : username.trim());
        newUser.setPasswordHash(passwordHash);
        newUser.setRole(role != null && !role.isEmpty() ? role : "REGISTERED");

        boolean created = userDAO.registerUser(newUser);

        if (created) {
            // Auto login user into session
            HttpSession session = request.getSession(true);
            session.setAttribute("currentUser", newUser);
            session.setAttribute("userId", newUser.getUserId());
            session.setAttribute("userRole", newUser.getRole());
            session.setAttribute("displayName", newUser.getDisplayName());

            response.sendRedirect(request.getContextPath() + "/home?welcome=true");
        } else {
            forwardWithError(request, response, "Registration failed due to a system error. Please try again.");
        }
    }

    private void forwardWithError(HttpServletRequest request, HttpServletResponse response, String errorMsg) 
            throws ServletException, IOException {
        request.setAttribute("errorMessage", errorMsg);
        request.setAttribute("username", request.getParameter("username"));
        request.setAttribute("email", request.getParameter("email"));
        request.setAttribute("displayName", request.getParameter("displayName"));
        request.getRequestDispatcher("/WEB-INF/views/user/register.jsp").forward(request, response);
    }
}
