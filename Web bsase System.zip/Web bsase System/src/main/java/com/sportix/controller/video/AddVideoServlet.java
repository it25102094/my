package com.sportix.controller.video;

import com.sportix.dao.UserDAO;
import com.sportix.dao.VideoDAO;
import com.sportix.model.Category;
import com.sportix.model.Team;
import com.sportix.model.User;
import com.sportix.model.Video;
import com.sportix.patterns.observer.TeamNotificationSubject;
import com.sportix.util.YouTubeHelper;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Date;
import java.util.List;

/**
 * Controller for Uploading/Adding Sports Videos (UC-03: Add Sports Video).
 * Assigned to Member 3 (IT25102093 - Jayawardhana M.A.H.F.).
 * Triggers the OBSERVER DESIGN PATTERN to notify followers when a team video is published.
 */
@WebServlet(name = "AddVideoServlet", urlPatterns = {"/add-video"})
public class AddVideoServlet extends HttpServlet {

    private final VideoDAO videoDAO = new VideoDAO();
    private final UserDAO userDAO = new UserDAO();
    private final TeamNotificationSubject notificationSubject = new TeamNotificationSubject();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        User currentUser = (session != null) ? (User) session.getAttribute("currentUser") : null;

        if (currentUser == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        List<Category> categories = videoDAO.getAllCategories();
        List<Team> teams = videoDAO.getAllTeams();

        request.setAttribute("categories", categories);
        request.setAttribute("teams", teams);
        request.getRequestDispatcher("/WEB-INF/views/video/add-video.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        User currentUser = (session != null) ? (User) session.getAttribute("currentUser") : null;

        if (currentUser == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String title = request.getParameter("title");
        String description = request.getParameter("description");
        String youtubeUrl = request.getParameter("youtubeUrl");
        String categoryIdStr = request.getParameter("categoryId");
        String teamIdStr = request.getParameter("teamId");
        String videoType = request.getParameter("videoType");
        String matchScore = request.getParameter("matchScore");
        String isFeaturedParam = request.getParameter("isFeatured");
        String startDateStr = request.getParameter("featuredStartDate");
        String endDateStr = request.getParameter("featuredEndDate");

        // Validate YouTube link format
        String videoId = YouTubeHelper.extractVideoId(youtubeUrl);
        if (videoId == null) {
            request.setAttribute("errorMessage", "Invalid YouTube URL. Please enter a valid YouTube video or shorts link.");
            doGet(request, response);
            return;
        }

        if (title == null || title.trim().isEmpty() || categoryIdStr == null) {
            request.setAttribute("errorMessage", "Title and Category are mandatory.");
            doGet(request, response);
            return;
        }

        Video video = new Video();
        video.setTitle(title.trim());
        video.setDescription(description != null ? description.trim() : "");
        video.setYoutubeUrl(youtubeUrl.trim());
        video.setYoutubeVideoId(videoId);
        video.setThumbnailUrl(YouTubeHelper.getDefaultThumbnailUrl(videoId));
        video.setCategoryId(Integer.parseInt(categoryIdStr));
        
        Integer teamId = null;
        if (teamIdStr != null && !teamIdStr.trim().isEmpty() && !"0".equals(teamIdStr)) {
            teamId = Integer.parseInt(teamIdStr);
            video.setTeamId(teamId);
        }

        video.setVideoType(videoType != null ? videoType : "HIGHLIGHT");
        video.setMatchScore(matchScore != null && !matchScore.trim().isEmpty() ? matchScore.trim() : null);
        video.setUploaderId(currentUser.getUserId());

        // Role-Based publishing rules (NFR2 - RBAC)
        if (currentUser.isContentManager() || currentUser.isAdmin()) {
            video.setStatus("APPROVED");
        } else {
            video.setStatus("PENDING"); // Registered users submissions require moderation (UC-06)
        }

        // Featured Video scheduling
        boolean isFeatured = "true".equalsIgnoreCase(isFeaturedParam) || "on".equalsIgnoreCase(isFeaturedParam);
        video.setFeatured(isFeatured);
        if (isFeatured) {
            if (startDateStr != null && !startDateStr.isEmpty()) {
                video.setFeaturedStartDate(Date.valueOf(startDateStr));
            }
            if (endDateStr != null && !endDateStr.isEmpty()) {
                video.setFeaturedEndDate(Date.valueOf(endDateStr));
            }
        }

        boolean saved = videoDAO.addVideo(video);

        if (saved) {
            // If published directly for a team, trigger OBSERVER PATTERN to notify followers
            if ("APPROVED".equals(video.getStatus()) && teamId != null) {
                List<Integer> followers = userDAO.getTeamFollowerUserIds(teamId);
                notificationSubject.dispatchTeamUploadNotification(video, followers);
            }

            if ("APPROVED".equals(video.getStatus())) {
                response.sendRedirect(request.getContextPath() + "/watch?v=" + video.getVideoId() + "&published=true");
            } else {
                response.sendRedirect(request.getContextPath() + "/home?submitted=pending");
            }
        } else {
            request.setAttribute("errorMessage", "Error saving video to database. Please check values.");
            doGet(request, response);
        }
    }
}
