package com.sportix.controller.ads;

import com.sportix.dao.NotificationDAO;
import com.sportix.model.Notification;
import com.sportix.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

/**
 * Controller for Viewing & Managing User Notifications.
 * Assigned to Member 5 (IT25102094 - Thilakarathna S.H.S.D.).
 */
@WebServlet(name = "NotificationServlet", urlPatterns = {"/notifications", "/notifications/read"})
public class NotificationServlet extends HttpServlet {

    private final NotificationDAO notificationDAO = new NotificationDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        User currentUser = (session != null) ? (User) session.getAttribute("currentUser") : null;

        if (currentUser == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        List<Notification> list = notificationDAO.getUserNotifications(currentUser.getUserId());
        request.setAttribute("notifications", list);
        request.getRequestDispatcher("/WEB-INF/views/user/notifications.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {

        HttpSession session = request.getSession(false);
        User currentUser = (session != null) ? (User) session.getAttribute("currentUser") : null;

        if (currentUser == null) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            return;
        }

        String idStr = request.getParameter("notificationId");
        if (idStr != null) {
            try {
                int notifId = Integer.parseInt(idStr);
                notificationDAO.markAsRead(notifId, currentUser.getUserId());
                response.setStatus(HttpServletResponse.SC_OK);
                return;
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
        response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
    }
}
