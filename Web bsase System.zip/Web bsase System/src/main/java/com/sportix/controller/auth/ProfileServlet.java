package com.sportix.controller.auth;

import com.sportix.dao.UserDAO;
import com.sportix.dao.VideoDAO;
import com.sportix.model.Team;
import com.sportix.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

/**
 * Controller for User Profile Management & Following Teams.
 * Assigned to Member 1 (IT25102095 - Pasandul H.L.A.).
 */
@WebServlet(name = "ProfileServlet", urlPatterns = {"/profile", "/follow-team", "/unfollow-team"})
public class ProfileServlet extends HttpServlet {

    private final UserDAO userDAO = new UserDAO();
    private final VideoDAO videoDAO = new VideoDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        User currentUser = (session != null) ? (User) session.getAttribute("currentUser") : null;

        if (currentUser == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        // Fetch followed teams
        List<Team> followedTeams = userDAO.getFollowedTeams(currentUser.getUserId());
        List<Team> allTeams = videoDAO.getAllTeams();

        request.setAttribute("user", currentUser);
        request.setAttribute("followedTeams", followedTeams);
        request.setAttribute("allTeams", allTeams);
        request.getRequestDispatcher("/WEB-INF/views/user/profile.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        User currentUser = (session != null) ? (User) session.getAttribute("currentUser") : null;

        if (currentUser == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String path = request.getServletPath();

        if ("/follow-team".equals(path)) {
            String teamIdStr = request.getParameter("teamId");
            if (teamIdStr != null) {
                userDAO.followTeam(currentUser.getUserId(), Integer.parseInt(teamIdStr));
            }
            response.sendRedirect(request.getContextPath() + "/profile");
            return;
        }

        if ("/unfollow-team".equals(path)) {
            String teamIdStr = request.getParameter("teamId");
            if (teamIdStr != null) {
                userDAO.unfollowTeam(currentUser.getUserId(), Integer.parseInt(teamIdStr));
            }
            response.sendRedirect(request.getContextPath() + "/profile");
            return;
        }

        // Profile Update
        String displayName = request.getParameter("displayName");
        String email = request.getParameter("email");

        if (displayName != null && email != null) {
            currentUser.setDisplayName(displayName.trim());
            currentUser.setEmail(email.trim());
            boolean updated = userDAO.updateProfile(currentUser);
            if (updated) {
                session.setAttribute("currentUser", currentUser);
                session.setAttribute("displayName", currentUser.getDisplayName());
                request.setAttribute("successMessage", "Profile updated successfully!");
            } else {
                request.setAttribute("errorMessage", "Failed to update profile.");
            }
        }
        doGet(request, response);
    }
}
