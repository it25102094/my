package com.sportix.controller.video;

import com.sportix.dao.AdvertisementDAO;
import com.sportix.dao.EngagementDAO;
import com.sportix.dao.UserDAO;
import com.sportix.dao.VideoDAO;
import com.sportix.model.Advertisement;
import com.sportix.model.Comment;
import com.sportix.model.User;
import com.sportix.model.Video;
import com.sportix.util.YouTubeHelper;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

/**
 * Controller for Video Watching, Embedded Player, and Engagement interactions.
 * Bridges Member 2 (Video Browsing) and Member 4 (User Engagement).
 */
@WebServlet(name = "WatchServlet", urlPatterns = {"/watch"})
public class WatchServlet extends HttpServlet {

    private final VideoDAO videoDAO = new VideoDAO();
    private final EngagementDAO engagementDAO = new EngagementDAO();
    private final UserDAO userDAO = new UserDAO();
    private final AdvertisementDAO adDAO = new AdvertisementDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        String idParam = request.getParameter("v");
        if (idParam == null || idParam.trim().isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/home");
            return;
        }

        try {
            int videoId = Integer.parseInt(idParam.trim());
            Video video = videoDAO.getVideoById(videoId);

            if (video == null) {
                response.sendRedirect(request.getContextPath() + "/home?error=notfound");
                return;
            }

            // Increment view counter
            videoDAO.incrementViewCount(videoId);
            video.setViewCount(video.getViewCount() + 1);

            // YouTube Embed URL
            String embedUrl = YouTubeHelper.getEmbedUrl(video.getYoutubeVideoId());
            request.setAttribute("embedUrl", embedUrl);

            // Fetch comments
            List<Comment> comments = engagementDAO.getCommentsByVideoId(videoId);
            request.setAttribute("comments", comments);

            // User-specific engagement state (if logged in)
            HttpSession session = request.getSession(false);
            User currentUser = (session != null) ? (User) session.getAttribute("currentUser") : null;

            if (currentUser != null) {
                Integer userLike = engagementDAO.getUserLikeStatus(currentUser.getUserId(), videoId);
                Integer userRating = engagementDAO.getUserRating(currentUser.getUserId(), videoId);
                boolean isSaved = userDAO.isVideoInWatchLater(currentUser.getUserId(), videoId);

                request.setAttribute("userLikeStatus", userLike);
                request.setAttribute("userRating", userRating);
                request.setAttribute("isSavedInWatchLater", isSaved);
            }

            // Related videos recommendation
            List<Video> relatedVideos = videoDAO.searchAndFilterVideos(null, video.getCategoryId(), null, null);
            relatedVideos.removeIf(v -> v.getVideoId() == videoId);
            request.setAttribute("relatedVideos", relatedVideos);

            // Sidebar ad
            List<Advertisement> sidebarAds = adDAO.getActiveAds("SIDEBAR");
            if (!sidebarAds.isEmpty()) {
                Advertisement sidebarAd = sidebarAds.get(0);
                adDAO.incrementImpressions(sidebarAd.getAdId());
                request.setAttribute("sidebarAd", sidebarAd);
            }

            request.setAttribute("video", video);
            request.getRequestDispatcher("/WEB-INF/views/video/watch.jsp").forward(request, response);

        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/home");
        }
    }
}
