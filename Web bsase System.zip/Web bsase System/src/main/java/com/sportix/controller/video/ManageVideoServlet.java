package com.sportix.controller.video;

import com.sportix.dao.VideoDAO;
import com.sportix.model.Category;
import com.sportix.model.Team;
import com.sportix.model.User;
import com.sportix.model.Video;
import com.sportix.util.YouTubeHelper;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Date;
import java.util.List;

/**
 * Controller for Managing, Editing, and Deleting Videos.
 * Assigned to Member 3 (IT25102093 - Jayawardhana M.A.H.F.).
 */
@WebServlet(name = "ManageVideoServlet", urlPatterns = {"/manage-videos", "/video/edit", "/video/delete"})
public class ManageVideoServlet extends HttpServlet {

    private final VideoDAO videoDAO = new VideoDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        User currentUser = (session != null) ? (User) session.getAttribute("currentUser") : null;

        if (currentUser == null || (!currentUser.isContentManager() && !currentUser.isAdmin())) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String path = request.getServletPath();

        if ("/video/edit".equals(path)) {
            String videoIdStr = request.getParameter("id");
            if (videoIdStr != null) {
                try {
                    int videoId = Integer.parseInt(videoIdStr);
                    Video video = videoDAO.getVideoById(videoId);
                    List<Category> categories = videoDAO.getAllCategories();
                    List<Team> teams = videoDAO.getAllTeams();

                    request.setAttribute("video", video);
                    request.setAttribute("categories", categories);
                    request.setAttribute("teams", teams);
                    request.getRequestDispatcher("/WEB-INF/views/video/edit-video.jsp").forward(request, response);
                    return;
                } catch (NumberFormatException ignored) {}
            }
        }

        // List videos
        List<Video> videos = videoDAO.getAllApprovedVideos();
        request.setAttribute("videos", videos);
        request.getRequestDispatcher("/WEB-INF/views/video/manage-videos.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        User currentUser = (session != null) ? (User) session.getAttribute("currentUser") : null;

        if (currentUser == null || (!currentUser.isContentManager() && !currentUser.isAdmin())) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String path = request.getServletPath();

        if ("/video/delete".equals(path)) {
            String videoIdStr = request.getParameter("videoId");
            if (videoIdStr != null) {
                try {
                    int videoId = Integer.parseInt(videoIdStr);
                    videoDAO.deleteVideo(videoId);
                } catch (NumberFormatException ignored) {}
            }
            response.sendRedirect(request.getContextPath() + "/manage-videos?deleted=true");
            return;
        }

        // Edit Video submission
        String videoIdStr = request.getParameter("videoId");
        String title = request.getParameter("title");
        String description = request.getParameter("description");
        String youtubeUrl = request.getParameter("youtubeUrl");
        String categoryIdStr = request.getParameter("categoryId");
        String teamIdStr = request.getParameter("teamId");
        String videoType = request.getParameter("videoType");
        String matchScore = request.getParameter("matchScore");
        String isFeaturedParam = request.getParameter("isFeatured");
        String startDateStr = request.getParameter("featuredStartDate");
        String endDateStr = request.getParameter("featuredEndDate");

        String videoIdExt = YouTubeHelper.extractVideoId(youtubeUrl);
        if (videoIdExt == null) {
            request.setAttribute("errorMessage", "Invalid YouTube URL.");
            doGet(request, response);
            return;
        }

        try {
            Video video = new Video();
            video.setVideoId(Integer.parseInt(videoIdStr));
            video.setTitle(title.trim());
            video.setDescription(description != null ? description.trim() : "");
            video.setYoutubeUrl(youtubeUrl.trim());
            video.setYoutubeVideoId(videoIdExt);
            video.setThumbnailUrl(YouTubeHelper.getDefaultThumbnailUrl(videoIdExt));
            video.setCategoryId(Integer.parseInt(categoryIdStr));

            if (teamIdStr != null && !teamIdStr.trim().isEmpty() && !"0".equals(teamIdStr)) {
                video.setTeamId(Integer.parseInt(teamIdStr));
            } else {
                video.setTeamId(null);
            }

            video.setVideoType(videoType != null ? videoType : "HIGHLIGHT");
            video.setMatchScore(matchScore != null && !matchScore.trim().isEmpty() ? matchScore.trim() : null);

            boolean isFeatured = "true".equalsIgnoreCase(isFeaturedParam) || "on".equalsIgnoreCase(isFeaturedParam);
            video.setFeatured(isFeatured);
            if (isFeatured) {
                if (startDateStr != null && !startDateStr.isEmpty()) video.setFeaturedStartDate(Date.valueOf(startDateStr));
                if (endDateStr != null && !endDateStr.isEmpty()) video.setFeaturedEndDate(Date.valueOf(endDateStr));
            }

            videoDAO.updateVideo(video);
            response.sendRedirect(request.getContextPath() + "/manage-videos?updated=true");

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/manage-videos?error=true");
        }
    }
}
