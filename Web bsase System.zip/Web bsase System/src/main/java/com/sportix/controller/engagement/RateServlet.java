package com.sportix.controller.engagement;

import com.sportix.dao.EngagementDAO;
import com.sportix.dao.VideoDAO;
import com.sportix.model.User;
import com.sportix.model.Video;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Controller for Submitting Star Ratings (1 - 5 stars).
 * Assigned to Member 4 (IT25102091 - Wijesekara W.M.B.S.).
 */
@WebServlet(name = "RateServlet", urlPatterns = {"/video/rate"})
public class RateServlet extends HttpServlet {

    private final EngagementDAO engagementDAO = new EngagementDAO();
    private final VideoDAO videoDAO = new VideoDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {

        HttpSession session = request.getSession(false);
        User currentUser = (session != null) ? (User) session.getAttribute("currentUser") : null;

        if (currentUser == null) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.getWriter().write("{\"error\": \"Must be logged in\"}");
            return;
        }

        String videoIdStr = request.getParameter("videoId");
        String ratingStr = request.getParameter("rating");

        if (videoIdStr != null && ratingStr != null) {
            try {
                int videoId = Integer.parseInt(videoIdStr);
                int rating = Integer.parseInt(ratingStr);

                if (rating >= 1 && rating <= 5) {
                    engagementDAO.rateVideo(currentUser.getUserId(), videoId, rating);
                    Video video = videoDAO.getVideoById(videoId);

                    response.setContentType("application/json");
                    response.setCharacterEncoding("UTF-8");
                    String json = String.format(
                        "{\"success\": true, \"avgRating\": %.1f, \"userRating\": %d}",
                        video.getAvgRating(),
                        rating
                    );
                    response.getWriter().write(json);
                    return;
                }
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
        response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
    }
}
