package com.sportix.controller.admin;

import com.sportix.dao.EventDAO;
import com.sportix.model.Event;
import com.sportix.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Date;
import java.util.List;

/**
 * Controller for Sporting Events / Matches CRUD.
 * Supports Create, Read, Update, Delete, and live score updates.
 * Assigned to Member 3 (Content Management) & Member 6 (Admin Desk).
 */
@WebServlet(name = "AdminEventServlet", urlPatterns = {
    "/admin/events",
    "/admin/events/create",
    "/admin/events/update",
    "/admin/events/update-score",
    "/admin/events/delete"
})
public class AdminEventServlet extends HttpServlet {

    private final EventDAO eventDAO = new EventDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        User currentUser = (session != null) ? (User) session.getAttribute("currentUser") : null;

        if (currentUser == null || !currentUser.isAdmin()) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String servletPath = request.getServletPath();
        if ("/admin/events/delete".equals(servletPath)) {
            handleDelete(request, response);
            return;
        }

        List<Event> events = eventDAO.getAllEvents();
        request.setAttribute("eventList", events);
        response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=events");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        User currentUser = (session != null) ? (User) session.getAttribute("currentUser") : null;

        if (currentUser == null || !currentUser.isAdmin()) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Access Denied");
            return;
        }

        request.setCharacterEncoding("UTF-8");
        String servletPath = request.getServletPath();

        switch (servletPath) {
            case "/admin/events/create":
                handleCreate(request, response);
                break;
            case "/admin/events/update":
                handleUpdate(request, response);
                break;
            case "/admin/events/update-score":
                handleUpdateScore(request, response);
                break;
            case "/admin/events/delete":
                handleDelete(request, response);
                break;
            default:
                response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=events");
                break;
        }
    }

    private void handleCreate(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            String title = request.getParameter("title");
            int categoryId = Integer.parseInt(request.getParameter("categoryId"));
            String tournamentName = request.getParameter("tournamentName");
            int team1Id = Integer.parseInt(request.getParameter("team1Id"));
            int team2Id = Integer.parseInt(request.getParameter("team2Id"));
            Date eventDate = Date.valueOf(request.getParameter("eventDate"));
            String eventTime = request.getParameter("eventTime");
            String venue = request.getParameter("venue");
            String status = request.getParameter("status");
            String team1Score = request.getParameter("team1Score");
            String team2Score = request.getParameter("team2Score");
            String matchSummary = request.getParameter("matchSummary");
            
            String liveViewersStr = request.getParameter("liveViewers");
            int liveViewers = (liveViewersStr != null && !liveViewersStr.trim().isEmpty()) ? Integer.parseInt(liveViewersStr.trim()) : 0;
            
            String videoIdStr = request.getParameter("videoId");
            Integer videoId = (videoIdStr != null && !videoIdStr.trim().isEmpty()) ? Integer.parseInt(videoIdStr.trim()) : null;

            Event event = new Event();
            event.setTitle(title);
            event.setCategoryId(categoryId);
            event.setTournamentName(tournamentName);
            event.setTeam1Id(team1Id);
            event.setTeam2Id(team2Id);
            event.setEventDate(eventDate);
            event.setEventTime(eventTime);
            event.setVenue(venue);
            event.setStatus((status != null && !status.trim().isEmpty()) ? status.trim() : "UPCOMING");
            event.setTeam1Score(team1Score);
            event.setTeam2Score(team2Score);
            event.setMatchSummary(matchSummary);
            event.setLiveViewers(liveViewers);
            event.setVideoId(videoId);

            boolean success = eventDAO.createEvent(event);
            if (success) {
                response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=events&success=Event+created+successfully");
            } else {
                response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=events&error=Failed+to+create+event");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=events&error=Invalid+event+data");
        }
    }

    private void handleUpdate(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            int eventId = Integer.parseInt(request.getParameter("eventId"));
            String title = request.getParameter("title");
            int categoryId = Integer.parseInt(request.getParameter("categoryId"));
            String tournamentName = request.getParameter("tournamentName");
            int team1Id = Integer.parseInt(request.getParameter("team1Id"));
            int team2Id = Integer.parseInt(request.getParameter("team2Id"));
            Date eventDate = Date.valueOf(request.getParameter("eventDate"));
            String eventTime = request.getParameter("eventTime");
            String venue = request.getParameter("venue");
            String status = request.getParameter("status");
            String team1Score = request.getParameter("team1Score");
            String team2Score = request.getParameter("team2Score");
            String matchSummary = request.getParameter("matchSummary");
            
            String liveViewersStr = request.getParameter("liveViewers");
            int liveViewers = (liveViewersStr != null && !liveViewersStr.trim().isEmpty()) ? Integer.parseInt(liveViewersStr.trim()) : 0;
            
            String videoIdStr = request.getParameter("videoId");
            Integer videoId = (videoIdStr != null && !videoIdStr.trim().isEmpty()) ? Integer.parseInt(videoIdStr.trim()) : null;

            Event event = new Event();
            event.setEventId(eventId);
            event.setTitle(title);
            event.setCategoryId(categoryId);
            event.setTournamentName(tournamentName);
            event.setTeam1Id(team1Id);
            event.setTeam2Id(team2Id);
            event.setEventDate(eventDate);
            event.setEventTime(eventTime);
            event.setVenue(venue);
            event.setStatus(status);
            event.setTeam1Score(team1Score);
            event.setTeam2Score(team2Score);
            event.setMatchSummary(matchSummary);
            event.setLiveViewers(liveViewers);
            event.setVideoId(videoId);

            boolean success = eventDAO.updateEvent(event);
            if (success) {
                response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=events&success=Event+updated+successfully");
            } else {
                response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=events&error=Failed+to+update+event");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=events&error=Invalid+event+update+data");
        }
    }

    private void handleUpdateScore(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            int eventId = Integer.parseInt(request.getParameter("eventId"));
            String team1Score = request.getParameter("team1Score");
            String team2Score = request.getParameter("team2Score");
            String status = request.getParameter("status");
            String matchSummary = request.getParameter("matchSummary");

            boolean success = eventDAO.updateEventScoreAndStatus(eventId, team1Score, team2Score, status, matchSummary);
            
            String isAjax = request.getParameter("ajax");
            if ("true".equalsIgnoreCase(isAjax) || "XMLHttpRequest".equals(request.getHeader("X-Requested-With"))) {
                response.setContentType("application/json");
                response.setCharacterEncoding("UTF-8");
                response.getWriter().write("{\"success\":" + success + "}");
                return;
            }

            if (success) {
                response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=events&success=Score+updated+successfully");
            } else {
                response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=events&error=Failed+to+update+score");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=events&error=Invalid+score+data");
        }
    }

    private void handleDelete(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            int eventId = Integer.parseInt(request.getParameter("eventId"));
            boolean success = eventDAO.deleteEvent(eventId);
            if (success) {
                response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=events&success=Event+deleted+successfully");
            } else {
                response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=events&error=Failed+to+delete+event");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=events&error=Invalid+event+ID");
        }
    }
}
