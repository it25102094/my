package com.sportix.controller.engagement;

import com.sportix.dao.EngagementDAO;
import com.sportix.model.Comment;
import com.sportix.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Controller for Managing Video Comments (Create, Delete).
 * Assigned to Member 4 (IT25102091 - Wijesekara W.M.B.S.).
 */
@WebServlet(name = "CommentServlet", urlPatterns = {"/comment/add", "/comment/delete"})
public class CommentServlet extends HttpServlet {

    private final EngagementDAO engagementDAO = new EngagementDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        User currentUser = (session != null) ? (User) session.getAttribute("currentUser") : null;

        if (currentUser == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String path = request.getServletPath();

        if ("/comment/add".equals(path)) {
            String videoIdStr = request.getParameter("videoId");
            String content = request.getParameter("content");

            if (videoIdStr != null && content != null && !content.trim().isEmpty()) {
                try {
                    int videoId = Integer.parseInt(videoIdStr.trim());
                    Comment comment = new Comment();
                    comment.setUserId(currentUser.getUserId());
                    comment.setVideoId(videoId);
                    comment.setContent(content.trim());

                    engagementDAO.addComment(comment);
                    response.sendRedirect(request.getContextPath() + "/watch?v=" + videoId + "#comments");
                    return;
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }
            }
            response.sendRedirect(request.getContextPath() + "/home");
            return;
        }

        if ("/comment/delete".equals(path)) {
            String commentIdStr = request.getParameter("commentId");
            String videoIdStr = request.getParameter("videoId");

            if (commentIdStr != null && videoIdStr != null) {
                try {
                    int commentId = Integer.parseInt(commentIdStr.trim());
                    int videoId = Integer.parseInt(videoIdStr.trim());
                    
                    engagementDAO.deleteComment(commentId, currentUser.getUserId(), currentUser.isAdmin());
                    response.sendRedirect(request.getContextPath() + "/watch?v=" + videoId + "#comments");
                    return;
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }
            }
            response.sendRedirect(request.getContextPath() + "/home");
        }
    }
}
