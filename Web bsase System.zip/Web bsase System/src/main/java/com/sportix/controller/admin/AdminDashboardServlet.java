package com.sportix.controller.admin;

import com.sportix.dao.AdminDAO;
import com.sportix.dao.AdvertisementDAO;
import com.sportix.dao.EngagementDAO;
import com.sportix.dao.EventDAO;
import com.sportix.dao.UserDAO;
import com.sportix.dao.VideoDAO;
import com.sportix.model.Advertisement;
import com.sportix.model.Category;
import com.sportix.model.Comment;
import com.sportix.model.Event;
import com.sportix.model.Report;
import com.sportix.model.Team;
import com.sportix.model.User;
import com.sportix.model.Video;
import com.sportix.util.PasswordUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Date;
import java.util.List;
import java.util.Map;

/**
 * Unified Controller for Complete 6-Member Administration & Operations.
 * Empowers the Administrator to oversee and execute CRUD on:
 * - Member 1: User Accounts & Profiles
 * - Member 2: Sports Categories & Teams Taxonomy
 * - Member 3: Videos & Sporting Events/Fixtures
 * - Member 4: Community Comments & Ratings
 * - Member 5: Ad Campaigns & Notifications
 * - Member 6: System Analytics & Content Moderation Queue (UC-06)
 */
@WebServlet(name = "AdminDashboardServlet", urlPatterns = {
    "/admin/dashboard",
    "/admin/users/create",
    "/admin/users/update-role",
    "/admin/users/delete",
    "/admin/categories/create",
    "/admin/categories/delete",
    "/admin/teams/create",
    "/admin/teams/delete",
    "/admin/videos/status",
    "/admin/videos/delete",
    "/admin/comments/delete",
    "/admin/ads/create",
    "/admin/ads/status",
    "/admin/ads/delete"
})
public class AdminDashboardServlet extends HttpServlet {

    private final AdminDAO adminDAO = new AdminDAO();
    private final EventDAO eventDAO = new EventDAO();
    private final VideoDAO videoDAO = new VideoDAO();
    private final UserDAO userDAO = new UserDAO();
    private final EngagementDAO engagementDAO = new EngagementDAO();
    private final AdvertisementDAO advertisementDAO = new AdvertisementDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        User currentUser = (session != null) ? (User) session.getAttribute("currentUser") : null;

        if (currentUser == null || !currentUser.isAdmin()) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        // Aggregate datasets across all 6 members
        Map<String, Integer> stats = adminDAO.getDashboardStats();
        List<User> userList = adminDAO.getAllUsers();
        List<Category> categories = videoDAO.getAllCategories();
        List<Team> teams = videoDAO.getAllTeams();
        List<Event> eventList = eventDAO.getAllEvents();
        List<Video> videoList = videoDAO.getAllApprovedVideos();
        List<Comment> allComments = engagementDAO.getAllComments();
        List<Advertisement> adList = advertisementDAO.getAllAds();
        List<Report> pendingReports = adminDAO.getPendingReports();

        request.setAttribute("stats", stats);
        request.setAttribute("userList", userList);
        request.setAttribute("categories", categories);
        request.setAttribute("teams", teams);
        request.setAttribute("eventList", eventList);
        request.setAttribute("videoList", videoList);
        request.setAttribute("allComments", allComments);
        request.setAttribute("adList", adList);
        request.setAttribute("pendingReports", pendingReports);

        request.getRequestDispatcher("/WEB-INF/views/admin/dashboard.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {

        HttpSession session = request.getSession(false);
        User currentUser = (session != null) ? (User) session.getAttribute("currentUser") : null;

        if (currentUser == null || !currentUser.isAdmin()) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        request.setCharacterEncoding("UTF-8");
        String servletPath = request.getServletPath();

        switch (servletPath) {
            // Member 1: User Account CRUD
            case "/admin/users/create":
                handleCreateUser(request, response);
                break;
            case "/admin/users/update-role":
                handleUpdateUserRole(request, response);
                break;
            case "/admin/users/delete":
                handleDeleteUser(request, response);
                break;

            // Member 2: Categories & Teams CRUD
            case "/admin/categories/create":
                handleCreateCategory(request, response);
                break;
            case "/admin/categories/delete":
                handleDeleteCategory(request, response);
                break;
            case "/admin/teams/create":
                handleCreateTeam(request, response);
                break;
            case "/admin/teams/delete":
                handleDeleteTeam(request, response);
                break;

            // Member 3: Video Catalog Management
            case "/admin/videos/status":
                handleUpdateVideoStatus(request, response);
                break;
            case "/admin/videos/delete":
                handleDeleteVideo(request, response);
                break;

            // Member 4: Comments CRUD
            case "/admin/comments/delete":
                handleDeleteComment(request, response);
                break;

            // Member 5: Advertising Campaigns CRUD
            case "/admin/ads/create":
                handleCreateAd(request, response);
                break;
            case "/admin/ads/status":
                handleUpdateAdStatus(request, response);
                break;
            case "/admin/ads/delete":
                handleDeleteAd(request, response);
                break;

            default:
                response.sendRedirect(request.getContextPath() + "/admin/dashboard");
                break;
        }
    }

    // --- Member 1 Handlers ---
    private void handleCreateUser(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            String username = request.getParameter("username");
            String email = request.getParameter("email");
            String displayName = request.getParameter("displayName");
            String password = request.getParameter("password");
            String role = request.getParameter("role");

            User u = new User();
            u.setUsername(username);
            u.setEmail(email);
            u.setDisplayName(displayName);
            u.setPasswordHash(PasswordUtil.hashPassword(password));
            u.setRole(role != null ? role : "REGISTERED");

            boolean success = userDAO.registerUser(u);
            response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=users&" + (success ? "success=User+created" : "error=Failed+to+create+user"));
        } catch (Exception e) {
            response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=users&error=Invalid+user+data");
        }
    }

    private void handleUpdateUserRole(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            int userId = Integer.parseInt(request.getParameter("userId"));
            String newRole = request.getParameter("newRole");
            boolean success = adminDAO.updateUserRole(userId, newRole);
            response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=users&" + (success ? "success=Role+updated" : "error=Failed+to+update+role"));
        } catch (Exception e) {
            response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=users&error=Error");
        }
    }

    private void handleDeleteUser(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            int userId = Integer.parseInt(request.getParameter("userId"));
            boolean success = userDAO.deleteUser(userId);
            response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=users&" + (success ? "success=User+deleted" : "error=Failed+to+delete+user"));
        } catch (Exception e) {
            response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=users&error=Error");
        }
    }

    // --- Member 2 Handlers ---
    private void handleCreateCategory(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            String name = request.getParameter("name");
            String description = request.getParameter("description");
            String iconClass = request.getParameter("iconClass");

            Category c = new Category();
            c.setName(name);
            c.setSlug(name.toLowerCase().replaceAll("\\s+", "-"));
            c.setDescription(description);
            c.setIconClass(iconClass != null && !iconClass.isEmpty() ? iconClass : "fas fa-futbol");

            boolean success = videoDAO.createCategory(c);
            response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=categories&" + (success ? "success=Category+created" : "error=Failed"));
        } catch (Exception e) {
            response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=categories&error=Error");
        }
    }

    private void handleDeleteCategory(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            int categoryId = Integer.parseInt(request.getParameter("categoryId"));
            boolean success = videoDAO.deleteCategory(categoryId);
            response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=categories&" + (success ? "success=Category+deleted" : "error=Failed"));
        } catch (Exception e) {
            response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=categories&error=Error");
        }
    }

    private void handleCreateTeam(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            String name = request.getParameter("name");
            int categoryId = Integer.parseInt(request.getParameter("categoryId"));
            String country = request.getParameter("country");
            String logoUrl = request.getParameter("logoUrl");

            Team t = new Team();
            t.setName(name);
            t.setCategoryId(categoryId);
            t.setCountry(country);
            t.setLogoUrl(logoUrl);

            boolean success = videoDAO.createTeam(t);
            response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=categories&" + (success ? "success=Team+created" : "error=Failed"));
        } catch (Exception e) {
            response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=categories&error=Error");
        }
    }

    private void handleDeleteTeam(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            int teamId = Integer.parseInt(request.getParameter("teamId"));
            boolean success = videoDAO.deleteTeam(teamId);
            response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=categories&" + (success ? "success=Team+deleted" : "error=Failed"));
        } catch (Exception e) {
            response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=categories&error=Error");
        }
    }

    // --- Member 3 Handlers ---
    private void handleUpdateVideoStatus(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            int videoId = Integer.parseInt(request.getParameter("videoId"));
            String status = request.getParameter("status");
            boolean success = adminDAO.updateVideoStatus(videoId, status);
            response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=videos&" + (success ? "success=Video+status+updated" : "error=Failed"));
        } catch (Exception e) {
            response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=videos&error=Error");
        }
    }

    private void handleDeleteVideo(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            int videoId = Integer.parseInt(request.getParameter("videoId"));
            boolean success = videoDAO.deleteVideo(videoId, 0, true);
            response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=videos&" + (success ? "success=Video+deleted" : "error=Failed"));
        } catch (Exception e) {
            response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=videos&error=Error");
        }
    }

    // --- Member 4 Handlers ---
    private void handleDeleteComment(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            int commentId = Integer.parseInt(request.getParameter("commentId"));
            boolean success = engagementDAO.deleteComment(commentId, 0, true);
            response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=comments&" + (success ? "success=Comment+removed" : "error=Failed"));
        } catch (Exception e) {
            response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=comments&error=Error");
        }
    }

    // --- Member 5 Handlers ---
    private void handleCreateAd(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            HttpSession session = request.getSession(false);
            User currentUser = (User) session.getAttribute("currentUser");

            String title = request.getParameter("title");
            String adType = request.getParameter("adType");
            String imageUrl = request.getParameter("imageUrl");
            String targetUrl = request.getParameter("targetUrl");
            Date startDate = Date.valueOf(request.getParameter("startDate"));
            Date endDate = Date.valueOf(request.getParameter("endDate"));
            int priority = Integer.parseInt(request.getParameter("priority"));

            Advertisement ad = new Advertisement();
            ad.setAdvertiserId(currentUser.getUserId());
            ad.setTitle(title);
            ad.setAdType(adType);
            ad.setImageUrl(imageUrl);
            ad.setTargetUrl(targetUrl);
            ad.setStartDate(startDate);
            ad.setEndDate(endDate);
            ad.setPriority(priority);
            ad.setStatus("ACTIVE");

            boolean success = advertisementDAO.createAd(ad);
            response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=ads&" + (success ? "success=Ad+campaign+created" : "error=Failed"));
        } catch (Exception e) {
            response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=ads&error=Invalid+ad+data");
        }
    }

    private void handleUpdateAdStatus(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            int adId = Integer.parseInt(request.getParameter("adId"));
            String status = request.getParameter("status");
            boolean success = advertisementDAO.updateAdStatus(adId, status);
            response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=ads&" + (success ? "success=Ad+status+updated" : "error=Failed"));
        } catch (Exception e) {
            response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=ads&error=Error");
        }
    }

    private void handleDeleteAd(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            int adId = Integer.parseInt(request.getParameter("adId"));
            boolean success = advertisementDAO.deleteAd(adId, 0, true);
            response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=ads&" + (success ? "success=Ad+deleted" : "error=Failed"));
        } catch (Exception e) {
            response.sendRedirect(request.getContextPath() + "/admin/dashboard?tab=ads&error=Error");
        }
    }
}
