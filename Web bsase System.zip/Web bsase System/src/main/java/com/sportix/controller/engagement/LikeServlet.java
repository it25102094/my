package com.sportix.controller.engagement;

import com.sportix.dao.EngagementDAO;
import com.sportix.dao.VideoDAO;
import com.sportix.model.User;
import com.sportix.model.Video;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Controller for Liking/Disliking Sports Videos.
 * Supports asynchronous AJAX requests and standard redirects.
 * Assigned to Member 4 (IT25102091 - Wijesekara W.M.B.S.).
 */
@WebServlet(name = "LikeServlet", urlPatterns = {"/video/like"})
public class LikeServlet extends HttpServlet {

    private final EngagementDAO engagementDAO = new EngagementDAO();
    private final VideoDAO videoDAO = new VideoDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {

        HttpSession session = request.getSession(false);
        User currentUser = (session != null) ? (User) session.getAttribute("currentUser") : null;

        if (currentUser == null) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.getWriter().write("{\"error\": \"Must be logged in\"}");
            return;
        }

        String videoIdStr = request.getParameter("videoId");
        String isLikeStr = request.getParameter("isLike");

        if (videoIdStr != null && isLikeStr != null) {
            try {
                int videoId = Integer.parseInt(videoIdStr);
                boolean isLike = "1".equals(isLikeStr) || "true".equalsIgnoreCase(isLikeStr);

                engagementDAO.setLikeStatus(currentUser.getUserId(), videoId, isLike);

                // Fetch updated stats
                Video video = videoDAO.getVideoById(videoId);
                Integer currentStatus = engagementDAO.getUserLikeStatus(currentUser.getUserId(), videoId);

                response.setContentType("application/json");
                response.setCharacterEncoding("UTF-8");
                String jsonResponse = String.format(
                    "{\"success\": true, \"likeCount\": %d, \"dislikeCount\": %d, \"userStatus\": %s}",
                    video.getLikeCount(),
                    video.getDislikeCount(),
                    currentStatus != null ? currentStatus.toString() : "null"
                );
                response.getWriter().write(jsonResponse);
                return;
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
        response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
    }
}
