package com.sportix.controller.video;

import com.sportix.dao.VideoDAO;
import com.sportix.model.Category;
import com.sportix.model.Team;
import com.sportix.model.Video;
import com.sportix.patterns.strategy.MostViewedStrategy;
import com.sportix.patterns.strategy.RecentStrategy;
import com.sportix.patterns.strategy.TopRatedStrategy;
import com.sportix.patterns.strategy.VideoSortStrategy;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Controller for Video Search & Multi-criteria Filtering (UC-02: Search Sports Content).
 * Assigned to Member 2 (IT25102096 - Yashodhya H.N.).
 * Incorporates the STRATEGY DESIGN PATTERN for dynamic sorting algorithms.
 */
@WebServlet(name = "SearchServlet", urlPatterns = {"/search"})
public class SearchServlet extends HttpServlet {

    private final VideoDAO videoDAO = new VideoDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        String query = request.getParameter("q");
        String categoryParam = request.getParameter("category");
        String teamParam = request.getParameter("team");
        String formatParam = request.getParameter("type");
        String sortParam = request.getParameter("sortBy");

        Integer categoryId = parseInteger(categoryParam);
        Integer teamId = parseInteger(teamParam);

        // Retrieve matched videos
        List<Video> results = videoDAO.searchAndFilterVideos(query, categoryId, teamId, formatParam);

        // Apply STRATEGY DESIGN PATTERN for sorting algorithms
        VideoSortStrategy sortStrategy;
        if ("views".equalsIgnoreCase(sortParam)) {
            sortStrategy = new MostViewedStrategy();
        } else if ("rating".equalsIgnoreCase(sortParam)) {
            sortStrategy = new TopRatedStrategy();
        } else {
            sortStrategy = new RecentStrategy();
        }
        sortStrategy.sort(results);

        List<Category> categories = videoDAO.getAllCategories();
        List<Team> teams = videoDAO.getAllTeams();

        request.setAttribute("query", query);
        request.setAttribute("selectedCategory", categoryId);
        request.setAttribute("selectedTeam", teamId);
        request.setAttribute("selectedType", formatParam);
        request.setAttribute("selectedSort", sortParam);
        request.setAttribute("appliedStrategy", sortStrategy.getStrategyName());
        request.setAttribute("results", results);
        request.setAttribute("categories", categories);
        request.setAttribute("teams", teams);

        request.getRequestDispatcher("/WEB-INF/views/video/search.jsp").forward(request, response);
    }

    private Integer parseInteger(String str) {
        if (str != null && !str.trim().isEmpty()) {
            try {
                return Integer.parseInt(str.trim());
            } catch (NumberFormatException ignored) {}
        }
        return null;
    }
}
