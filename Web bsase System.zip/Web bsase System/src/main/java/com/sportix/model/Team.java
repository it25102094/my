package com.sportix.model;

import java.io.Serializable;

/**
 * Model representing a sports team.
 * Relevant to Member 1 (Follow Teams) and Member 2 (Browsing/Filter by Team).
 */
public class Team implements Serializable {
    private static final long serialVersionUID = 1L;

    private int teamId;
    private String name;
    private int categoryId;
    private String categoryName;
    private String country;
    private String logoUrl;
    private boolean isFollowedByCurrentUser;

    public Team() {}

    public Team(int teamId, String name, int categoryId, String country, String logoUrl) {
        this.teamId = teamId;
        this.name = name;
        this.categoryId = categoryId;
        this.country = country;
        this.logoUrl = logoUrl;
    }

    public int getTeamId() { return teamId; }
    public void setTeamId(int teamId) { this.teamId = teamId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public int getCategoryId() { return categoryId; }
    public void setCategoryId(int categoryId) { this.categoryId = categoryId; }

    public String getCategoryName() { return categoryName; }
    public void setCategoryName(String categoryName) { this.categoryName = categoryName; }

    public String getCountry() { return country; }
    public void setCountry(String country) { this.country = country; }

    public String getLogoUrl() { return logoUrl; }
    public void setLogoUrl(String logoUrl) { this.logoUrl = logoUrl; }

    public boolean isFollowedByCurrentUser() { return isFollowedByCurrentUser; }
    public void setFollowedByCurrentUser(boolean isFollowedByCurrentUser) { 
        this.isFollowedByCurrentUser = isFollowedByCurrentUser; 
    }
}
