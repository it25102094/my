package com.sportix.model;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

/**
 * Model representing an advertisement campaign.
 * Assigned to Member 5 (IT25102094 - Thilakarathna S.H.S.D.).
 */
public class Advertisement implements Serializable {
    private static final long serialVersionUID = 1L;

    private int adId;
    private int advertiserId;
    private String advertiserName;
    private String title;
    private String adType; // 'BANNER', 'SIDEBAR', 'CARD'
    private String imageUrl;
    private String targetUrl;
    private Date startDate;
    private Date endDate;
    private int priority;
    private String status; // 'SCHEDULED', 'ACTIVE', 'EXPIRED', 'PAUSED'
    private int impressions;
    private int clicks;
    private Timestamp createdAt;

    public Advertisement() {}

    public int getAdId() { return adId; }
    public void setAdId(int adId) { this.adId = adId; }

    public int getAdvertiserId() { return advertiserId; }
    public void setAdvertiserId(int advertiserId) { this.advertiserId = advertiserId; }

    public String getAdvertiserName() { return advertiserName; }
    public void setAdvertiserName(String advertiserName) { this.advertiserName = advertiserName; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getAdType() { return adType; }
    public void setAdType(String adType) { this.adType = adType; }

    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }

    public String getTargetUrl() { return targetUrl; }
    public void setTargetUrl(String targetUrl) { this.targetUrl = targetUrl; }

    public Date getStartDate() { return startDate; }
    public void setStartDate(Date startDate) { this.startDate = startDate; }

    public Date getEndDate() { return endDate; }
    public void setEndDate(Date endDate) { this.endDate = endDate; }

    public int getPriority() { return priority; }
    public void setPriority(int priority) { this.priority = priority; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public int getImpressions() { return impressions; }
    public void setImpressions(int impressions) { this.impressions = impressions; }

    public int getClicks() { return clicks; }
    public void setClicks(int clicks) { this.clicks = clicks; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }
}
