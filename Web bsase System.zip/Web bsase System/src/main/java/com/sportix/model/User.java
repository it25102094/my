package com.sportix.model;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Model representing a user in the Sportix platform.
 * Assigned to Member 1 (IT25102095 - Pasandul H.L.A.).
 */
public class User implements Serializable {
    private static final long serialVersionUID = 1L;

    private int userId;
    private String username;
    private String email;
    private String passwordHash;
    private String displayName;
    private String role; // 'GUEST', 'REGISTERED', 'CONTENT_MANAGER', 'ADVERTISER', 'ADMIN'
    private Timestamp createdAt;

    public User() {}

    public User(int userId, String username, String email, String displayName, String role) {
        this.userId = userId;
        this.username = username;
        this.email = email;
        this.displayName = displayName;
        this.role = role;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public boolean isAdmin() {
        return "ADMIN".equalsIgnoreCase(this.role);
    }

    public boolean isContentManager() {
        return "CONTENT_MANAGER".equalsIgnoreCase(this.role) || isAdmin();
    }

    public boolean isAdvertiser() {
        return "ADVERTISER".equalsIgnoreCase(this.role) || isAdmin();
    }
}
