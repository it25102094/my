package com.sportix.model;

import java.io.Serializable;

/**
 * Model representing a sports category.
 * Relevant to Member 2 (Video Browsing) and Member 6 (Admin Category Management).
 */
public class Category implements Serializable {
    private static final long serialVersionUID = 1L;

    private int categoryId;
    private String name;
    private String slug;
    private String description;
    private String iconClass;

    public Category() {}

    public Category(int categoryId, String name, String slug, String description, String iconClass) {
        this.categoryId = categoryId;
        this.name = name;
        this.slug = slug;
        this.description = description;
        this.iconClass = iconClass;
    }

    public int getCategoryId() { return categoryId; }
    public void setCategoryId(int categoryId) { this.categoryId = categoryId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getSlug() { return slug; }
    public void setSlug(String slug) { this.slug = slug; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getIconClass() { return iconClass; }
    public void setIconClass(String iconClass) { this.iconClass = iconClass; }
}
