package com.sportix.model;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Model representing a user comment on a sports video.
 * Assigned to Member 4 (IT25102091 - Wijesekara W.M.B.S.).
 */
public class Comment implements Serializable {
    private static final long serialVersionUID = 1L;

    private int commentId;
    private int userId;
    private String username;
    private String userDisplayName;
    private int videoId;
    private String content;
    private String status; // 'ACTIVE', 'HIDDEN'
    private Timestamp createdAt;
    private String videoTitle;

    public String getVideoTitle() { return videoTitle; }
    public void setVideoTitle(String videoTitle) { this.videoTitle = videoTitle; }

    public Comment() {}

    public Comment(int commentId, int userId, String username, String userDisplayName, int videoId, String content, Timestamp createdAt) {
        this.commentId = commentId;
        this.userId = userId;
        this.username = username;
        this.userDisplayName = userDisplayName;
        this.videoId = videoId;
        this.content = content;
        this.createdAt = createdAt;
        this.status = "ACTIVE";
    }

    public int getCommentId() { return commentId; }
    public void setCommentId(int commentId) { this.commentId = commentId; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getUserDisplayName() { return userDisplayName; }
    public void setUserDisplayName(String userDisplayName) { this.userDisplayName = userDisplayName; }

    public int getVideoId() { return videoId; }
    public void setVideoId(int videoId) { this.videoId = videoId; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }
}
