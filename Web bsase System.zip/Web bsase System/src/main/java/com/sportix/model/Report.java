package com.sportix.model;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Model representing a user report on an inappropriate video or comment.
 * Bridges Member 4 (User Engagement) and Member 6 (Admin Moderation Queue).
 */
public class Report implements Serializable {
    private static final long serialVersionUID = 1L;

    private int reportId;
    private int reporterId;
    private String reporterUsername;
    private String targetType; // 'VIDEO', 'COMMENT'
    private int targetId;
    private String targetContentTitleOrSnippet; // Details of the flagged video or comment
    private String reason;
    private String description;
    private String status; // 'PENDING', 'APPROVED', 'DISMISSED'
    private String adminNotes;
    private Timestamp createdAt;
    private Timestamp resolvedAt;

    public Report() {}

    public int getReportId() { return reportId; }
    public void setReportId(int reportId) { this.reportId = reportId; }

    public int getReporterId() { return reporterId; }
    public void setReporterId(int reporterId) { this.reporterId = reporterId; }

    public String getReporterUsername() { return reporterUsername; }
    public void setReporterUsername(String reporterUsername) { this.reporterUsername = reporterUsername; }

    public String getTargetType() { return targetType; }
    public void setTargetType(String targetType) { this.targetType = targetType; }

    public int getTargetId() { return targetId; }
    public void setTargetId(int targetId) { this.targetId = targetId; }

    public String getTargetContentTitleOrSnippet() { return targetContentTitleOrSnippet; }
    public void setTargetContentTitleOrSnippet(String targetContentTitleOrSnippet) { 
        this.targetContentTitleOrSnippet = targetContentTitleOrSnippet; 
    }

    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getAdminNotes() { return adminNotes; }
    public void setAdminNotes(String adminNotes) { this.adminNotes = adminNotes; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }

    public Timestamp getResolvedAt() { return resolvedAt; }
    public void setResolvedAt(Timestamp resolvedAt) { this.resolvedAt = resolvedAt; }
}
