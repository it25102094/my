package com.sportix.model;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

/**
 * Model representing a sports video item.
 * Assigned to Member 2 (Browsing/Searching) and Member 3 (Content Posting Management).
 */
public class Video implements Serializable {
    private static final long serialVersionUID = 1L;

    private int videoId;
    private String title;
    private String description;
    private String youtubeUrl;
    private String youtubeVideoId;
    private String thumbnailUrl;
    private int categoryId;
    private String categoryName;
    private Integer teamId;
    private String teamName;
    private String videoType; // HIGHLIGHT, SHORT, LIVE, INTERVIEW
    private String matchScore; // Supports Spoiler-Free Mode
    private int uploaderId;
    private String uploaderName;
    private String status; // PENDING, APPROVED, REJECTED
    private boolean isFeatured;
    private Date featuredStartDate;
    private Date featuredEndDate;
    private int viewCount;
    private Timestamp createdAt;

    // Derived fields for engagement metrics
    private int likeCount;
    private int dislikeCount;
    private double avgRating;
    private int commentCount;
    private boolean isSavedInWatchLater;
    private Integer userLikeStatus; // 1 = liked, 0 = disliked, null = none
    private Integer userRating;     // 1 to 5, null = not rated

    public Video() {}

    public int getVideoId() { return videoId; }
    public void setVideoId(int videoId) { this.videoId = videoId; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getYoutubeUrl() { return youtubeUrl; }
    public void setYoutubeUrl(String youtubeUrl) { this.youtubeUrl = youtubeUrl; }

    public String getYoutubeVideoId() { return youtubeVideoId; }
    public void setYoutubeVideoId(String youtubeVideoId) { this.youtubeVideoId = youtubeVideoId; }

    public String getThumbnailUrl() { return thumbnailUrl; }
    public void setThumbnailUrl(String thumbnailUrl) { this.thumbnailUrl = thumbnailUrl; }

    public int getCategoryId() { return categoryId; }
    public void setCategoryId(int categoryId) { this.categoryId = categoryId; }

    public String getCategoryName() { return categoryName; }
    public void setCategoryName(String categoryName) { this.categoryName = categoryName; }

    public Integer getTeamId() { return teamId; }
    public void setTeamId(Integer teamId) { this.teamId = teamId; }

    public String getTeamName() { return teamName; }
    public void setTeamName(String teamName) { this.teamName = teamName; }

    public String getVideoType() { return videoType; }
    public void setVideoType(String videoType) { this.videoType = videoType; }

    public String getMatchScore() { return matchScore; }
    public void setMatchScore(String matchScore) { this.matchScore = matchScore; }

    public int getUploaderId() { return uploaderId; }
    public void setUploaderId(int uploaderId) { this.uploaderId = uploaderId; }

    public String getUploaderName() { return uploaderName; }
    public void setUploaderName(String uploaderName) { this.uploaderName = uploaderName; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public boolean isFeatured() { return isFeatured; }
    public void setFeatured(boolean isFeatured) { this.isFeatured = isFeatured; }

    public Date getFeaturedStartDate() { return featuredStartDate; }
    public void setFeaturedStartDate(Date featuredStartDate) { this.featuredStartDate = featuredStartDate; }

    public Date getFeaturedEndDate() { return featuredEndDate; }
    public void setFeaturedEndDate(Date featuredEndDate) { this.featuredEndDate = featuredEndDate; }

    public int getViewCount() { return viewCount; }
    public void setViewCount(int viewCount) { this.viewCount = viewCount; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }

    public int getLikeCount() { return likeCount; }
    public void setLikeCount(int likeCount) { this.likeCount = likeCount; }

    public int getDislikeCount() { return dislikeCount; }
    public void setDislikeCount(int dislikeCount) { this.dislikeCount = dislikeCount; }

    public double getAvgRating() { return avgRating; }
    public void setAvgRating(double avgRating) { this.avgRating = avgRating; }

    public int getCommentCount() { return commentCount; }
    public void setCommentCount(int commentCount) { this.commentCount = commentCount; }

    public boolean isSavedInWatchLater() { return isSavedInWatchLater; }
    public void setSavedInWatchLater(boolean isSavedInWatchLater) { this.isSavedInWatchLater = isSavedInWatchLater; }

    public Integer getUserLikeStatus() { return userLikeStatus; }
    public void setUserLikeStatus(Integer userLikeStatus) { this.userLikeStatus = userLikeStatus; }

    public Integer getUserRating() { return userRating; }
    public void setUserRating(Integer userRating) { this.userRating = userRating; }
}
