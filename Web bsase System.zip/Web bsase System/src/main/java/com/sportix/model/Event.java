package com.sportix.model;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

/**
 * Model representing a Sporting Event / Live Match.
 * Assigned to Member 3 (Content Posting) and Member 6 (Admin Operations).
 */
public class Event implements Serializable {
    private static final long serialVersionUID = 1L;

    private int eventId;
    private String title;
    private int categoryId;
    private String categoryName;
    private String tournamentName;
    private int team1Id;
    private String team1Name;
    private String team1Logo;
    private int team2Id;
    private String team2Name;
    private String team2Logo;
    private Date eventDate;
    private String eventTime;
    private String venue;
    private String status; // 'UPCOMING', 'LIVE', 'COMPLETED'
    private String team1Score;
    private String team2Score;
    private String matchSummary;
    private int liveViewers;
    private Integer videoId;
    private Timestamp createdAt;

    public Event() {}

    public int getEventId() { return eventId; }
    public void setEventId(int eventId) { this.eventId = eventId; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public int getCategoryId() { return categoryId; }
    public void setCategoryId(int categoryId) { this.categoryId = categoryId; }

    public String getCategoryName() { return categoryName; }
    public void setCategoryName(String categoryName) { this.categoryName = categoryName; }

    public String getTournamentName() { return tournamentName; }
    public void setTournamentName(String tournamentName) { this.tournamentName = tournamentName; }

    public int getTeam1Id() { return team1Id; }
    public void setTeam1Id(int team1Id) { this.team1Id = team1Id; }

    public String getTeam1Name() { return team1Name; }
    public void setTeam1Name(String team1Name) { this.team1Name = team1Name; }

    public String getTeam1Logo() { return team1Logo; }
    public void setTeam1Logo(String team1Logo) { this.team1Logo = team1Logo; }

    public int getTeam2Id() { return team2Id; }
    public void setTeam2Id(int team2Id) { this.team2Id = team2Id; }

    public String getTeam2Name() { return team2Name; }
    public void setTeam2Name(String team2Name) { this.team2Name = team2Name; }

    public String getTeam2Logo() { return team2Logo; }
    public void setTeam2Logo(String team2Logo) { this.team2Logo = team2Logo; }

    public Date getEventDate() { return eventDate; }
    public void setEventDate(Date eventDate) { this.eventDate = eventDate; }

    public String getEventTime() { return eventTime; }
    public void setEventTime(String eventTime) { this.eventTime = eventTime; }

    public String getVenue() { return venue; }
    public void setVenue(String venue) { this.venue = venue; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getTeam1Score() { return team1Score; }
    public void setTeam1Score(String team1Score) { this.team1Score = team1Score; }

    public String getTeam2Score() { return team2Score; }
    public void setTeam2Score(String team2Score) { this.team2Score = team2Score; }

    public String getMatchSummary() { return matchSummary; }
    public void setMatchSummary(String matchSummary) { this.matchSummary = matchSummary; }

    public int getLiveViewers() { return liveViewers; }
    public void setLiveViewers(int liveViewers) { this.liveViewers = liveViewers; }

    public Integer getVideoId() { return videoId; }
    public void setVideoId(Integer videoId) { this.videoId = videoId; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }

    public boolean isLive() {
        return "LIVE".equalsIgnoreCase(this.status);
    }
}
