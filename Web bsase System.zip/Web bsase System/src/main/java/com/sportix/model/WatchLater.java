package com.sportix.model;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Model representing a video saved to the user's Watch Later list.
 * Assigned to Member 1 (IT25102095 - Pasandul H.L.A.).
 */
public class WatchLater implements Serializable {
    private static final long serialVersionUID = 1L;

    private int watchId;
    private int userId;
    private int videoId;
    private Video video;
    private Timestamp addedAt;

    public WatchLater() {}

    public WatchLater(int watchId, int userId, int videoId, Video video, Timestamp addedAt) {
        this.watchId = watchId;
        this.userId = userId;
        this.videoId = videoId;
        this.video = video;
        this.addedAt = addedAt;
    }

    public int getWatchId() { return watchId; }
    public void setWatchId(int watchId) { this.watchId = watchId; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public int getVideoId() { return videoId; }
    public void setVideoId(int videoId) { this.videoId = videoId; }

    public Video getVideo() { return video; }
    public void setVideo(Video video) { this.video = video; }

    public Timestamp getAddedAt() { return addedAt; }
    public void setAddedAt(Timestamp addedAt) { this.addedAt = addedAt; }
}
