package com.sportix.model;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Model representing a star rating given to a sports video (1 - 5 stars).
 * Assigned to Member 4 (IT25102091 - Wijesekara W.M.B.S.).
 */
public class Rating implements Serializable {
    private static final long serialVersionUID = 1L;

    private int ratingId;
    private int userId;
    private int videoId;
    private int ratingValue;
    private Timestamp createdAt;

    public Rating() {}

    public Rating(int ratingId, int userId, int videoId, int ratingValue) {
        this.ratingId = ratingId;
        this.userId = userId;
        this.videoId = videoId;
        this.ratingValue = ratingValue;
    }

    public int getRatingId() { return ratingId; }
    public void setRatingId(int ratingId) { this.ratingId = ratingId; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public int getVideoId() { return videoId; }
    public void setVideoId(int videoId) { this.videoId = videoId; }

    public int getRatingValue() { return ratingValue; }
    public void setRatingValue(int ratingValue) { this.ratingValue = ratingValue; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }
}
