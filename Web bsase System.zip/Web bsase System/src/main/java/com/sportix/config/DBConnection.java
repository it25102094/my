package com.sportix.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * DBConnection - Implements the SINGLETON DESIGN PATTERN.
 * Ensures a single, centralized entry point for obtaining database connections
 * throughout the entire Sportix application.
 * 
 * Satisfies the SE2030 Design Pattern requirement (Rubric: Design Patterns).
 */
public class DBConnection {

    private static volatile DBConnection instance;
    private static final String URL = "jdbc:mysql://localhost:3306/sportix_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String USERNAME = "root";
    private static final String PASSWORD = ""; // Change according to your MySQL root password

    // Private constructor prevents instantiation from outside
    private DBConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.err.println("CRITICAL: MySQL JDBC Driver not found in classpath!");
            e.printStackTrace();
        }
    }

    /**
     * Thread-safe Singleton access method with Double-Checked Locking.
     * @return Single instance of DBConnection
     */
    public static DBConnection getInstance() {
        if (instance == null) {
            synchronized (DBConnection.class) {
                if (instance == null) {
                    instance = new DBConnection();
                }
            }
        }
        return instance;
    }

    /**
     * Creates and returns a new active Connection object to the MySQL database.
     * @return Connection object
     * @throws SQLException if a database access error occurs
     */
    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }
}
