package com.sportix.dao;

import com.sportix.config.DBConnection;
import com.sportix.model.Team;
import com.sportix.model.User;
import com.sportix.model.Video;
import com.sportix.model.WatchLater;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for User Accounts, Watch Later, and Team Following.
 * Assigned to Member 1 (IT25102095 - Pasandul H.L.A.).
 * Satisfies CRUD operations on Users, WatchLater, and Followed Teams.
 */
public class UserDAO {

    /**
     * Creates a new user account in database.
     * Uses PreparedStatement to prevent SQL Injection.
     */
    public boolean registerUser(User user) {
        String sql = "INSERT INTO users (username, email, password_hash, display_name, role) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setString(1, user.getUsername());
            stmt.setString(2, user.getEmail());
            stmt.setString(3, user.getPasswordHash());
            stmt.setString(4, user.getDisplayName());
            stmt.setString(5, user.getRole() != null ? user.getRole() : "REGISTERED");

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        user.setUserId(rs.getInt(1));
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Authenticates user by username or email.
     */
    public User authenticate(String usernameOrEmail) {
        String sql = "SELECT * FROM users WHERE username = ? OR email = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, usernameOrEmail);
            stmt.setString(2, usernameOrEmail);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    User user = mapResultSetToUser(rs);
                    user.setPasswordHash(rs.getString("password_hash"));
                    return user;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public User findById(int userId) {
        String sql = "SELECT * FROM users WHERE user_id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, userId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToUser(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean updateProfile(User user) {
        String sql = "UPDATE users SET display_name = ?, email = ? WHERE user_id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, user.getDisplayName());
            stmt.setString(2, user.getEmail());
            stmt.setInt(3, user.getUserId());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean updatePassword(int userId, String newPasswordHash) {
        String sql = "UPDATE users SET password_hash = ? WHERE user_id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, newPasswordHash);
            stmt.setInt(2, userId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // -------------------------------------------------------------------------
    // Team Following Operations
    // -------------------------------------------------------------------------

    public boolean followTeam(int userId, int teamId) {
        String sql = "INSERT IGNORE INTO user_followed_teams (user_id, team_id) VALUES (?, ?)";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            stmt.setInt(2, teamId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean unfollowTeam(int userId, int teamId) {
        String sql = "DELETE FROM user_followed_teams WHERE user_id = ? AND team_id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            stmt.setInt(2, teamId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public List<Team> getFollowedTeams(int userId) {
        List<Team> teams = new ArrayList<>();
        String sql = "SELECT t.*, c.name AS category_name FROM teams t " +
                     "JOIN user_followed_teams uft ON t.team_id = uft.team_id " +
                     "JOIN categories c ON t.category_id = c.category_id " +
                     "WHERE uft.user_id = ? ORDER BY t.name ASC";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Team team = new Team();
                    team.setTeamId(rs.getInt("team_id"));
                    team.setName(rs.getString("name"));
                    team.setCategoryId(rs.getInt("category_id"));
                    team.setCategoryName(rs.getString("category_name"));
                    team.setCountry(rs.getString("country"));
                    team.setLogoUrl(rs.getString("logo_url"));
                    team.setFollowedByCurrentUser(true);
                    teams.add(team);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return teams;
    }

    public List<Integer> getTeamFollowerUserIds(int teamId) {
        List<Integer> userIds = new ArrayList<>();
        String sql = "SELECT user_id FROM user_followed_teams WHERE team_id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, teamId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    userIds.add(rs.getInt("user_id"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return userIds;
    }

    // -------------------------------------------------------------------------
    // Watch Later Operations
    // -------------------------------------------------------------------------

    public boolean addToWatchLater(int userId, int videoId) {
        String sql = "INSERT IGNORE INTO watch_later (user_id, video_id) VALUES (?, ?)";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            stmt.setInt(2, videoId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean removeFromWatchLater(int userId, int videoId) {
        String sql = "DELETE FROM watch_later WHERE user_id = ? AND video_id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            stmt.setInt(2, videoId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean isVideoInWatchLater(int userId, int videoId) {
        String sql = "SELECT 1 FROM watch_later WHERE user_id = ? AND video_id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            stmt.setInt(2, videoId);
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public List<WatchLater> getWatchLaterVideos(int userId) {
        List<WatchLater> list = new ArrayList<>();
        String sql = "SELECT wl.*, v.*, c.name AS category_name, t.name AS team_name " +
                     "FROM watch_later wl " +
                     "JOIN videos v ON wl.video_id = v.video_id " +
                     "JOIN categories c ON v.category_id = c.category_id " +
                     "LEFT JOIN teams t ON v.team_id = t.team_id " +
                     "WHERE wl.user_id = ? ORDER BY wl.added_at DESC";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    WatchLater wl = new WatchLater();
                    wl.setWatchId(rs.getInt("watch_id"));
                    wl.setUserId(userId);
                    wl.setVideoId(rs.getInt("video_id"));
                    wl.setAddedAt(rs.getTimestamp("added_at"));

                    Video video = new Video();
                    video.setVideoId(rs.getInt("video_id"));
                    video.setTitle(rs.getString("title"));
                    video.setDescription(rs.getString("description"));
                    video.setYoutubeUrl(rs.getString("youtube_url"));
                    video.setYoutubeVideoId(rs.getString("youtube_video_id"));
                    video.setThumbnailUrl(rs.getString("thumbnail_url"));
                    video.setCategoryName(rs.getString("category_name"));
                    video.setTeamName(rs.getString("team_name"));
                    video.setVideoType(rs.getString("video_type"));
                    video.setMatchScore(rs.getString("match_score"));
                    video.setViewCount(rs.getInt("view_count"));
                    wl.setVideo(video);

                    list.add(wl);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * DELETE: Delete user account by ID (Member 1 - Admin Oversight).
     */
    public boolean deleteUser(int userId) {
        String sql = "DELETE FROM users WHERE user_id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private User mapResultSetToUser(ResultSet rs) throws SQLException {
        User user = new User();
        user.setUserId(rs.getInt("user_id"));
        user.setUsername(rs.getString("username"));
        user.setEmail(rs.getString("email"));
        user.setDisplayName(rs.getString("display_name"));
        user.setRole(rs.getString("role"));
        user.setCreatedAt(rs.getTimestamp("created_at"));
        return user;
    }
}
