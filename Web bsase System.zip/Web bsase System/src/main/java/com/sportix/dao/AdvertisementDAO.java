package com.sportix.dao;

import com.sportix.config.DBConnection;
import com.sportix.model.Advertisement;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for Advertising Campaigns.
 * Assigned to Member 5 (IT25102094 - Thilakarathna S.H.S.D.).
 * Handles Campaign Creation (UC-05), Editing, Deleting, and Impressions/Clicks.
 */
public class AdvertisementDAO {

    public boolean createAd(Advertisement ad) {
        String sql = "INSERT INTO advertisements (advertiser_id, title, ad_type, image_url, target_url, " +
                     "start_date, end_date, priority, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setInt(1, ad.getAdvertiserId());
            stmt.setString(2, ad.getTitle());
            stmt.setString(3, ad.getAdType() != null ? ad.getAdType() : "BANNER");
            stmt.setString(4, ad.getImageUrl());
            stmt.setString(5, ad.getTargetUrl());
            stmt.setDate(6, ad.getStartDate());
            stmt.setDate(7, ad.getEndDate());
            stmt.setInt(8, ad.getPriority());
            stmt.setString(9, ad.getStatus() != null ? ad.getStatus() : "ACTIVE");

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        ad.setAdId(rs.getInt(1));
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean updateAd(Advertisement ad) {
        String sql = "UPDATE advertisements SET title = ?, ad_type = ?, image_url = ?, target_url = ?, " +
                     "start_date = ?, end_date = ?, priority = ?, status = ? WHERE ad_id = ? AND advertiser_id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, ad.getTitle());
            stmt.setString(2, ad.getAdType());
            stmt.setString(3, ad.getImageUrl());
            stmt.setString(4, ad.getTargetUrl());
            stmt.setDate(5, ad.getStartDate());
            stmt.setDate(6, ad.getEndDate());
            stmt.setInt(7, ad.getPriority());
            stmt.setString(8, ad.getStatus());
            stmt.setInt(9, ad.getAdId());
            stmt.setInt(10, ad.getAdvertiserId());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean deleteAd(int adId, int advertiserId, boolean isAdmin) {
        String sql;
        if (isAdmin) {
            sql = "DELETE FROM advertisements WHERE ad_id = ?";
        } else {
            sql = "DELETE FROM advertisements WHERE ad_id = ? AND advertiser_id = ?";
        }
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, adId);
            if (!isAdmin) {
                stmt.setInt(2, advertiserId);
            }
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public List<Advertisement> getAllAds() {
        List<Advertisement> list = new ArrayList<>();
        String sql = "SELECT a.*, u.display_name AS advertiser_name " +
                     "FROM advertisements a " +
                     "JOIN users u ON a.advertiser_id = u.user_id " +
                     "ORDER BY a.created_at DESC";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                list.add(mapResultSetToAd(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Advertisement> getActiveAds(String adType) {
        List<Advertisement> list = new ArrayList<>();
        String sql = "SELECT a.*, u.display_name AS advertiser_name " +
                     "FROM advertisements a " +
                     "JOIN users u ON a.advertiser_id = u.user_id " +
                     "WHERE a.ad_type = ? AND a.status = 'ACTIVE' " +
                     "AND a.start_date <= CURDATE() AND a.end_date >= CURDATE() " +
                     "ORDER BY a.priority DESC, RAND() LIMIT 3";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, adType);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToAd(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Advertisement> getAdsByAdvertiser(int advertiserId) {
        List<Advertisement> list = new ArrayList<>();
        String sql = "SELECT a.*, u.display_name AS advertiser_name " +
                     "FROM advertisements a " +
                     "JOIN users u ON a.advertiser_id = u.user_id " +
                     "WHERE a.advertiser_id = ? ORDER BY a.created_at DESC";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, advertiserId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToAd(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public void incrementImpressions(int adId) {
        String sql = "UPDATE advertisements SET impressions = impressions + 1 WHERE ad_id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, adId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void incrementClicks(int adId) {
        String sql = "UPDATE advertisements SET clicks = clicks + 1 WHERE ad_id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, adId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private Advertisement mapResultSetToAd(ResultSet rs) throws SQLException {
        Advertisement ad = new Advertisement();
        ad.setAdId(rs.getInt("ad_id"));
        ad.setAdvertiserId(rs.getInt("advertiser_id"));
        ad.setAdvertiserName(rs.getString("advertiser_name"));
        ad.setTitle(rs.getString("title"));
        ad.setAdType(rs.getString("ad_type"));
        ad.setImageUrl(rs.getString("image_url"));
        ad.getTargetUrl();
        ad.setTargetUrl(rs.getString("target_url"));
        ad.setStartDate(rs.getDate("start_date"));
        ad.setEndDate(rs.getDate("end_date"));
        ad.setPriority(rs.getInt("priority"));
        ad.setStatus(rs.getString("status"));
        ad.setImpressions(rs.getInt("impressions"));
        ad.setClicks(rs.getInt("clicks"));
        ad.setCreatedAt(rs.getTimestamp("created_at"));
        return ad;
    }
}
