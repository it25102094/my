package com.sportix.dao;

import com.sportix.config.DBConnection;
import com.sportix.model.Report;
import com.sportix.model.User;
import com.sportix.model.Video;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Data Access Object for Administrator Functions & Moderation.
 * Assigned to Member 6 (IT25102092 - Samarasingha S.A.A.K.B.).
 * Handles Content Approval/Rejection (UC-06), System Analytics, and User Management.
 */
public class AdminDAO {

    /**
     * Dashboard statistics aggregation.
     */
    public Map<String, Integer> getDashboardStats() {
        Map<String, Integer> stats = new HashMap<>();
        try (Connection conn = DBConnection.getInstance().getConnection()) {
            
            stats.put("totalUsers", getCount(conn, "SELECT COUNT(*) FROM users"));
            stats.put("totalVideos", getCount(conn, "SELECT COUNT(*) FROM videos WHERE status = 'APPROVED'"));
            stats.put("pendingVideos", getCount(conn, "SELECT COUNT(*) FROM videos WHERE status = 'PENDING'"));
            stats.put("totalComments", getCount(conn, "SELECT COUNT(*) FROM comments"));
            stats.put("pendingReports", getCount(conn, "SELECT COUNT(*) FROM reports WHERE status = 'PENDING'"));
            stats.put("activeAds", getCount(conn, "SELECT COUNT(*) FROM advertisements WHERE status = 'ACTIVE'"));
            stats.put("totalEvents", getCount(conn, "SELECT COUNT(*) FROM events"));
            stats.put("liveEvents", getCount(conn, "SELECT COUNT(*) FROM events WHERE status = 'LIVE'"));

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return stats;
    }

    private int getCount(Connection conn, String query) throws SQLException {
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }

    /**
     * Moderation Queue: Get all pending user reports (UC-06).
     */
    public List<Report> getPendingReports() {
        List<Report> list = new ArrayList<>();
        String sql = "SELECT r.*, u.username AS reporter_username FROM reports r " +
                     "JOIN users u ON r.reporter_id = u.user_id " +
                     "WHERE r.status = 'PENDING' ORDER BY r.created_at ASC";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Report r = new Report();
                r.setReportId(rs.getInt("report_id"));
                r.setReporterId(rs.getInt("reporter_id"));
                r.setReporterUsername(rs.getString("reporter_username"));
                r.setTargetType(rs.getString("target_type"));
                r.setTargetId(rs.getInt("target_id"));
                r.setReason(rs.getString("reason"));
                r.setDescription(rs.getString("description"));
                r.setStatus(rs.getString("status"));
                r.setCreatedAt(rs.getTimestamp("created_at"));
                list.add(r);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * Moderation Queue: Resolve a report (Approve penalty or Dismiss report).
     */
    public boolean resolveReport(int reportId, String status, String adminNotes) {
        String sql = "UPDATE reports SET status = ?, admin_notes = ?, resolved_at = CURRENT_TIMESTAMP WHERE report_id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, status);
            stmt.setString(2, adminNotes);
            stmt.setInt(3, reportId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Approve or reject a video submission (UC-06).
     */
    public boolean updateVideoStatus(int videoId, String status) {
        String sql = "UPDATE videos SET status = ? WHERE video_id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, status);
            stmt.setInt(2, videoId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Get all users for admin user management.
     */
    public List<User> getAllUsers() {
        List<User> list = new ArrayList<>();
        String sql = "SELECT user_id, username, email, display_name, role, created_at FROM users ORDER BY created_at DESC";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                User u = new User();
                u.setUserId(rs.getInt("user_id"));
                u.setUsername(rs.getString("username"));
                u.setEmail(rs.getString("email"));
                u.setDisplayName(rs.getString("display_name"));
                u.setRole(rs.getString("role"));
                u.setCreatedAt(rs.getTimestamp("created_at"));
                list.add(u);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public boolean updateUserRole(int userId, String newRole) {
        String sql = "UPDATE users SET role = ? WHERE user_id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, newRole);
            stmt.setInt(2, userId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
