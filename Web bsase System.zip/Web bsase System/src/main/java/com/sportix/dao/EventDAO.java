package com.sportix.dao;

import com.sportix.config.DBConnection;
import com.sportix.model.Event;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for Sporting Events and Live Matches.
 * Implements complete CRUD (Create, Read, Update, Delete) operations.
 * Assigned to Member 3 (Content Management) and Member 6 (Admin Operations).
 */
public class EventDAO {

    /**
     * CREATE: Add a new sporting event / match fixture.
     */
    public boolean createEvent(Event event) {
        String sql = "INSERT INTO events (title, category_id, tournament_name, team1_id, team2_id, " +
                     "event_date, event_time, venue, status, team1_score, team2_score, match_summary, live_viewers, video_id) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setString(1, event.getTitle());
            stmt.setInt(2, event.getCategoryId());
            stmt.setString(3, event.getTournamentName());
            stmt.setInt(4, event.getTeam1Id());
            stmt.setInt(5, event.getTeam2Id());
            stmt.setDate(6, event.getEventDate());
            stmt.setString(7, event.getEventTime());
            stmt.setString(8, event.getVenue());
            stmt.setString(9, event.getStatus() != null ? event.getStatus() : "UPCOMING");
            stmt.setString(10, event.getTeam1Score());
            stmt.setString(11, event.getTeam2Score());
            stmt.setString(12, event.getMatchSummary());
            stmt.setInt(13, event.getLiveViewers());
            if (event.getVideoId() != null && event.getVideoId() > 0) {
                stmt.setInt(14, event.getVideoId());
            } else {
                stmt.setNull(14, Types.INTEGER);
            }

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        event.setEventId(rs.getInt(1));
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * READ: Get a single event by ID with full team names and category.
     */
    public Event getEventById(int eventId) {
        String sql = "SELECT e.*, c.name AS category_name, t1.name AS team1_name, t1.logo_url AS team1_logo, " +
                     "t2.name AS team2_name, t2.logo_url AS team2_logo " +
                     "FROM events e " +
                     "JOIN categories c ON e.category_id = c.category_id " +
                     "JOIN teams t1 ON e.team1_id = t1.team_id " +
                     "JOIN teams t2 ON e.team2_id = t2.team_id " +
                     "WHERE e.event_id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, eventId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToEvent(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * READ: Retrieve all events ordered by date descending.
     */
    public List<Event> getAllEvents() {
        List<Event> list = new ArrayList<>();
        String sql = "SELECT e.*, c.name AS category_name, t1.name AS team1_name, t1.logo_url AS team1_logo, " +
                     "t2.name AS team2_name, t2.logo_url AS team2_logo " +
                     "FROM events e " +
                     "JOIN categories c ON e.category_id = c.category_id " +
                     "JOIN teams t1 ON e.team1_id = t1.team_id " +
                     "JOIN teams t2 ON e.team2_id = t2.team_id " +
                     "ORDER BY e.status = 'LIVE' DESC, e.event_date DESC";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                list.add(mapResultSetToEvent(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * READ: Retrieve active LIVE events for home showcase.
     */
    public List<Event> getLiveEvents() {
        List<Event> list = new ArrayList<>();
        String sql = "SELECT e.*, c.name AS category_name, t1.name AS team1_name, t1.logo_url AS team1_logo, " +
                     "t2.name AS team2_name, t2.logo_url AS team2_logo " +
                     "FROM events e " +
                     "JOIN categories c ON e.category_id = c.category_id " +
                     "JOIN teams t1 ON e.team1_id = t1.team_id " +
                     "JOIN teams t2 ON e.team2_id = t2.team_id " +
                     "WHERE e.status = 'LIVE' " +
                     "ORDER BY e.live_viewers DESC LIMIT 4";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                list.add(mapResultSetToEvent(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * UPDATE: Update full event details.
     */
    public boolean updateEvent(Event event) {
        String sql = "UPDATE events SET title = ?, category_id = ?, tournament_name = ?, team1_id = ?, team2_id = ?, " +
                     "event_date = ?, event_time = ?, venue = ?, status = ?, team1_score = ?, team2_score = ?, " +
                     "match_summary = ?, live_viewers = ?, video_id = ? WHERE event_id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, event.getTitle());
            stmt.setInt(2, event.getCategoryId());
            stmt.setString(3, event.getTournamentName());
            stmt.setInt(4, event.getTeam1Id());
            stmt.setInt(5, event.getTeam2Id());
            stmt.setDate(6, event.getEventDate());
            stmt.setString(7, event.getEventTime());
            stmt.setString(8, event.getVenue());
            stmt.setString(9, event.getStatus());
            stmt.setString(10, event.getTeam1Score());
            stmt.setString(11, event.getTeam2Score());
            stmt.setString(12, event.getMatchSummary());
            stmt.setInt(13, event.getLiveViewers());
            if (event.getVideoId() != null && event.getVideoId() > 0) {
                stmt.setInt(14, event.getVideoId());
            } else {
                stmt.setNull(14, Types.INTEGER);
            }
            stmt.setInt(15, event.getEventId());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * UPDATE: Quick update for match score, status, and lead summary (Admin live desk).
     */
    public boolean updateEventScoreAndStatus(int eventId, String t1Score, String t2Score, String status, String summary) {
        String sql = "UPDATE events SET team1_score = ?, team2_score = ?, status = ?, match_summary = ? WHERE event_id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, t1Score);
            stmt.setString(2, t2Score);
            stmt.setString(3, status);
            stmt.setString(4, summary);
            stmt.setInt(5, eventId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * DELETE: Remove an event by ID.
     */
    public boolean deleteEvent(int eventId) {
        String sql = "DELETE FROM events WHERE event_id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, eventId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private Event mapResultSetToEvent(ResultSet rs) throws SQLException {
        Event e = new Event();
        e.setEventId(rs.getInt("event_id"));
        e.setTitle(rs.getString("title"));
        e.setCategoryId(rs.getInt("category_id"));
        e.setCategoryName(rs.getString("category_name"));
        e.setTournamentName(rs.getString("tournament_name"));
        e.setTeam1Id(rs.getInt("team1_id"));
        e.setTeam1Name(rs.getString("team1_name"));
        e.setTeam1Logo(rs.getString("team1_logo"));
        e.setTeam2Id(rs.getInt("team2_id"));
        e.setTeam2Name(rs.getString("team2_name"));
        e.setTeam2Logo(rs.getString("team2_logo"));
        e.setEventDate(rs.getDate("event_date"));
        e.setEventTime(rs.getString("event_time"));
        e.setVenue(rs.getString("venue"));
        e.setStatus(rs.getString("status"));
        e.setTeam1Score(rs.getString("team1_score"));
        e.setTeam2Score(rs.getString("team2_score"));
        e.setMatchSummary(rs.getString("match_summary"));
        e.setLiveViewers(rs.getInt("live_viewers"));
        e.setVideoId((Integer) rs.getObject("video_id"));
        e.setCreatedAt(rs.getTimestamp("created_at"));
        return e;
    }
}
