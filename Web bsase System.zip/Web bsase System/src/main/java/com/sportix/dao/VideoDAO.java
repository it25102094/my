package com.sportix.dao;

import com.sportix.config.DBConnection;
import com.sportix.model.Category;
import com.sportix.model.Team;
import com.sportix.model.Video;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for Video Browsing, Searching, and Content Management.
 * Assigned to Member 2 (IT25102096 - Yashodhya H.N.) and Member 3 (IT25102093 - Jayawardhana M.A.H.F.).
 */
public class VideoDAO {

    /**
     * Add a new video (Member 3 - Content Posting Management).
     */
    public boolean addVideo(Video video) {
        String sql = "INSERT INTO videos (title, description, youtube_url, youtube_video_id, thumbnail_url, " +
                     "category_id, team_id, video_type, match_score, uploader_id, status, is_featured, featured_start_date, featured_end_date) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setString(1, video.getTitle());
            stmt.setString(2, video.getDescription());
            stmt.setString(3, video.getYoutubeUrl());
            stmt.setString(4, video.getYoutubeVideoId());
            stmt.setString(5, video.getThumbnailUrl());
            stmt.setInt(6, video.getCategoryId());
            if (video.getTeamId() != null && video.getTeamId() > 0) {
                stmt.setInt(7, video.getTeamId());
            } else {
                stmt.setNull(7, Types.INTEGER);
            }
            stmt.setString(8, video.getVideoType() != null ? video.getVideoType() : "HIGHLIGHT");
            stmt.setString(9, video.getMatchScore());
            stmt.setInt(10, video.getUploaderId());
            stmt.setString(11, video.getStatus() != null ? video.getStatus() : "APPROVED");
            stmt.setBoolean(12, video.isFeatured());
            stmt.setDate(13, video.getFeaturedStartDate());
            stmt.setDate(14, video.getFeaturedEndDate());

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        video.setVideoId(rs.getInt(1));
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Update video information (Member 3).
     */
    public boolean updateVideo(Video video) {
        String sql = "UPDATE videos SET title = ?, description = ?, youtube_url = ?, youtube_video_id = ?, " +
                     "thumbnail_url = ?, category_id = ?, team_id = ?, video_type = ?, match_score = ?, " +
                     "is_featured = ?, featured_start_date = ?, featured_end_date = ? WHERE video_id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, video.getTitle());
            stmt.setString(2, video.getDescription());
            stmt.setString(3, video.getYoutubeUrl());
            stmt.setString(4, video.getYoutubeVideoId());
            stmt.setString(5, video.getThumbnailUrl());
            stmt.setInt(6, video.getCategoryId());
            if (video.getTeamId() != null && video.getTeamId() > 0) {
                stmt.setInt(7, video.getTeamId());
            } else {
                stmt.setNull(7, Types.INTEGER);
            }
            stmt.setString(8, video.getVideoType());
            stmt.setString(9, video.getMatchScore());
            stmt.setBoolean(10, video.isFeatured());
            stmt.setDate(11, video.getFeaturedStartDate());
            stmt.setDate(12, video.getFeaturedEndDate());
            stmt.setInt(13, video.getVideoId());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Delete video (Member 3 / Member 6).
     */
    public boolean deleteVideo(int videoId) {
        String sql = "DELETE FROM videos WHERE video_id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, videoId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Get single video with calculated stats (like count, rating, uploader name).
     */
    public Video getVideoById(int videoId) {
        String sql = "SELECT v.*, c.name AS category_name, t.name AS team_name, u.display_name AS uploader_name, " +
                     "(SELECT COUNT(*) FROM video_likes WHERE video_id = v.video_id AND is_like = 1) AS like_count, " +
                     "(SELECT COUNT(*) FROM video_likes WHERE video_id = v.video_id AND is_like = 0) AS dislike_count, " +
                     "(SELECT COALESCE(AVG(rating_value), 0.0) FROM video_ratings WHERE video_id = v.video_id) AS avg_rating, " +
                     "(SELECT COUNT(*) FROM comments WHERE video_id = v.video_id AND status = 'ACTIVE') AS comment_count " +
                     "FROM videos v " +
                     "JOIN categories c ON v.category_id = c.category_id " +
                     "LEFT JOIN teams t ON v.team_id = t.team_id " +
                     "JOIN users u ON v.uploader_id = u.user_id " +
                     "WHERE v.video_id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, videoId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToVideo(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Get all approved videos for home feed (Member 2).
     */
    public List<Video> getAllApprovedVideos() {
        List<Video> list = new ArrayList<>();
        String sql = "SELECT v.*, c.name AS category_name, t.name AS team_name, u.display_name AS uploader_name, " +
                     "(SELECT COUNT(*) FROM video_likes WHERE video_id = v.video_id AND is_like = 1) AS like_count, " +
                     "(SELECT COUNT(*) FROM video_likes WHERE video_id = v.video_id AND is_like = 0) AS dislike_count, " +
                     "(SELECT COALESCE(AVG(rating_value), 0.0) FROM video_ratings WHERE video_id = v.video_id) AS avg_rating, " +
                     "(SELECT COUNT(*) FROM comments WHERE video_id = v.video_id AND status = 'ACTIVE') AS comment_count " +
                     "FROM videos v " +
                     "JOIN categories c ON v.category_id = c.category_id " +
                     "LEFT JOIN teams t ON v.team_id = t.team_id " +
                     "JOIN users u ON v.uploader_id = u.user_id " +
                     "WHERE v.status = 'APPROVED' " +
                     "ORDER BY v.created_at DESC";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                list.add(mapResultSetToVideo(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * Search and filter videos (Member 2 - Video Browsing & Searching).
     */
    public List<Video> searchAndFilterVideos(String keyword, Integer categoryId, Integer teamId, String videoType) {
        List<Video> list = new ArrayList<>();
        StringBuilder sql = new StringBuilder(
            "SELECT v.*, c.name AS category_name, t.name AS team_name, u.display_name AS uploader_name, " +
            "(SELECT COUNT(*) FROM video_likes WHERE video_id = v.video_id AND is_like = 1) AS like_count, " +
            "(SELECT COUNT(*) FROM video_likes WHERE video_id = v.video_id AND is_like = 0) AS dislike_count, " +
            "(SELECT COALESCE(AVG(rating_value), 0.0) FROM video_ratings WHERE video_id = v.video_id) AS avg_rating, " +
            "(SELECT COUNT(*) FROM comments WHERE video_id = v.video_id AND status = 'ACTIVE') AS comment_count " +
            "FROM videos v " +
            "JOIN categories c ON v.category_id = c.category_id " +
            "LEFT JOIN teams t ON v.team_id = t.team_id " +
            "JOIN users u ON v.uploader_id = u.user_id " +
            "WHERE v.status = 'APPROVED' "
        );

        List<Object> params = new ArrayList<>();

        if (keyword != null && !keyword.trim().isEmpty()) {
            sql.append("AND (v.title LIKE ? OR v.description LIKE ? OR t.name LIKE ?) ");
            String kwParam = "%" + keyword.trim() + "%";
            params.add(kwParam);
            params.add(kwParam);
            params.add(kwParam);
        }
        if (categoryId != null && categoryId > 0) {
            sql.append("AND v.category_id = ? ");
            params.add(categoryId);
        }
        if (teamId != null && teamId > 0) {
            sql.append("AND v.team_id = ? ");
            params.add(teamId);
        }
        if (videoType != null && !videoType.trim().isEmpty() && !"ALL".equalsIgnoreCase(videoType)) {
            sql.append("AND v.video_type = ? ");
            params.add(videoType.trim().toUpperCase());
        }

        sql.append("ORDER BY v.created_at DESC");

        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql.toString())) {
            
            for (int i = 0; i < params.size(); i++) {
                stmt.setObject(i + 1, params.get(i));
            }

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToVideo(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * Featured videos for hero carousel (Member 3).
     */
    public List<Video> getFeaturedVideos() {
        List<Video> list = new ArrayList<>();
        String sql = "SELECT v.*, c.name AS category_name, t.name AS team_name, u.display_name AS uploader_name, " +
                     "0 AS like_count, 0 AS dislike_count, 5.0 AS avg_rating, 0 AS comment_count " +
                     "FROM videos v " +
                     "JOIN categories c ON v.category_id = c.category_id " +
                     "LEFT JOIN teams t ON v.team_id = t.team_id " +
                     "JOIN users u ON v.uploader_id = u.user_id " +
                     "WHERE v.status = 'APPROVED' AND v.is_featured = 1 " +
                     "AND (v.featured_start_date IS NULL OR v.featured_start_date <= CURDATE()) " +
                     "AND (v.featured_end_date IS NULL OR v.featured_end_date >= CURDATE()) " +
                     "ORDER BY v.created_at DESC LIMIT 5";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                list.add(mapResultSetToVideo(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public boolean incrementViewCount(int videoId) {
        String sql = "UPDATE videos SET view_count = view_count + 1 WHERE video_id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, videoId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // -------------------------------------------------------------------------
    // Categories and Teams Retrieval
    // -------------------------------------------------------------------------

    public List<Category> getAllCategories() {
        List<Category> categories = new ArrayList<>();
        String sql = "SELECT * FROM categories ORDER BY name ASC";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Category c = new Category();
                c.setCategoryId(rs.getInt("category_id"));
                c.setName(rs.getString("name"));
                c.setSlug(rs.getString("slug"));
                c.setDescription(rs.getString("description"));
                c.setIconClass(rs.getString("icon_class"));
                categories.add(c);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return categories;
    }

    public List<Team> getAllTeams() {
        List<Team> teams = new ArrayList<>();
        String sql = "SELECT t.*, c.name AS category_name FROM teams t " +
                     "JOIN categories c ON t.category_id = c.category_id ORDER BY t.name ASC";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Team t = new Team();
                t.setTeamId(rs.getInt("team_id"));
                t.setName(rs.getString("name"));
                t.setCategoryId(rs.getInt("category_id"));
                t.setCategoryName(rs.getString("category_name"));
                t.setCountry(rs.getString("country"));
                t.setLogoUrl(rs.getString("logo_url"));
                teams.add(t);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return teams;
    }

    public boolean createCategory(Category c) {
        String sql = "INSERT INTO categories (name, slug, description, icon_class) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, c.getName());
            stmt.setString(2, c.getSlug() != null ? c.getSlug() : c.getName().toLowerCase().replaceAll("\\s+", "-"));
            stmt.setString(3, c.getDescription());
            stmt.setString(4, c.getIconClass() != null ? c.getIconClass() : "fas fa-futbol");
            int rows = stmt.executeUpdate();
            if (rows > 0) {
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) c.setCategoryId(rs.getInt(1));
                }
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean updateCategory(Category c) {
        String sql = "UPDATE categories SET name = ?, slug = ?, description = ?, icon_class = ? WHERE category_id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, c.getName());
            stmt.setString(2, c.getSlug());
            stmt.setString(3, c.getDescription());
            stmt.setString(4, c.getIconClass());
            stmt.setInt(5, c.getCategoryId());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean deleteCategory(int categoryId) {
        String sql = "DELETE FROM categories WHERE category_id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, categoryId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean createTeam(Team t) {
        String sql = "INSERT INTO teams (name, category_id, country, logo_url) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, t.getName());
            stmt.setInt(2, t.getCategoryId());
            stmt.setString(3, t.getCountry());
            stmt.setString(4, t.getLogoUrl());
            int rows = stmt.executeUpdate();
            if (rows > 0) {
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) t.setTeamId(rs.getInt(1));
                }
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean updateTeam(Team t) {
        String sql = "UPDATE teams SET name = ?, category_id = ?, country = ?, logo_url = ? WHERE team_id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, t.getName());
            stmt.setInt(2, t.getCategoryId());
            stmt.setString(3, t.getCountry());
            stmt.setString(4, t.getLogoUrl());
            stmt.setInt(5, t.getTeamId());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean deleteTeam(int teamId) {
        String sql = "DELETE FROM teams WHERE team_id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, teamId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private Video mapResultSetToVideo(ResultSet rs) throws SQLException {
        Video v = new Video();
        v.setVideoId(rs.getInt("video_id"));
        v.setTitle(rs.getString("title"));
        v.setDescription(rs.getString("description"));
        v.setYoutubeUrl(rs.getString("youtube_url"));
        v.setYoutubeVideoId(rs.getString("youtube_video_id"));
        v.setThumbnailUrl(rs.getString("thumbnail_url"));
        v.setCategoryId(rs.getInt("category_id"));
        v.setCategoryName(rs.getString("category_name"));
        v.setTeamId((Integer) rs.getObject("team_id"));
        v.setTeamName(rs.getString("team_name"));
        v.setVideoType(rs.getString("video_type"));
        v.setMatchScore(rs.getString("match_score"));
        v.setUploaderId(rs.getInt("uploader_id"));
        v.setUploaderName(rs.getString("uploader_name"));
        v.setStatus(rs.getString("status"));
        v.setFeatured(rs.getBoolean("is_featured"));
        v.setFeaturedStartDate(rs.getDate("featured_start_date"));
        v.setFeaturedEndDate(rs.getDate("featured_end_date"));
        v.setViewCount(rs.getInt("view_count"));
        v.setCreatedAt(rs.getTimestamp("created_at"));
        v.setLikeCount(rs.getInt("like_count"));
        v.setDislikeCount(rs.getInt("dislike_count"));
        v.setAvgRating(Math.round(rs.getDouble("avg_rating") * 10.0) / 10.0);
        v.setCommentCount(rs.getInt("comment_count"));
        return v;
    }
}
