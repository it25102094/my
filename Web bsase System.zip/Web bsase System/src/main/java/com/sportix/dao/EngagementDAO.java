package com.sportix.dao;

import com.sportix.config.DBConnection;
import com.sportix.model.Comment;
import com.sportix.model.Report;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for User Engagement (Likes, Ratings, Comments, and Content Reporting).
 * Assigned to Member 4 (IT25102091 - Wijesekara W.M.B.S.).
 * Implements full CRUD functionality on comments, likes, ratings, and moderation reports.
 */
public class EngagementDAO {

    // -------------------------------------------------------------------------
    // 1. COMMENTS CRUD OPERATIONS (Member 4)
    // -------------------------------------------------------------------------

    /**
     * CREATE: Add a new comment to a video.
     */
    public boolean addComment(Comment comment) {
        String sql = "INSERT INTO comments (user_id, video_id, content, status) VALUES (?, ?, ?, 'ACTIVE')";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setInt(1, comment.getUserId());
            stmt.setInt(2, comment.getVideoId());
            stmt.setString(3, comment.getContent());

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        comment.setCommentId(rs.getInt(1));
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * READ: Get all active comments for a specific video, ordered newest first.
     */
    public List<Comment> getCommentsByVideoId(int videoId) {
        List<Comment> list = new ArrayList<>();
        String sql = "SELECT c.*, u.username, u.display_name " +
                     "FROM comments c " +
                     "JOIN users u ON c.user_id = u.user_id " +
                     "WHERE c.video_id = ? AND c.status = 'ACTIVE' " +
                     "ORDER BY c.created_at DESC";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, videoId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Comment comment = new Comment();
                    comment.setCommentId(rs.getInt("comment_id"));
                    comment.setUserId(rs.getInt("user_id"));
                    comment.setUsername(rs.getString("username"));
                    comment.setUserDisplayName(rs.getString("display_name"));
                    comment.setVideoId(rs.getInt("video_id"));
                    comment.setContent(rs.getString("content"));
                    comment.setStatus(rs.getString("status"));
                    comment.setCreatedAt(rs.getTimestamp("created_at"));
                    list.add(comment);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * READ: Get all platform comments across all videos for Admin moderation desk.
     */
    public List<Comment> getAllComments() {
        List<Comment> list = new ArrayList<>();
        String sql = "SELECT c.*, u.username, u.display_name, v.title AS video_title " +
                     "FROM comments c " +
                     "JOIN users u ON c.user_id = u.user_id " +
                     "JOIN videos v ON c.video_id = v.video_id " +
                     "ORDER BY c.created_at DESC LIMIT 50";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Comment comment = new Comment();
                comment.setCommentId(rs.getInt("comment_id"));
                comment.setUserId(rs.getInt("user_id"));
                comment.setUsername(rs.getString("username"));
                comment.setUserDisplayName(rs.getString("display_name"));
                comment.setVideoId(rs.getInt("video_id"));
                comment.setVideoTitle(rs.getString("video_title"));
                comment.setContent(rs.getString("content"));
                comment.setStatus(rs.getString("status"));
                comment.setCreatedAt(rs.getTimestamp("created_at"));
                list.add(comment);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * UPDATE: Edit an existing comment content.
     */
    public boolean updateComment(int commentId, int userId, String newContent) {
        String sql = "UPDATE comments SET content = ? WHERE comment_id = ? AND user_id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, newContent);
            stmt.setInt(2, commentId);
            stmt.setInt(3, userId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * DELETE: Remove/hide a comment by comment owner or admin.
     */
    public boolean deleteComment(int commentId, int userId, boolean isAdmin) {
        String sql;
        if (isAdmin) {
            sql = "DELETE FROM comments WHERE comment_id = ?";
        } else {
            sql = "DELETE FROM comments WHERE comment_id = ? AND user_id = ?";
        }
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, commentId);
            if (!isAdmin) {
                stmt.setInt(2, userId);
            }
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // -------------------------------------------------------------------------
    // 2. LIKES & DISLIKES (Member 4)
    // -------------------------------------------------------------------------

    /**
     * Toggle like or dislike. If user already clicked same button, removes reaction;
     * otherwise, sets or updates the reaction.
     */
    public boolean setLikeStatus(int userId, int videoId, boolean isLike) {
        String checkSql = "SELECT is_like FROM video_likes WHERE user_id = ? AND video_id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection()) {
            boolean exists = false;
            boolean existingStatus = false;

            try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
                checkStmt.setInt(1, userId);
                checkStmt.setInt(2, videoId);
                try (ResultSet rs = checkStmt.executeQuery()) {
                    if (rs.next()) {
                        exists = true;
                        existingStatus = rs.getBoolean("is_like");
                    }
                }
            }

            if (exists) {
                if (existingStatus == isLike) {
                    // Clicked same again -> Remove reaction (toggle off)
                    String deleteSql = "DELETE FROM video_likes WHERE user_id = ? AND video_id = ?";
                    try (PreparedStatement delStmt = conn.prepareStatement(deleteSql)) {
                        delStmt.setInt(1, userId);
                        delStmt.setInt(2, videoId);
                        return delStmt.executeUpdate() > 0;
                    }
                } else {
                    // Switched reaction (like to dislike or vice versa)
                    String updateSql = "UPDATE video_likes SET is_like = ? WHERE user_id = ? AND video_id = ?";
                    try (PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {
                        updateStmt.setBoolean(1, isLike);
                        updateStmt.setInt(2, userId);
                        updateStmt.setInt(3, videoId);
                        return updateStmt.executeUpdate() > 0;
                    }
                }
            } else {
                // New reaction
                String insertSql = "INSERT INTO video_likes (user_id, video_id, is_like) VALUES (?, ?, ?)";
                try (PreparedStatement insertStmt = conn.prepareStatement(insertSql)) {
                    insertStmt.setInt(1, userId);
                    insertStmt.setInt(2, videoId);
                    insertStmt.setBoolean(3, isLike);
                    return insertStmt.executeUpdate() > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public Integer getUserLikeStatus(int userId, int videoId) {
        String sql = "SELECT is_like FROM video_likes WHERE user_id = ? AND video_id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            stmt.setInt(2, videoId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getBoolean("is_like") ? 1 : 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null; // Not liked or disliked
    }

    // -------------------------------------------------------------------------
    // 3. RATINGS (Member 4 - 1 to 5 Stars)
    // -------------------------------------------------------------------------

    public boolean rateVideo(int userId, int videoId, int ratingValue) {
        if (ratingValue < 1 || ratingValue > 5) {
            return false;
        }
        String sql = "INSERT INTO video_ratings (user_id, video_id, rating_value) VALUES (?, ?, ?) " +
                     "ON DUPLICATE KEY UPDATE rating_value = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            stmt.setInt(2, videoId);
            stmt.setInt(3, ratingValue);
            stmt.setInt(4, ratingValue);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public Integer getUserRating(int userId, int videoId) {
        String sql = "SELECT rating_value FROM video_ratings WHERE user_id = ? AND video_id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            stmt.setInt(2, videoId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("rating_value");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // -------------------------------------------------------------------------
    // 4. REPORTING SYSTEM (UC-04: Report Video or Comment - Member 4)
    // -------------------------------------------------------------------------

    /**
     * Allows a registered user to flag abusive, misleading, or inappropriate content.
     * Prevents duplicate reports from the same user on the same item.
     */
    public boolean submitReport(Report report) {
        // Prevent duplicate report
        String checkSql = "SELECT 1 FROM reports WHERE reporter_id = ? AND target_type = ? AND target_id = ? AND status = 'PENDING'";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
            
            checkStmt.setInt(1, report.getReporterId());
            checkStmt.setString(2, report.getTargetType());
            checkStmt.setInt(3, report.getTargetId());
            
            try (ResultSet rs = checkStmt.executeQuery()) {
                if (rs.next()) {
                    return false; // Already reported and pending review
                }
            }

            String insertSql = "INSERT INTO reports (reporter_id, target_type, target_id, reason, description, status) " +
                               "VALUES (?, ?, ?, ?, ?, 'PENDING')";
            try (PreparedStatement insertStmt = conn.prepareStatement(insertSql, Statement.RETURN_GENERATED_KEYS)) {
                insertStmt.setInt(1, report.getReporterId());
                insertStmt.setString(2, report.getTargetType());
                insertStmt.setInt(3, report.getTargetId());
                insertStmt.setString(4, report.getReason());
                insertStmt.setString(5, report.getDescription());

                int rows = insertStmt.executeUpdate();
                if (rows > 0) {
                    try (ResultSet rs = insertStmt.getGeneratedKeys()) {
                        if (rs.next()) {
                            report.setReportId(rs.getInt(1));
                        }
                    }
                    return true;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
