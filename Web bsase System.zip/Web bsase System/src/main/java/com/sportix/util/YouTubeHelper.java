package com.sportix.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Helper class to parse and validate YouTube links, extract 11-character video IDs,
 * and generate embed player URLs and default thumbnail URLs.
 * Essential for Content Posting Management (Member 3) & Video Browsing (Member 2).
 */
public class YouTubeHelper {

    // Regex pattern matching standard youtube, youtu.be, shorts, and embed formats
    private static final String YOUTUBE_REGEX = 
            "(?:https?:\\/\\/)?(?:www\\.)?(?:youtube\\.com\\/(?:watch\\?v=|embed\\/|shorts\\/)|youtu\\.be\\/)([a-zA-Z0-9_-]{11})";

    private static final Pattern PATTERN = Pattern.compile(YOUTUBE_REGEX, Pattern.CASE_INSENSITIVE);

    /**
     * Extracts the 11-character YouTube video ID from a given URL.
     * @param url Full or shortened YouTube URL
     * @return 11-character video ID, or null if invalid
     */
    public static String extractVideoId(String url) {
        if (url == null || url.trim().isEmpty()) {
            return null;
        }
        Matcher matcher = PATTERN.matcher(url.trim());
        if (matcher.find()) {
            return matcher.group(1);
        }
        return null;
    }

    /**
     * Checks if the provided string is a valid YouTube URL.
     */
    public static boolean isValidYouTubeUrl(String url) {
        return extractVideoId(url) != null;
    }

    /**
     * Generates a secure embed URL for iframe embedding.
     */
    public static String getEmbedUrl(String videoId) {
        if (videoId == null || videoId.isEmpty()) {
            return "";
        }
        return "https://www.youtube.com/embed/" + videoId + "?autoplay=0&rel=0";
    }

    /**
     * Generates standard high-quality thumbnail image URL from YouTube CDN.
     */
    public static String getDefaultThumbnailUrl(String videoId) {
        if (videoId == null || videoId.isEmpty()) {
            return "assets/images/default-thumb.jpg";
        }
        return "https://img.youtube.com/vi/" + videoId + "/hqdefault.jpg";
    }
}
