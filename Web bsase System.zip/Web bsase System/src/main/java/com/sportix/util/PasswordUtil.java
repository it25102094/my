package com.sportix.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Utility for cryptographic operations.
 * Implements SHA-256 password hashing for secure authentication.
 * Satisfies NFR2 (Security) & NFR (Password Encryption).
 */
public class PasswordUtil {

    /**
     * Hashes a plain-text password using SHA-256 algorithm.
     * @param password Plain-text password entered by user
     * @return 64-character hexadecimal SHA-256 string
     */
    public static String hashPassword(String password) {
        if (password == null || password.trim().isEmpty()) {
            return null;
        }
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] encodedHash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder hexString = new StringBuilder();
            for (byte b : encodedHash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 algorithm not available in environment", e);
        }
    }

    /**
     * Verifies whether an entered password matches a stored hash.
     * @param rawPassword Plain text candidate
     * @param storedHash Existing hash from database
     * @return true if matches, false otherwise
     */
    public static boolean verifyPassword(String rawPassword, String storedHash) {
        if (rawPassword == null || storedHash == null) {
            return false;
        }
        String hashedCandidate = hashPassword(rawPassword);
        return storedHash.equalsIgnoreCase(hashedCandidate);
    }
}
