-- =======================================================
-- SPORTIX - Web-based Sports Video Browsing System
-- SE2030: Software Engineering Group Project
-- Group ID: 2026-Y2-S1-MTR-15
-- Production-Ready Database Schema & Relational Structure
-- =======================================================

CREATE DATABASE IF NOT EXISTS sportix_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sportix_db;

-- Drop existing tables in dependency order
DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS advertisements;
DROP TABLE IF EXISTS reports;
DROP TABLE IF EXISTS comments;
DROP TABLE IF EXISTS video_ratings;
DROP TABLE IF EXISTS video_likes;
DROP TABLE IF EXISTS watch_later;
DROP TABLE IF EXISTS events;
DROP TABLE IF EXISTS videos;
DROP TABLE IF EXISTS user_followed_teams;
DROP TABLE IF EXISTS teams;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS users;


CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    display_name VARCHAR(100) NOT NULL,
    role ENUM('GUEST', 'REGISTERED', 'CONTENT_MANAGER', 'ADVERTISER', 'ADMIN') NOT NULL DEFAULT 'REGISTERED',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------------
-- 2. CATEGORIES TABLE (Member 2 - IT25102096: Yashodhya H.N.)
-- ---------------------
CREATE TABLE categories (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE,
    slug VARCHAR(50) NOT NULL UNIQUE,
    description TEXT,
    icon_class VARCHAR(50) DEFAULT 'fas fa-futbol'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------------
-- 3. TEAMS TABLE (Member 1 & 2)
-- -------------------------------------------------------
CREATE TABLE teams (
    team_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    category_id INT NOT NULL,
    country VARCHAR(50),
    logo_url VARCHAR(255),
    CONSTRAINT fk_team_category FOREIGN KEY (category_id) REFERENCES categories(category_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------------
-- 4. USER FOLLOWED TEAMS (Member 1)
-- -------------------------------------------------------
CREATE TABLE user_followed_teams (
    user_id INT NOT NULL,
    team_id INT NOT NULL,
    followed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, team_id),
    CONSTRAINT fk_follow_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_follow_team FOREIGN KEY (team_id) REFERENCES teams(team_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------------
-- 5. VIDEOS TABLE (Member 2 & 3 - Jayawardhana & Yashodhya)
-- -------------------------------------------------------
CREATE TABLE videos (
    video_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    youtube_url VARCHAR(255) NOT NULL,
    youtube_video_id VARCHAR(50) NOT NULL,
    thumbnail_url VARCHAR(255),
    category_id INT NOT NULL,
    team_id INT,
    video_type ENUM('HIGHLIGHT', 'SHORT', 'LIVE', 'INTERVIEW') NOT NULL DEFAULT 'HIGHLIGHT',
    match_score VARCHAR(50) DEFAULT NULL,
    uploader_id INT NOT NULL,
    status ENUM('PENDING', 'APPROVED', 'REJECTED') NOT NULL DEFAULT 'APPROVED',
    is_featured BOOLEAN DEFAULT FALSE,
    featured_start_date DATE DEFAULT NULL,
    featured_end_date DATE DEFAULT NULL,
    view_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_video_category FOREIGN KEY (category_id) REFERENCES categories(category_id) ON DELETE RESTRICT,
    CONSTRAINT fk_video_team FOREIGN KEY (team_id) REFERENCES teams(team_id) ON DELETE SET NULL,
    CONSTRAINT fk_video_uploader FOREIGN KEY (uploader_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------------
-- 6. EVENTS / LIVE MATCHES TABLE (Member 3 & Member 6: Jayawardhana & Samarasingha)
-- -------------------------------------------------------
CREATE TABLE events (
    event_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    category_id INT NOT NULL,
    tournament_name VARCHAR(100) NOT NULL,
    team1_id INT NOT NULL,
    team2_id INT NOT NULL,
    event_date DATE NOT NULL,
    event_time VARCHAR(30) NOT NULL,
    venue VARCHAR(150) NOT NULL,
    status ENUM('UPCOMING', 'LIVE', 'COMPLETED') NOT NULL DEFAULT 'UPCOMING',
    team1_score VARCHAR(50) DEFAULT NULL,
    team2_score VARCHAR(50) DEFAULT NULL,
    match_summary VARCHAR(200) DEFAULT NULL,
    live_viewers INT DEFAULT 0,
    video_id INT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_event_category FOREIGN KEY (category_id) REFERENCES categories(category_id) ON DELETE RESTRICT,
    CONSTRAINT fk_event_team1 FOREIGN KEY (team1_id) REFERENCES teams(team_id) ON DELETE CASCADE,
    CONSTRAINT fk_event_team2 FOREIGN KEY (team2_id) REFERENCES teams(team_id) ON DELETE CASCADE,
    CONSTRAINT fk_event_video FOREIGN KEY (video_id) REFERENCES videos(video_id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------------
-- 7. WATCH LATER TABLE (Member 1 - Pasandul H.L.A.)
-- -------------------------------------------------------
CREATE TABLE watch_later (
    watch_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    video_id INT NOT NULL,
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_user_video (user_id, video_id),
    CONSTRAINT fk_watch_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_watch_video FOREIGN KEY (video_id) REFERENCES videos(video_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------------
-- 8. ENGAGEMENT - LIKES & RATINGS (Member 4 - Wijesekara W.M.B.S.)
-- -------------------------------------------------------
CREATE TABLE video_likes (
    like_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    video_id INT NOT NULL,
    is_like BOOLEAN NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_like_user_video (user_id, video_id),
    CONSTRAINT fk_like_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_like_video FOREIGN KEY (video_id) REFERENCES videos(video_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE video_ratings (
    rating_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    video_id INT NOT NULL,
    rating_value TINYINT NOT NULL CHECK (rating_value BETWEEN 1 AND 5),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_rating_user_video (user_id, video_id),
    CONSTRAINT fk_rating_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_rating_video FOREIGN KEY (video_id) REFERENCES videos(video_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------------
-- 9. COMMENTS TABLE (Member 4 - Wijesekara W.M.B.S.)
-- -------------------------------------------------------
CREATE TABLE comments (
    comment_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    video_id INT NOT NULL,
    content TEXT NOT NULL,
    status ENUM('ACTIVE', 'HIDDEN') NOT NULL DEFAULT 'ACTIVE',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_comment_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_comment_video FOREIGN KEY (video_id) REFERENCES videos(video_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------------
-- 10. REPORTS TABLE (Member 4 & Member 6 - Wijesekara & Samarasingha)
-- -------------------------------------------------------
CREATE TABLE reports (
    report_id INT AUTO_INCREMENT PRIMARY KEY,
    reporter_id INT NOT NULL,
    target_type ENUM('VIDEO', 'COMMENT') NOT NULL,
    target_id INT NOT NULL,
    reason VARCHAR(100) NOT NULL,
    description TEXT,
    status ENUM('PENDING', 'APPROVED', 'DISMISSED') NOT NULL DEFAULT 'PENDING',
    admin_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP NULL,
    CONSTRAINT fk_report_reporter FOREIGN KEY (reporter_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------------
-- 11. ADVERTISEMENTS TABLE (Member 5 - Thilakarathna S.H.S.D.)
-- -------------------------------------------------------
CREATE TABLE advertisements (
    ad_id INT AUTO_INCREMENT PRIMARY KEY,
    advertiser_id INT NOT NULL,
    title VARCHAR(100) NOT NULL,
    ad_type ENUM('BANNER', 'SIDEBAR', 'CARD') NOT NULL DEFAULT 'BANNER',
    image_url VARCHAR(255) NOT NULL,
    target_url VARCHAR(255) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    priority INT DEFAULT 1,
    status ENUM('SCHEDULED', 'ACTIVE', 'EXPIRED', 'PAUSED') NOT NULL DEFAULT 'ACTIVE',
    impressions INT DEFAULT 0,
    clicks INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_ad_advertiser FOREIGN KEY (advertiser_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------------
-- 12. NOTIFICATIONS TABLE (Member 5 - Thilakarathna S.H.S.D.)
-- -------------------------------------------------------
CREATE TABLE notifications (
    notification_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(150) NOT NULL,
    message TEXT NOT NULL,
    type ENUM('TEAM_POST', 'SYSTEM', 'PROMOTION', 'MODERATION') NOT NULL DEFAULT 'SYSTEM',
    reference_id INT DEFAULT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_notification_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- =======================================================
-- INITIAL PRODUCTION-GRADE SEED DATA
-- =======================================================

-- Users (Hashed with SHA-256: 'Admin@123' for staff, 'User@123' for fans)
INSERT INTO users (username, email, password_hash, display_name, role) VALUES
('admin', 'admin@sportix.com', 'e86f78a8a3caf0b60d8e74e5942aa6d86dc150cd3c03338aef25b7d2d7e3acc7', 'Sportix Administrator', 'ADMIN'),
('content_mgr', 'content@sportix.com', 'e86f78a8a3caf0b60d8e74e5942aa6d86dc150cd3c03338aef25b7d2d7e3acc7', 'Content Manager', 'CONTENT_MANAGER'),
('advertiser1', 'ads@sportix.com', 'e86f78a8a3caf0b60d8e74e5942aa6d86dc150cd3c03338aef25b7d2d7e3acc7', 'RedBull Advertiser', 'ADVERTISER'),
('john_fan', 'john@example.com', '3e7c19576488862816f13b512cacf3e4ba97dd97243ea0bd6a2ad1642d86ba72', 'John Perera', 'REGISTERED'),
('kamal_fan', 'kamal@example.com', '3e7c19576488862816f13b512cacf3e4ba97dd97243ea0bd6a2ad1642d86ba72', 'Kamal Silva', 'REGISTERED'),
('kavindu_perera', 'kavindu@example.com', '3e7c19576488862816f13b512cacf3e4ba97dd97243ea0bd6a2ad1642d86ba72', 'Kavindu Perera', 'REGISTERED'),
('nimal_perera', 'nimal@example.com', '3e7c19576488862816f13b512cacf3e4ba97dd97243ea0bd6a2ad1642d86ba72', 'Nimal Perera', 'REGISTERED');

-- Categories
INSERT INTO categories (name, slug, description, icon_class) VALUES
('Cricket', 'cricket', 'Cricket highlights, T20 leagues, ICC tournaments and live scores.', 'fas fa-baseball-ball'),
('Football', 'football', 'Premier League, Champions League, FIFA and international soccer highlights.', 'fas fa-futbol'),
('Basketball', 'basketball', 'NBA games, top dunks, highlights and tactical breakdowns.', 'fas fa-basketball-ball'),
('Rugby', 'rugby', 'World Cup rugby fixtures, tries, and full match summaries.', 'fas fa-football-ball'),
('Tennis', 'tennis', 'Grand Slam matches, ATP tours, and best rallies.', 'fas fa-table-tennis');

-- Teams
INSERT INTO teams (team_id, name, category_id, country, logo_url) VALUES
(1, 'Colombo Lions', 1, 'Sri Lanka', 'https://upload.wikimedia.org/wikipedia/en/thumb/5/52/Sri_Lanka_Cricket_Logo.svg/1200px-Sri_Lanka_Cricket_Logo.svg.png'),
(2, 'Kandy Titans', 1, 'Sri Lanka', 'https://upload.wikimedia.org/wikipedia/en/thumb/4/41/Flag_of_India.svg/1200px-Flag_of_India.svg.png'),
(3, 'Galle Mariners', 2, 'Sri Lanka', 'https://upload.wikimedia.org/wikipedia/en/thumb/5/56/Real_Madrid_CF.svg/1200px-Real_Madrid_CF.svg.png'),
(4, 'Jaffna Rangers', 2, 'Sri Lanka', 'https://upload.wikimedia.org/wikipedia/en/thumb/7/7a/Manchester_United_FC_crest.svg/1200px-Manchester_United_FC_crest.svg.png'),
(5, 'Lanka Hurricanes', 4, 'Sri Lanka', 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3c/Los_Angeles_Lakers_logo.svg/1200px-Los_Angeles_Lakers_logo.svg.png'),
(6, 'Coastal Bears', 4, 'Sri Lanka', 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3c/Los_Angeles_Lakers_logo.svg/1200px-Los_Angeles_Lakers_logo.svg.png'),
(7, 'Sky City Bulls', 3, 'Sri Lanka', 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3c/Los_Angeles_Lakers_logo.svg/1200px-Los_Angeles_Lakers_logo.svg.png'),
(8, 'Riverside Falcons', 3, 'Sri Lanka', 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3c/Los_Angeles_Lakers_logo.svg/1200px-Los_Angeles_Lakers_logo.svg.png');

-- Videos (Curated Real Sports Highlights)
INSERT INTO videos (video_id, title, description, youtube_url, youtube_video_id, thumbnail_url, category_id, team_id, video_type, match_score, uploader_id, status, is_featured, view_count) VALUES
(1, 'Colombo Lions vs Kandy Titans | Live Cricket | Emerald Cup 2025', 'High intensity live cricket battle at R. Premadasa Stadium in Colombo.', 'https://www.youtube.com/watch?v=n4K04N7uGfc', 'n4K04N7uGfc', 'https://images.unsplash.com/photo-1531415074968-036ba1b575da?w=600&auto=format&fit=crop', 1, 1, 'LIVE', 'Lions 178/4 (32.1)', 2, 'APPROVED', TRUE, 45200),
(2, 'Sri Lanka FC 3 - 1 Maldives United | South Asia Club Cup', 'Dominant attacking performance with stunning team counter-attacks and precision finishes.', 'https://www.youtube.com/watch?v=kJQP7kiw5Fk', 'kJQP7kiw5Fk', 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=600&auto=format&fit=crop', 2, 3, 'HIGHLIGHT', 'Sri Lanka FC 3 - 1 Maldives Utd', 2, 'APPROVED', TRUE, 89100),
(3, 'Sri Lanka Rugby Highlights | Asia Rugby Championship', 'Thrilling physical contest showcasing brilliant defensive discipline and decisive tries.', 'https://www.youtube.com/watch?v=fJ9rUzIMcZQ', 'fJ9rUzIMcZQ', 'https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=600&auto=format&fit=crop', 4, 5, 'HIGHLIGHT', 'Hurricanes 24 - 18 Bears', 2, 'APPROVED', FALSE, 12800),
(4, 'Sky City Bulls vs Riverside Falcons | South Asia Basketball League', 'High scoring shootout with clutch three-pointers in the dying seconds of the fourth quarter.', 'https://www.youtube.com/watch?v=3JZ_D3ELwOQ', '3JZ_D3ELwOQ', 'https://images.unsplash.com/photo-1546519638-68e109498ffc?w=600&auto=format&fit=crop', 3, 7, 'HIGHLIGHT', 'Bulls 98 - 94 Falcons', 2, 'APPROVED', FALSE, 23400);

-- Events / Live Sporting Fixtures (Member 3 & 6 CRUD target)
INSERT INTO events (event_id, title, category_id, tournament_name, team1_id, team2_id, event_date, event_time, venue, status, team1_score, team2_score, match_summary, live_viewers, video_id) VALUES
(1, 'Colombo Lions vs Kandy Titans', 1, 'Emerald Cup 2025', 1, 2, CURDATE(), '2:30 PM (IST)', 'R. Premadasa Stadium, Colombo', 'LIVE', '178/4 (32.1)', '162/7 (35.0)', 'Lions lead by 16 runs', 24600, 1),
(2, 'Galle Mariners vs Jaffna Rangers', 2, 'Island Premier League', 3, 4, CURDATE(), '4:00 PM (IST)', 'Sugathadasa Stadium, Colombo', 'LIVE', '2', '1', 'Mariners lead 2-1 (78 min)', 18200, 2),
(3, 'Lanka Hurricanes vs Coastal Bears', 4, 'Oceanic Rugby Series', 5, 6, CURDATE(), '6:15 PM (IST)', 'Racecourse International Rugby Stadium', 'LIVE', '24', '18', '2nd Half - Hurricanes lead by 6', 7100, 3),
(4, 'Sky City Bulls vs Riverside Falcons', 3, 'South Asia Basketball League', 7, 8, CURDATE(), '8:00 PM (IST)', 'Sugathadasa Indoor Arena', 'LIVE', '82', '79', 'Q4 2:15 remaining', 5400, 4);

-- Real User Comments (Member 4)
INSERT INTO comments (user_id, video_id, content) VALUES
(4, 1, 'What an unforgettable victory for Sri Lanka! Goosebumps watching the final over.'),
(5, 1, 'Masterclass bowling under immense pressure. Dasun Shanaka captaincy was on point!'),
(4, 2, 'Sensational passing from the midfield. Deserved victory!');

-- Likes & Ratings (Member 4)
INSERT INTO video_likes (user_id, video_id, is_like) VALUES
(4, 1, 1),
(5, 1, 1),
(4, 2, 1);

INSERT INTO video_ratings (user_id, video_id, rating_value) VALUES
(4, 1, 5),
(5, 1, 5),
(4, 2, 4);

-- Advertisements (Member 5)
INSERT INTO advertisements (advertiser_id, title, ad_type, image_url, target_url, start_date, end_date, priority, status) VALUES
(3, 'Solaris Clean Energy - Fans Fuel a Brighter Tomorrow', 'BANNER', 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=1200&auto=format&fit=crop', 'https://www.solaris.com', CURDATE(), DATE_ADD(CURDATE(), INTERVAL 30 DAY), 1, 'ACTIVE'),
(3, 'Nike Pro Sports Gear 2026 Collection', 'SIDEBAR', 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600&auto=format&fit=crop', 'https://www.nike.com', CURDATE(), DATE_ADD(CURDATE(), INTERVAL 20 DAY), 2, 'ACTIVE');

-- Notifications (Member 5)
INSERT INTO notifications (user_id, title, message, type) VALUES
(4, 'Emerald Cup 2025 Live Match', 'Colombo Lions vs Kandy Titans is now live! Watch the broadcast now.', 'TEAM_POST'),
(5, 'Welcome to Sportix!', 'Follow your favorite teams to receive automated notifications when new matches are scheduled.', 'SYSTEM');
