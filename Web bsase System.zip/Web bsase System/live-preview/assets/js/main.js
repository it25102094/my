/**
 * SPORTIX - Client-side Interactive JavaScript
 * Handles AJAX Engagements, Spoiler-Free Mode, and Validations
 */

document.addEventListener('DOMContentLoaded', () => {

    // ---------------------------------------------------------
    // 1. Spoiler-Free Mode Toggle (NFR4)
    // ---------------------------------------------------------
    const spoilerToggle = document.getElementById('spoilerFreeToggle');
    if (spoilerToggle) {
        const isSpoilerFree = localStorage.getItem('sportix_spoiler_free') === 'true';
        spoilerToggle.checked = isSpoilerFree;
        applySpoilerFreeMode(isSpoilerFree);

        spoilerToggle.addEventListener('change', (e) => {
            const enabled = e.target.checked;
            localStorage.setItem('sportix_spoiler_free', enabled);
            applySpoilerFreeMode(enabled);
        });
    }

    function applySpoilerFreeMode(enabled) {
        const scoreElements = document.querySelectorAll('.spoiler-score');
        scoreElements.forEach(el => {
            if (enabled) {
                el.classList.add('spoiler-blur');
                el.title = "Click to reveal match score";
            } else {
                el.classList.remove('spoiler-blur');
                el.title = "";
            }
        });
    }

    // Individual click to reveal blurred score
    document.querySelectorAll('.spoiler-score').forEach(el => {
        el.addEventListener('click', () => {
            el.classList.toggle('spoiler-blur');
        });
    });

    // ---------------------------------------------------------
    // 2. AJAX Like & Dislike Handler (Member 4)
    // ---------------------------------------------------------
    const likeBtn = document.getElementById('likeBtn');
    const dislikeBtn = document.getElementById('dislikeBtn');

    if (likeBtn && dislikeBtn) {
        likeBtn.addEventListener('click', () => sendReaction(1));
        dislikeBtn.addEventListener('click', () => sendReaction(0));
    }

    function sendReaction(isLike) {
        const videoId = document.getElementById('currentVideoId')?.value;
        if (!videoId) return;

        fetch('video/like', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `videoId=${videoId}&isLike=${isLike}`
        })
        .then(response => {
            if (response.status === 401) {
                window.location.href = 'login';
                return;
            }
            return response.json();
        })
        .then(data => {
            if (data && data.success) {
                document.getElementById('likeCount').innerText = data.likeCount;
                document.getElementById('dislikeCount').innerText = data.dislikeCount;

                if (data.userStatus === 1) {
                    likeBtn.classList.add('active');
                    dislikeBtn.classList.remove('active');
                } else if (data.userStatus === 0) {
                    dislikeBtn.classList.add('active');
                    likeBtn.classList.remove('active');
                } else {
                    likeBtn.classList.remove('active');
                    dislikeBtn.classList.remove('active');
                }
            }
        })
        .catch(err => console.error('Error recording reaction:', err));
    }

    // ---------------------------------------------------------
    // 3. Star Rating Handler (Member 4)
    // ---------------------------------------------------------
    const starContainer = document.getElementById('starRatingContainer');
    if (starContainer) {
        const stars = starContainer.querySelectorAll('.star-item');
        const videoId = document.getElementById('currentVideoId')?.value;

        stars.forEach(star => {
            star.addEventListener('click', () => {
                const rating = star.getAttribute('data-rating');
                fetch('video/rate', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `videoId=${videoId}&rating=${rating}`
                })
                .then(res => {
                    if (res.status === 401) {
                        window.location.href = 'login';
                        return;
                    }
                    return res.json();
                })
                .then(data => {
                    if (data && data.success) {
                        document.getElementById('avgRatingDisplay').innerText = data.avgRating;
                        highlightStars(data.userRating);
                    }
                });
            });
        });

        function highlightStars(ratingValue) {
            stars.forEach(s => {
                const val = parseInt(s.getAttribute('data-rating'));
                if (val <= ratingValue) {
                    s.classList.add('fas', 'active');
                    s.classList.remove('far');
                } else {
                    s.classList.remove('fas', 'active');
                    s.classList.add('far');
                }
            });
        }
    }

    // ---------------------------------------------------------
    // 4. Instant YouTube Preview for Add Video (Member 3)
    // ---------------------------------------------------------
    const ytUrlInput = document.getElementById('youtubeUrlInput');
    const ytPreviewContainer = document.getElementById('ytPreviewContainer');
    const ytThumbPreview = document.getElementById('ytThumbPreview');

    if (ytUrlInput && ytPreviewContainer && ytThumbPreview) {
        ytUrlInput.addEventListener('input', () => {
            const val = ytUrlInput.value.trim();
            const regex = /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/;
            const match = val.match(regex);

            if (match && match[1]) {
                const videoId = match[1];
                ytThumbPreview.src = `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;
                ytPreviewContainer.style.display = 'block';
            } else {
                ytPreviewContainer.style.display = 'none';
            }
        });
    }
});
