# SPORTIX - How to Run in IntelliJ IDEA (Step-by-Step Guide)

## 🚀 1-Click Run in IntelliJ IDEA (Zero Setup Needed)

This project has been pre-configured for **IntelliJ IDEA (Community & Ultimate Editions)** with shared run configurations and a native Java server.

---

### Method 1: The Fastest Way (1-Click Run)

1. Open **IntelliJ IDEA**.
2. Click **File -> Open...** and select the folder:
   `c:\Users\MSI\Desktop\Web bsase System`
3. In the top right toolbar of IntelliJ, you will see a Run Configuration called:
   **`Run Sportix (IntelliJ)`** (or **`Run Sportix Server`**).
4. Simply click the green **▶ Play (Run)** button!
5. IntelliJ will start the server and automatically open the **Master Administrator Command Center** in your browser at:
   👉 **`http://localhost:8080/admin.html`**

---

### Method 2: Run directly from Java File

1. In IntelliJ Project tool window, expand:
   `src -> main -> java -> com -> sportix -> SportixServer.java`
2. Open **`SportixServer.java`**.
3. Right-click anywhere in the file and click:
   **`Run 'SportixServer.main()'`** (or click the green triangle icon on line 18).
4. The server starts immediately and opens the browser.

---

### Method 3: Run with Apache Tomcat (IntelliJ Ultimate)

If you have IntelliJ IDEA Ultimate Edition with external Apache Tomcat 9:
1. Go to **Run -> Edit Configurations...**
2. Click **+ (Add New Configuration) -> Tomcat Server -> Local**.
3. In the **Deployment** tab, click **+ -> Artifact -> `sportix-web-platform:war exploded`**.
4. Set Application Context to `/sportix`.
5. Click **Apply** and **Run**.

---

### 🌐 Key Endpoints when Running:
- **Master Admin Panel (All 6 Members CRUD):** `http://localhost:8080/admin.html`
- **Homepage:** `http://localhost:8080/index.html`
- **Live Match & HUD Score overlay:** `http://localhost:8080/watch.html?v=1`
- **Search & Filters:** `http://localhost:8080/search.html`
